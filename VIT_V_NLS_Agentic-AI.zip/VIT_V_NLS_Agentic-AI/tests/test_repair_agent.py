"""
Tests for the Repair Agent. No LLM needed here -- we construct the state
directly (as if Diagnosis already ran) to test the confidence-gating
behavior in isolation.
"""

import os
import pandas as pd
import pytest

from app.core.config import settings
from app.core.schemas import ForensicsState, DetectedIssue, Hypothesis, Evidence
from app.agents import repair_agent


def test_repair_agent_applies_fix_when_confidence_is_high():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-1", column="city", issue_type="category_inconsistency",
        severity="low", affected_rows=[0, 5, 8],
        raw_observation="New York spelling variants found.",
    ))
    state.hypotheses.append(Hypothesis(
        issue_id="issue-1", explanation="Same city, different capitalization.",
        requires_evidence=["data_dictionary_rule"],
    ))
    # Three evidence sources -> confidence = 0.45 + 0.30 + 0.10 = 0.85 >= 0.80 threshold
    state.evidence.append(Evidence(
        issue_id="issue-1", source="data_dictionary_rule",
        finding="City names should be consistently capitalized.", supports_hypothesis=True,
    ))
    state.evidence.append(Evidence(
        issue_id="issue-1", source="related_column_consistency",
        finding="All three rows share the same customer profile pattern.", supports_hypothesis=True,
    ))
    state.evidence.append(Evidence(
        issue_id="issue-1", source="pattern_frequency",
        finding="Case-inconsistent city names are a common entry error.", supports_hypothesis=True,
    ))
    state.current_issue_id = "issue-1"

    result_state = repair_agent.run(state)

    proposal = result_state.proposals[0]
    assert proposal.confidence >= settings.confidence_threshold
    assert result_state.sandbox_path is not None
    assert os.path.exists(result_state.sandbox_path)

    sandboxed_df = pd.read_csv(result_state.sandbox_path)
    ny_values = sandboxed_df.loc[[0, 5, 8], "city"].unique()
    assert len(ny_values) == 1

    original_df = pd.read_csv("sample_data/sample_customers.csv")
    assert original_df.loc[5, "city"] == "new york"  # still lowercase, unrepaired

    os.remove(result_state.sandbox_path)


def test_repair_agent_abstains_when_confidence_is_low():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-2", column="age", issue_type="outlier",
        severity="high", affected_rows=[3], raw_observation="Age=240 is extreme.",
    ))
    state.hypotheses.append(Hypothesis(
        issue_id="issue-2", explanation="Possibly a typo, unconfirmed.",
        requires_evidence=["pattern_frequency"],
    ))
    state.evidence.append(Evidence(
        issue_id="issue-2", source="pattern_frequency",
        finding="Extra-digit typos are a common data-entry error pattern.",
        supports_hypothesis=True,
    ))
    state.current_issue_id = "issue-2"

    result_state = repair_agent.run(state)

    proposal = result_state.proposals[0]
    assert proposal.confidence < settings.confidence_threshold
    assert result_state.sandbox_path is None


def test_repair_agent_never_auto_repairs_outliers_even_with_maximal_evidence():
    """
    Regression/design-decision test: outliers are DELIBERATELY excluded
    from automatic repair, even with maximal possible evidence support.
    See the design-decision docstring at the top of app/agents/repair_agent.py
    for the empirical finding (median substitution scored 0.0 Safe Repair
    Rate in an end-to-end evaluation) that justifies this.
    """
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-3", column="age", issue_type="outlier",
        severity="high", affected_rows=[3], raw_observation="Age=240 is extreme.",
    ))
    state.hypotheses.append(Hypothesis(
        issue_id="issue-3", explanation="Likely a typo.",
        requires_evidence=["data_dictionary_rule", "statistical_distribution", "related_column_consistency"],
    ))
    state.evidence.append(Evidence(
        issue_id="issue-3", source="data_dictionary_rule",
        finding="Age must be 0-120.", supports_hypothesis=True,
    ))
    state.evidence.append(Evidence(
        issue_id="issue-3", source="statistical_distribution",
        finding="240 is far outside the typical range.", supports_hypothesis=True,
    ))
    state.evidence.append(Evidence(
        issue_id="issue-3", source="related_column_consistency",
        finding="Other values in this row look normal.", supports_hypothesis=True,
    ))
    state.current_issue_id = "issue-3"

    result_state = repair_agent.run(state)

    proposal = result_state.proposals[0]
    assert proposal.confidence == 0.90
    assert proposal.action == "manual_value_correction"
    assert proposal.applied is False
    assert result_state.sandbox_path is None