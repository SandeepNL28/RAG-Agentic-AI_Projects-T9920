"""
Tests for the multi-seed evaluation aggregation. This is the closest
thing in the project to "does the whole research pipeline actually work
end-to-end across a batch of runs" -- so these are worth taking seriously
rather than treating as boilerplate.
"""

import pytest

from app.agents import diagnosis_agent
from evaluation.baselines import fixed_llm_workflow
from evaluation.run_multi_seed_evaluation import run_multi_seed_evaluation, AggregatedMetric


@pytest.fixture(autouse=True)
def mock_llm(monkeypatch):
    def _fake_diagnosis_llm(prompt, expect_json=True):
        return {
            "explanation": "Automated multi-seed evaluation hypothesis.",
            "requires_evidence": ["statistical_distribution", "data_dictionary_rule", "related_column_consistency", "pattern_frequency"],
        }
    monkeypatch.setattr(diagnosis_agent, "call_llm", _fake_diagnosis_llm)

    def _fake_baseline_llm(prompt, expect_json=True):
        if "impute" in prompt.lower() or "outlier" in prompt.lower():
            return {"action": "impute", "fixed_value": None}
        return {"action": "normalize", "fixed_value": None}
    monkeypatch.setattr(fixed_llm_workflow, "call_llm", _fake_baseline_llm)


def test_aggregated_metric_handles_a_simple_case():
    metric = AggregatedMetric(total_runs=4)
    metric.add(0.5)
    metric.add(0.7)
    metric.add(0.6)
    metric.add(None)  # e.g. safe_repair_rate was undefined on this run

    summary = metric.summary()
    assert summary["n_defined"] == 3
    assert summary["n_total"] == 4
    assert summary["mean"] == round((0.5 + 0.7 + 0.6) / 3, 4)
    assert summary["min"] == 0.5
    assert summary["max"] == 0.7


def test_aggregated_metric_reports_none_when_nothing_was_ever_defined():
    metric = AggregatedMetric(total_runs=3)
    metric.add(None)
    metric.add(None)
    metric.add(None)

    summary = metric.summary()
    assert summary["mean"] is None
    assert summary["n_defined"] == 0
    assert summary["n_total"] == 3


def test_multi_seed_evaluation_runs_all_seeds_and_aggregates():
    seeds = [1, 2, 3]
    results = run_multi_seed_evaluation(seeds=seeds)

    assert results["n_seeds_requested"] == 3
    assert results["n_seeds_succeeded"] == 3
    assert results["failed_seeds"] == []
    assert len(results["per_seed_results"]) == 3

    expected_metrics = {
        "baseline1_repair_accuracy", "baseline2_repair_accuracy",
        "proposed_precision", "proposed_recall", "proposed_f1",
        "proposed_safe_repair_rate", "proposed_false_repair_rate", "proposed_autonomy_rate",
    }
    assert set(results["aggregated"].keys()) == expected_metrics

    assert results["aggregated"]["proposed_f1"]["n_defined"] == 3
    assert 0.0 <= results["aggregated"]["proposed_f1"]["mean"] <= 1.0


def test_multi_seed_evaluation_actually_uses_different_corruption_per_seed():
    """
    Confirms the seed genuinely varies WHICH rows get corrupted (proving
    it isn't inert) -- WITHOUT assuming this must also change the
    aggregate accuracy metric. It's tempting to assume "different rows
    corrupted => different accuracy", but investigation showed this
    synthetic dataset's accuracy is actually structurally deterministic
    per corruption type, independent of row identity: mean-substitution
    repairs (baseline1's strategy for outliers/missing values) can NEVER
    exactly recover a row-specific true value regardless of which row was
    picked (0/3 correct on every seed tested), while its blind
    lowercasing always "matches" category corruption under case-
    insensitive scoring (6/6 correct on every seed tested). This is a
    genuine property of pairing a highly regular synthetic dataset with
    these specific repair/scoring choices -- not a bug in seed handling,
    and itself a real argument for why real, irregular datasets
    (scripts/fetch_datasets.py) matter for producing meaningfully varying
    results across scenarios.
    """
    from evaluation.run_evaluation import build_benchmark_scenario

    corrupted_row_sets = []
    for seed in [1, 2, 3, 4, 5]:
        _, ground_truths = build_benchmark_scenario(seed=seed)
        outlier_gt = next(gt for gt in ground_truths if gt["corruption_type"] == "outlier")
        corrupted_row_sets.append(frozenset(outlier_gt["true_values"].keys()))

    assert len(set(corrupted_row_sets)) > 1


def test_multi_seed_evaluation_reports_std_as_zero_for_a_single_seed():
    results = run_multi_seed_evaluation(seeds=[42])
    assert results["aggregated"]["proposed_f1"]["std"] == 0.0