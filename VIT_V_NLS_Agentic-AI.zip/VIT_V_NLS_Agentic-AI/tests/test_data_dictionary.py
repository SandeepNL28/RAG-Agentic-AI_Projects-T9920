"""
Tests for app/core/data_dictionary.py -- the heuristic rule inference
that replaced the old hard-coded "only works for 'age'" behavior.
"""

from app.core.data_dictionary import infer_rule_for_column


def test_infers_age_rule_from_column_name():
    assert infer_rule_for_column("age") == {"min": 0, "max": 120}
    assert infer_rule_for_column("customer_age") == {"min": 0, "max": 120}


def test_infers_percentage_rule_from_column_name():
    assert infer_rule_for_column("discount_rate") == {"min": 0, "max": 100}
    assert infer_rule_for_column("completion_pct") == {"min": 0, "max": 100}


def test_infers_non_negative_rule_for_money_like_columns():
    assert infer_rule_for_column("annual_income") == {"min": 0}
    assert infer_rule_for_column("unit_price") == {"min": 0}
    assert infer_rule_for_column("account_balance") == {"min": 0}


def test_returns_none_for_unrecognized_column_names():
    assert infer_rule_for_column("favorite_color") is None
    assert infer_rule_for_column("notes") is None


def test_explicit_rules_take_priority_over_heuristics():
    explicit = {"age": {"min": 18, "max": 65}}  # a stricter, custom rule
    assert infer_rule_for_column("age", explicit_rules=explicit) == {"min": 18, "max": 65}


def test_handles_empty_or_none_column_name_gracefully():
    assert infer_rule_for_column("") is None
    assert infer_rule_for_column(None) is None

def test_does_not_falsely_match_substrings_inside_unrelated_words():
    """
    Regression test for a real bug found on the Adult Income dataset:
    the original regex-based matching used re.search(), which matched
    "count" as a substring inside "native-country" ("nativeCOUNTry"),
    incorrectly applying a numeric {"min": 0} rule to a text column and
    crashing constraint_check() with "Invalid comparison between
    dtype=str and int". Token-based exact matching fixes this.
    """
    assert infer_rule_for_column("native-country") is None
    assert infer_rule_for_column("marital-status") is None
    assert infer_rule_for_column("country") is None


def test_still_matches_compound_column_names_correctly():
    """
    Confirms the fix didn't overcorrect: keywords must still match when
    they appear as a genuine whole token separated by underscore/hyphen.
    """
    assert infer_rule_for_column("item_count") == {"min": 0}
    assert infer_rule_for_column("stock-quantity") == {"min": 0}