"""
Tests for the Diagnosis Agent.

We CANNOT call a real LLM in this environment (no Ollama server available
here) -- so call_llm is mocked with monkeypatch to return a fixed,
realistic JSON response. This proves the agent's own logic (prompt
building, parsing the response, triggering evidence-gathering) is correct,
independent of what a real model would say. This is standard practice for
testing LLM-dependent code.

Once you're on your own machine with `ollama serve` running, you can also
run this manually against the REAL model -- see the bottom of this file.
"""

import pandas as pd
import pytest

from app.core.schemas import ForensicsState, DetectedIssue
from app.agents import diagnosis_agent


@pytest.fixture
def state_with_age_outlier():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-1",
        column="age",
        issue_type="outlier",
        severity="high",
        affected_rows=[3],
        raw_observation="1 value(s) exceed 2.5 standard deviations from the mean.",
    ))
    state.current_issue_id = "issue-1"
    return state


def test_diagnosis_agent_parses_mocked_llm_response_into_hypothesis(monkeypatch, state_with_age_outlier):
    mocked_response = {
        "explanation": "Likely a data-entry typo: an extra digit was probably added (24 -> 240).",
        "requires_evidence": ["data_dictionary_rule"],
    }
    monkeypatch.setattr(diagnosis_agent, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diagnosis_agent.run(state_with_age_outlier)

    assert len(result_state.hypotheses) == 1
    hyp = result_state.hypotheses[0]
    assert hyp.issue_id == "issue-1"
    assert "typo" in hyp.explanation.lower()
    assert hyp.requires_evidence == ["data_dictionary_rule"]


def test_diagnosis_agent_gathers_evidence_after_hypothesis(monkeypatch, state_with_age_outlier):
    mocked_response = {
        "explanation": "Likely a typo.",
        "requires_evidence": ["data_dictionary_rule"],
    }
    monkeypatch.setattr(diagnosis_agent, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diagnosis_agent.run(state_with_age_outlier)

    assert len(result_state.evidence) == 1
    ev = result_state.evidence[0]
    assert ev.source == "data_dictionary_rule"
    assert ev.supports_hypothesis is True  # age=240 genuinely violates the 0-120 rule


def test_data_dictionary_evidence_now_works_for_non_age_columns(monkeypatch):
    """
    This is the key regression test for the generalization: the OLD
    version of _gather_evidence only ever produced data_dictionary_rule
    evidence for a column literally named 'age'. This confirms it now
    works for any column the heuristic data dictionary recognizes.
    """
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-income", column="annual_income", issue_type="outlier",
        severity="high", affected_rows=[0], raw_observation="Income looks unusual.",
    ))
    state.current_issue_id = "issue-income"

    mocked_response = {"explanation": "Possibly a negative or corrupted income value.", "requires_evidence": ["data_dictionary_rule"]}
    monkeypatch.setattr(diagnosis_agent, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diagnosis_agent.run(state)

    assert len(result_state.evidence) == 1
    assert result_state.evidence[0].source == "data_dictionary_rule"


def test_pattern_frequency_evidence_detects_a_dominant_spelling(monkeypatch):
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-city", column="city", issue_type="category_inconsistency",
        severity="low", affected_rows=[0, 5, 8], raw_observation="New York spelling variants.",
    ))
    state.current_issue_id = "issue-city"

    mocked_response = {"explanation": "Same city, inconsistent capitalization.", "requires_evidence": ["pattern_frequency"]}
    monkeypatch.setattr(diagnosis_agent, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diagnosis_agent.run(state)

    assert len(result_state.evidence) == 1
    assert result_state.evidence[0].source == "pattern_frequency"
    # In sample_customers.csv, "New York" appears alongside "new york" and
    # "NEW YORK" -- exactly 1 occurrence each, so there is NO dominant
    # spelling (each variant is a 1/3 minority), and this should NOT
    # support the hypothesis under the >=50% majority rule.
    assert result_state.evidence[0].supports_hypothesis is False


def test_related_column_consistency_evidence_flags_isolated_outlier(monkeypatch):
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-age", column="age", issue_type="outlier",
        severity="high", affected_rows=[3], raw_observation="Age=240 is extreme.",
    ))
    state.current_issue_id = "issue-age"

    mocked_response = {"explanation": "Likely a typo.", "requires_evidence": ["related_column_consistency"]}
    monkeypatch.setattr(diagnosis_agent, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diagnosis_agent.run(state)

    assert len(result_state.evidence) == 1
    assert result_state.evidence[0].source == "related_column_consistency"
    # Row 3's annual_income (65000) is unremarkable compared to the rest
    # of the column, so this should support the "isolated error" hypothesis.
    assert result_state.evidence[0].supports_hypothesis is True


def test_multiple_evidence_types_can_be_gathered_together(monkeypatch):
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-age", column="age", issue_type="outlier",
        severity="high", affected_rows=[3], raw_observation="Age=240 is extreme.",
    ))
    state.current_issue_id = "issue-age"

    mocked_response = {
        "explanation": "Likely a typo.",
        "requires_evidence": ["data_dictionary_rule", "statistical_distribution", "related_column_consistency"],
    }
    monkeypatch.setattr(diagnosis_agent, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diagnosis_agent.run(state)

    sources = {e.source for e in result_state.evidence}
    assert sources == {"data_dictionary_rule", "statistical_distribution", "related_column_consistency"}


def test_data_dictionary_evidence_skips_non_numeric_columns_even_if_name_matches(monkeypatch):
    """
    Defensive dtype check regression test: even if a column's NAME
    heuristically matches a data-dictionary pattern, a min/max rule must
    never be applied to a non-numeric column.
    """
    import pandas as pd
    from app.core.schemas import ForensicsState, DetectedIssue
    from app.agents import diagnosis_agent as diag_module

    df = pd.DataFrame({"age_group": ["18-25", "26-35", "18-25", "36-45"]})
    df.to_csv("sample_data/_temp_age_group_test.csv", index=False)

    state = ForensicsState(dataset_path="sample_data/_temp_age_group_test.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-agegroup", column="age_group", issue_type="category_inconsistency",
        severity="low", affected_rows=[0, 2], raw_observation="Some grouping issue.",
    ))
    state.current_issue_id = "issue-agegroup"

    mocked_response = {"explanation": "test", "requires_evidence": ["data_dictionary_rule"]}
    monkeypatch.setattr(diag_module, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diag_module.run(state)
    assert result_state.evidence == []

    import os
    os.remove("sample_data/_temp_age_group_test.csv")