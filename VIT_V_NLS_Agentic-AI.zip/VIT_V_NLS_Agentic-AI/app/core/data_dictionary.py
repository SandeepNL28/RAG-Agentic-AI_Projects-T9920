"""
Heuristic data dictionary. In a real deployment, a proper data dictionary
would be supplied alongside a dataset (a JSON/YAML file with explicit
column rules). Since most real datasets won't have one, this module
infers reasonable constraints from common column-name patterns as a
sensible default -- and any explicit rules passed in always take priority
over the heuristics.

MATCHING STRATEGY (a real bug fixed here, worth understanding): the first
version used regex substring search (re.search), which matched keywords
ANYWHERE inside a column name -- "count" (meant to catch "item_count")
matched inside "native-country" ("nativeCOUNTry"), incorrectly applying a
numeric rule to a text column and crashing downstream. A naive fix using
regex word boundaries (\\b) was considered and rejected: \\b treats
underscore as a word character, so \\bage\\b would fail to match
"customer_age" (breaking the exact "compound column name" case this
heuristic exists for). The actual fix: split the column name into tokens
on any non-alphanumeric separator (underscore, hyphen, space, etc.) and
require an EXACT match against a whole token -- this correctly matches
"age" inside "customer_age" (separated by "_") while correctly rejecting
"count" inside "country" (no separator, same word).
"""

import re

# Each entry: (set of exact keyword tokens, rule dict)
_HEURISTIC_KEYWORD_RULES: list[tuple[set[str], dict]] = [
    ({"age"}, {"min": 0, "max": 120}),
    ({"percent", "pct", "rate"}, {"min": 0, "max": 100}),
    ({"income", "salary", "price", "amount", "cost", "revenue", "balance"}, {"min": 0}),
    ({"quantity", "qty", "count", "stock"}, {"min": 0}),
    ({"year"}, {"min": 1900, "max": 2100}),
]


def _tokenize(column_name: str) -> set[str]:
    """Splits a column name into lowercase tokens on any non-alphanumeric
    separator -- handles snake_case, kebab-case, and space-separated names."""
    return {t for t in re.split(r"[^a-z0-9]+", column_name.lower()) if t}


def infer_rule_for_column(column_name: str, explicit_rules: dict | None = None) -> dict | None:
    """
    Returns a constraint rule (e.g. {"min": 0, "max": 120}) for the given
    column name, preferring an explicit override if one is provided,
    falling back to a heuristic match on the column name's tokens, or
    None if no rule applies.
    """
    if explicit_rules and column_name in explicit_rules:
        return explicit_rules[column_name]

    if not column_name:
        return None

    tokens = _tokenize(column_name)
    for keywords, rule in _HEURISTIC_KEYWORD_RULES:
        if tokens & keywords:  # any overlap between column's tokens and this rule's keywords
            return rule

    return None