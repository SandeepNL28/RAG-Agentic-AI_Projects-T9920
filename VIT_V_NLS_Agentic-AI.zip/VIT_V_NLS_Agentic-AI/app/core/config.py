"""
Central configuration for the Autonomous Dataset Forensics Agent.
Keeping all tunable values here means nothing is hard-coded inside
the agent logic itself.
"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # LLM settings
    ollama_model: str = "qwen3:4b"
    ollama_base_url: str = "http://localhost:11434"
    ollama_timeout_seconds: int = 300

    # Qwen3 is a "thinking" model: by default it writes a long hidden
    # reasoning trace before answering, which is very slow on CPU.
    # The Diagnosis Agent only needs a short structured JSON answer, and
    # its decisions are gated by deterministic evidence anyway.
    ollama_think: bool = False

    # Hard cap on generated tokens per call. Large enough for a JSON
    # hypothesis, small enough that a runaway generation can't stall a run.
    ollama_num_predict: int = 512

    # How long Ollama keeps the model in RAM after a call, so only the
    # first request of a session pays the cold-load cost.
    ollama_keep_alive: str = "30m"

    # Evidence-gating threshold: minimum confidence (0.0-1.0) required
    # before the Repair Agent is allowed to auto-apply a fix.
    confidence_threshold: float = 0.80

    # Where sandboxed (disposable) dataset copies are written during repair.
    sandbox_dir: str = "./_sandbox"

    # Where the audit trail database lives.
    audit_db_path: str = "./audit_trail.sqlite"

    # Where run records (status, results) are persisted, so run history
    # survives a server restart.
    run_registry_db_path: str = "./run_registry.sqlite"

    # Outlier detection sensitivity (z-score threshold).
    # NOTE: 2.5 rather than the textbook 3.0. On small datasets, a single
    # extreme outlier inflates the standard deviation enough to partially
    # mask its own z-score. 2.5 is a more practical default for
    # small/medium datasets.
    outlier_z_threshold: float = 2.5


settings = Settings()