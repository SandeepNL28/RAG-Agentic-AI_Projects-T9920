"""
The evidence-gating math. This is the core safety mechanism of the whole
project: a repair is only attempted once accumulated evidence crosses
settings.confidence_threshold.

Weights are a reasonable, literature-informed starting point (an explicit
documented rule is stronger evidence than a generic statistical pattern) --
NOT derived from a formal proof. They are meant to be tuned experimentally
via ablation studies once the benchmark evaluation exists.
"""

from app.core.schemas import Evidence

SOURCE_WEIGHTS = {
    "data_dictionary_rule": 0.45,        # strongest: an explicit documented rule
    "related_column_consistency": 0.30,
    "statistical_distribution": 0.15,
    "pattern_frequency": 0.10,           # weakest: just "this pattern is common"
    # PROOF, not statistics: a dry-run of a deterministic format repair that
    # verified no rows lost, no new nulls, and all numeric cells parse.
    # Set above the 0.80 gate by design. Because only SUPPORTING evidence is
    # summed, a failed verification contributes 0.0 -> the repair is gated out.
    # Tune/ablate this like any other weight.
    "repair_verification": 0.95,
}

DEFAULT_UNKNOWN_SOURCE_WEIGHT = 0.05


def estimate_confidence(evidence_list: list[Evidence]) -> float:
    """
    Sums the weights of every piece of evidence that supports the current
    hypothesis, capped at 1.0. Evidence that contradicts the hypothesis
    does not currently subtract from the score (see the viva-prep doc's
    Section 5 for why this is a known, documented limitation and an
    obvious future improvement).

    Rounded to 6 decimal places: summing floats like 0.45 + 0.15 + 0.30
    does not always land exactly on 0.90 in binary floating point (it can
    produce 0.8999999999999999 depending on summation order) -- harmless
    for display, but a real risk at the confidence_threshold comparison
    boundary, where a value that SHOULD equal the threshold exactly could
    incorrectly fall just short of it due to float imprecision. Rounding
    here, at the source, is more robust than patching every comparison
    site individually.
    """
    supporting = [e for e in evidence_list if e.supports_hypothesis]
    score = sum(SOURCE_WEIGHTS.get(e.source, DEFAULT_UNKNOWN_SOURCE_WEIGHT) for e in supporting)
    return round(min(score, 1.0), 6)