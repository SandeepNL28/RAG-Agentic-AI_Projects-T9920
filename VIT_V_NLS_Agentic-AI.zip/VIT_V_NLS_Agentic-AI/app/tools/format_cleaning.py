"""
app/tools/format_cleaning.py

Deterministic detection and repair of *format noise* -- the most common
real-world data problem and one the original toolset had no detector for:

  - footnote markers glued to values        7[2]   [b]   Tour Name ‡[21][a]
  - trailing symbols                        The Eras Tour †
  - numbers stored as text                  "$780,000,000"   "1,234"
  - year ranges in one cell                 2023-2024

Why this fits the evidence-gating thesis: unlike imputation or outlier
"correction", these repairs are VERIFIABLE. We can prove, before and after,
that (a) no rows were lost, (b) no non-null cell became null, and (c) every
cell in a numeric target column parses. That proof is the evidence.

Repairs that would ERASE information (a column made only of footnote
markers, e.g. a "Ref." column) are never marked auto-repairable.
"""

from __future__ import annotations

import re
from typing import Any

import numpy as np
import pandas as pd

# [1]  [12]  [a]  -- digits or a single letter only, so real bracketed text
# like "[Intro]" is NOT treated as a footnote.
_FOOTNOTE = re.compile(r"\[(?:\d+|[a-zA-Z])\]")
_TRAILING_SYMBOLS = re.compile(r"[\s\u2020\u2021*\u00a7\u00b6]+$")  # dagger, double dagger, *, section, pilcrow
_NUMERIC_JUNK = re.compile(r"[$\u20ac\u00a3\u20b9,\s]")
_CURRENCY_OR_THOUSANDS = re.compile(r"[$\u20ac\u00a3\u20b9]|\d,\d")
_DASH = re.compile(r"[\u2013\u2014-]")
_YEAR_RANGE = re.compile(r"^\s*(\d{4})\s*(?:[\u2013\u2014-]\s*(\d{4}))?\s*$")


def _is_text_col(series: pd.Series) -> bool:
    return pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)


def strip_annotations(value: Any) -> Any:
    """Remove footnote markers and trailing symbols. NaN passes through."""
    if pd.isna(value):
        return value
    s = _FOOTNOTE.sub("", str(value))
    s = _TRAILING_SYMBOLS.sub("", s)
    return s.strip()


_SYMBOLS = "\u2020\u2021*\u00a7\u00b6"


def _has_annotation(value: Any) -> bool:
    if pd.isna(value):
        return False
    text = str(value).rstrip()
    return bool(_FOOTNOTE.search(text)) or (len(text) > 0 and text[-1] in _SYMBOLS)


def _to_numeric(cleaned: pd.Series) -> pd.Series:
    stripped = cleaned.map(lambda v: v if pd.isna(v) else _NUMERIC_JUNK.sub("", str(v)))
    return pd.to_numeric(stripped, errors="coerce")


def _finalize_numeric(nums: pd.Series) -> pd.Series:
    """Nullable Int64 if every non-null value is whole, else float64.
    (Explicit dtype handling -- avoids the int64/float64 coercion bug.)"""
    non_null = nums.dropna()
    if len(non_null) and (non_null % 1 == 0).all():
        return nums.astype("Int64")
    return nums.astype("float64")


# --------------------------------------------------------------------------
# Detection
# --------------------------------------------------------------------------
def detect_format_issues(df: pd.DataFrame) -> list[dict]:
    """Inspect every text column; return one issue dict per affected column."""
    issues: list[dict] = []
    for col in df.columns:
        series = df[col]
        if not _is_text_col(series):
            continue
        cells = series.dropna()
        if cells.empty:
            continue

        annotated = cells.map(_has_annotation)
        cleaned = cells.map(strip_annotations)
        parsed = _to_numeric(cleaned)
        parse_rate = float(parsed.notna().mean())
        has_currency_or_commas = cells.astype(str).map(lambda v: bool(_CURRENCY_OR_THOUSANDS.search(v))).any()

        # Pure numeric-as-text (no annotations), e.g. "$13,928,571"
        numeric_as_text = parse_rate == 1.0 and (has_currency_or_commas or annotated.any())

        if not annotated.any() and not numeric_as_text:
            continue

        # A cell that is ONLY a marker would become "" -> information erased.
        erases_info = bool((cleaned == "").any())

        if erases_info:
            issue_type, auto_ok, target = "annotation_only", False, "text"
        elif numeric_as_text:
            issue_type, auto_ok, target = (
                "numeric_stored_as_text" if not annotated.any() else "annotated_numeric"
            ), True, "numeric"
        else:
            issue_type, auto_ok, target = "annotation_noise", True, "text"

        affected_mask = annotated | (numeric_as_text & cells.notna())
        affected_idx = list(cells.index[affected_mask])

        def _after(idx):
            if target == "text":
                return str(cleaned.loc[idx])
            v = parsed.loc[idx]
            return str(int(v)) if float(v).is_integer() else str(v)

        # Show an example cell that ACTUALLY changes (never "'1' -> '1'").
        ex_idx = next((i for i in affected_idx if str(series.loc[i]) != _after(i)),
                      affected_idx[0] if affected_idx else cells.index[0])

        issues.append({
            "column": col,
            "issue_type": issue_type,
            "target": target,
            "auto_repairable": auto_ok,
            "affected_count": len(affected_idx),
            "affected_fraction": round(len(affected_idx) / len(series), 3),
            "parse_rate_after_cleaning": round(parse_rate, 3),
            "example_before": str(series.loc[ex_idx]),
            "example_after": _after(ex_idx),
            "row_indices": affected_idx,
        })
    return issues


# --------------------------------------------------------------------------
# Repair + verification
# --------------------------------------------------------------------------
def apply_format_repair(df: pd.DataFrame, issue: dict) -> pd.DataFrame:
    """Return a NEW dataframe with the issue's column repaired."""
    if not issue.get("auto_repairable"):
        raise ValueError(f"Issue on {issue['column']!r} is not auto-repairable.")
    out = df.copy()
    col = issue["column"]
    cleaned = out[col].map(strip_annotations)
    out[col] = _finalize_numeric(_to_numeric(cleaned)) if issue["target"] == "numeric" else cleaned
    return out


def verify_format_repair(before: pd.DataFrame, after: pd.DataFrame, issue: dict) -> dict:
    """Evidence for the confidence score: did the repair provably lose nothing?"""
    col = issue["column"]
    checks = {
        "row_count_preserved": len(before) == len(after),
        "no_new_nulls": int(after[col].isna().sum()) == int(before[col].isna().sum()),
        "other_columns_untouched": before.drop(columns=[col]).equals(after.drop(columns=[col])),
    }
    if issue["target"] == "numeric":
        checks["all_cells_numeric"] = bool(
            pd.api.types.is_numeric_dtype(after[col])
        )
    return {"checks": checks, "verification_passed": all(checks.values())}


def split_year_ranges(df: pd.DataFrame, column: str) -> pd.DataFrame:
    """ADDITIVE: adds '<col> Start' / '<col> End' Int64 columns; keeps original."""
    out = df.copy()
    starts, ends = [], []
    for v in out[column]:
        m = _YEAR_RANGE.match(str(v)) if pd.notna(v) else None
        starts.append(int(m.group(1)) if m else pd.NA)
        ends.append(int(m.group(2) or m.group(1)) if m else pd.NA)
    base = column.replace("(s)", "").strip()
    out[f"{base} Start"] = pd.array(starts, dtype="Int64")
    out[f"{base} End"] = pd.array(ends, dtype="Int64")
    return out


def looks_like_year_range(series: pd.Series) -> bool:
    cells = series.dropna()
    return len(cells) > 0 and bool(cells.astype(str).map(lambda s: bool(_YEAR_RANGE.match(s))).all()) \
        and bool(cells.astype(str).map(lambda v: bool(_DASH.search(v))).any())


def find_format_issue(df: pd.DataFrame, column: str) -> dict | None:
    """Re-detect the format issue for ONE column (used by the repair agent,
    which re-detects on the sandbox copy rather than trusting stale state)."""
    return next((i for i in detect_format_issues(df) if i["column"] == column), None)


def _as_list(series: pd.Series) -> list:
    return [None if pd.isna(v) else str(v) for v in series]


def verify_cell_repair_against_original(
    original_df: pd.DataFrame, repaired_df: pd.DataFrame, column: str, target: str
) -> dict:
    """Independent post-hoc check used by the Validation Agent: recompute what the
    column SHOULD be from the untouched original, and compare to the sandbox file.
    Cumulative-safe: does not assume other columns are untouched."""
    checks = {"row_count_preserved": len(original_df) == len(repaired_df),
              "column_present": column in repaired_df.columns}
    if not all(checks.values()):
        return {"checks": checks, "verification_passed": False}

    cleaned = original_df[column].map(strip_annotations)
    if target == "numeric":
        expected = _to_numeric(cleaned).astype("float64").to_numpy()
        actual = pd.to_numeric(repaired_df[column], errors="coerce").astype("float64").to_numpy()
        checks["values_match_expected"] = bool(np.array_equal(expected, actual, equal_nan=True))
        checks["no_new_nulls"] = int(np.isnan(actual).sum()) == int(original_df[column].isna().sum())
    else:
        checks["values_match_expected"] = _as_list(cleaned) == _as_list(repaired_df[column])
        checks["no_new_nulls"] = int(repaired_df[column].isna().sum()) == int(original_df[column].isna().sum())
    return {"checks": checks, "verification_passed": all(checks.values())}


def verify_header_repair(original_df: pd.DataFrame, repaired_df: pd.DataFrame) -> dict:
    expected, _ = normalize_column_names(original_df)
    checks = {
        "row_count_preserved": len(original_df) == len(repaired_df),
        "column_count_preserved": len(original_df.columns) == len(repaired_df.columns),
        "headers_normalized": list(repaired_df.columns) == list(expected.columns),
        "no_header_collisions": len(set(expected.columns)) == len(expected.columns),
    }
    return {"checks": checks, "verification_passed": all(checks.values())}


def normalize_column_names(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Replace non-breaking/odd whitespace in headers with a single space.
    Returns (df, {old_name: new_name}) so the rename is auditable."""
    mapping = {}
    for c in df.columns:
        new = re.sub(r"\s+", " ", str(c)).strip()  # \s matches \xa0 in Python 3
        if new != c:
            mapping[c] = new
    return (df.rename(columns=mapping) if mapping else df.copy()), mapping


# --------------------------------------------------------------------------
# Convenience: run the whole thing on a dataframe (used by the CLI below)
# --------------------------------------------------------------------------
def clean_dataframe(df: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    """Detect -> repair -> verify. Returns (cleaned_df, per-issue decision log).
    Only repairs that pass verification are kept; the rest are abstained on."""
    current, renames = normalize_column_names(df)
    log: list[dict] = []
    if renames:
        log.append({"column": ", ".join(repr(k) for k in renames), "issue_type": "header_whitespace",
                    "decision": "AUTO_REPAIRED",
                    "reason": f"Normalized hidden whitespace in headers: {renames}"})
    for issue in detect_format_issues(current):
        entry = {k: v for k, v in issue.items() if k != "row_indices"}
        if not issue["auto_repairable"]:
            entry.update(decision="HUMAN_REVIEW",
                         reason="Cleaning would erase cell contents (column is only annotations).")
        else:
            candidate = apply_format_repair(current, issue)
            ev = verify_format_repair(current, candidate, issue)
            entry["verification"] = ev["checks"]
            if ev["verification_passed"]:
                current = candidate
                entry.update(decision="AUTO_REPAIRED", reason="All verification checks passed.")
            else:
                entry.update(decision="HUMAN_REVIEW", reason="Verification failed; repair discarded.")
        log.append(entry)

    for col in current.columns:
        if _is_text_col(current[col]) and looks_like_year_range(current[col]):
            current = split_year_ranges(current, col)
            log.append({"column": col, "issue_type": "year_range_in_one_cell",
                        "decision": "AUTO_REPAIRED (additive)",
                        "reason": "Added Start/End year columns; original column kept."})
    return current, log


if __name__ == "__main__":
    import sys
    src, dst = sys.argv[1], sys.argv[2]
    cleaned, decisions = clean_dataframe(pd.read_csv(src))
    cleaned.to_csv(dst, index=False)
    for d in decisions:
        print(f"{d['decision']:<26} {d['column']:<36} {d.get('issue_type')}")