"""
Repair Agent -- proposes a fix and estimates confidence, but only ever
applies it to a SANDBOX copy, and only if confidence clears
settings.confidence_threshold. No LLM is used here -- the repair action
itself is deterministic; only the earlier Diagnosis step used the LLM.

DESIGN DECISION ON OUTLIERS (empirically tested, then reverted):
An automatic outlier-repair path (replacing the flagged value with the
column median) was built and evaluated end-to-end against the benchmark's
tracked ground truth. The result was clear: median substitution uses ONE
value for every corrupted row, while each row's true original value was
different (e.g. true ages of 35, 29, 37 all got "corrected" to the same
median of 42). This is not a bug -- it's a structural limitation of any
single-statistic substitution strategy: it can restore plausibility
(bring a value back into a valid range) but cannot recover a row-specific
true value without additional correlated information the system doesn't
have (e.g. a date-of-birth column to derive age exactly). Measured Safe
Repair Rate for this path was 0.0. Based on this evidence, outliers are
deliberately kept human-review-only -- see app/tools/repair.py's
correct_outlier_value() for the still-available, still-tested tool this
decision applies to, kept for future use if a row-specific correction
strategy is ever developed (e.g. cross-referencing a related column).

FORMAT NOISE (new): unlike outliers, format repairs (strip footnote markers,
parse "$1,234" to 1234, normalize header whitespace) are VERIFIABLE -- the
Diagnosis Agent dry-runs the repair and proves nothing was lost. Their
evidence is scored via the "repair_verification" weight in scoring.py.
"""

import pandas as pd

from app.core.config import settings
from app.core.schemas import ForensicsState, RepairProposal, DetectedIssue, Hypothesis
from app.evidence.scoring import estimate_confidence
from app.sandbox import sandbox_manager
from app.audit.audit_logger import log, AuditEntry
from app.tools import repair as repair_tools
from app.tools import format_cleaning
from app.tools.quality_analysis import category_consistency_analysis

# Maps an issue_type to which repair tool handles it. "outlier" and
# "constraint_violation" intentionally have no automatic action -- see
# the module docstring for why outliers specifically were tested and
# then deliberately reverted to always require human review.
_ACTION_FOR_ISSUE_TYPE = {
    "missing_value": "impute_missing_values",
    "category_inconsistency": "normalize_categories",
    "date_format": "standardize_dates",
    "duplicate": "remove_exact_duplicates",
    "outlier": "manual_value_correction",
    "type_error": "correct_data_types",
    "constraint_violation": "manual_value_correction",
    "format_noise": "clean_format_noise",
}


def _get_issue(state: ForensicsState, issue_id: str) -> DetectedIssue:
    return next(i for i in state.issues if i.issue_id == issue_id)


def _get_hypothesis(state: ForensicsState, issue_id: str) -> Hypothesis | None:
    return next((h for h in state.hypotheses if h.issue_id == issue_id), None)


def _apply_repair(action: str, df_path: str, issue: DetectedIssue) -> bool:
    """Applies the chosen repair tool to the sandboxed file in place.
    Returns True only if a repair was actually written."""
    df = pd.read_csv(df_path)

    if action == "impute_missing_values":
        df = repair_tools.impute_missing_values(df, issue.column, strategy="median")
    elif action == "normalize_categories":
        detection = category_consistency_analysis(df, issue.column)
        df = repair_tools.normalize_categories(df, issue.column, detection["inconsistent_groups"])
    elif action == "standardize_dates":
        df = repair_tools.standardize_dates(df, issue.column)
    elif action == "remove_exact_duplicates":
        df = repair_tools.remove_exact_duplicates(df)
    elif action == "clean_format_noise":
        if issue.column is None:  # header issue
            df, renames = format_cleaning.normalize_column_names(df)
            if not renames:
                return False
        else:
            # Re-detect on the SANDBOX copy rather than trusting stale state.
            info = format_cleaning.find_format_issue(df, issue.column)
            if info is None or not info["auto_repairable"]:
                return False
            df = format_cleaning.apply_format_repair(df, info)
    else:
        return False  # no safe automatic action -- leave the sandbox file unchanged

    df.to_csv(df_path, index=False)
    return True


def run(state: ForensicsState) -> ForensicsState:
    issue = _get_issue(state, state.current_issue_id)
    hypothesis = _get_hypothesis(state, issue.issue_id)
    evidence_for_issue = [e for e in state.evidence if e.issue_id == issue.issue_id]

    confidence = estimate_confidence(evidence_for_issue)
    action = _ACTION_FOR_ISSUE_TYPE.get(issue.issue_type, "manual_value_correction")

    proposal = RepairProposal(
        issue_id=issue.issue_id,
        action=action,
        confidence=confidence,
        rationale=hypothesis.explanation if hypothesis else "No hypothesis available.",
    )
    state.proposals.append(proposal)

    should_repair = confidence >= settings.confidence_threshold and action != "manual_value_correction"

    if should_repair:
        if state.sandbox_path is None:
            state.sandbox_path = sandbox_manager.create_sandbox(state.dataset_path)
        else:
            # Snapshot so a failed validation undoes ONLY this repair.
            sandbox_manager.snapshot_sandbox(state.sandbox_path)
        proposal.applied = _apply_repair(action, state.sandbox_path, issue)
        if not proposal.applied:
            sandbox_manager.drop_snapshot(state.sandbox_path)
        if proposal.applied:
            repair_note = f"Confidence {confidence:.2f} cleared threshold -- repair applied to sandbox."
        else:
            repair_note = f"Confidence {confidence:.2f} cleared threshold, but the repair tool made no change."
    else:
        repair_note = f"Confidence {confidence:.2f} did not clear threshold -- no repair applied."

    log(AuditEntry(
        run_id=state.run_id,
        issue_id=issue.issue_id,
        step="repair",
        tool_used=action,
        observation=f"Proposed action: {action} (confidence={confidence:.2f}).",
        reasoning_summary=f"{proposal.rationale} {repair_note}",
    ))

    return state