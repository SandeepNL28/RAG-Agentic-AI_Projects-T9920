"""
Investigation Agent -- gathers raw facts. No LLM is used here at all;
this node purely calls the deterministic tools built earlier and converts
their output into DetectedIssue records.

FORMAT NOISE (new): footnote markers, symbols, numbers stored as text and
hidden-whitespace headers are detected by app/tools/format_cleaning.py.
These issues are appended AFTER all the other detectors, and the header
issue is appended LAST, on purpose: format repairs change column dtypes and
column names, so they must not run before repairs that still refer to the
original dtypes/names.
"""

import uuid
import pandas as pd

from app.core.schemas import ForensicsState, DetectedIssue
from app.audit.audit_logger import log, AuditEntry
from app.tools.quality_analysis import (
    missing_value_analysis,
    outlier_detection,
    category_consistency_analysis,
    date_format_consistency,
    duplicate_analysis,
)
from app.tools.format_cleaning import detect_format_issues, normalize_column_names


def _new_id() -> str:
    return str(uuid.uuid4())


def run(state: ForensicsState) -> ForensicsState:
    df = pd.read_csv(state.dataset_path)

    # --- Missing values ---
    missing = missing_value_analysis(df)
    for column, info in missing.items():
        state.issues.append(DetectedIssue(
            issue_id=_new_id(),
            column=column,
            issue_type="missing_value",
            severity="medium" if info["missing_pct"] < 20 else "high",
            affected_rows=info["affected_rows"],
            raw_observation=f"{info['missing_count']} missing value(s) ({info['missing_pct']}%).",
        ))

    # --- Outliers (numeric columns only) ---
    for column in df.select_dtypes(include="number").columns:
        result = outlier_detection(df, column)
        if result["flagged_rows"]:
            state.issues.append(DetectedIssue(
                issue_id=_new_id(),
                column=column,
                issue_type="outlier",
                severity="high",
                affected_rows=result["flagged_rows"],
                raw_observation=result["summary"],
            ))

    # --- Category inconsistencies (text/string columns only) ---
    for column in df.columns:
        if pd.api.types.is_string_dtype(df[column]):
            result = category_consistency_analysis(df, column)
            if result["inconsistent_groups"]:
                state.issues.append(DetectedIssue(
                    issue_id=_new_id(),
                    column=column,
                    issue_type="category_inconsistency",
                    severity="low",
                    affected_rows=result["affected_rows"],
                    raw_observation=result["summary"],
                ))

    # --- Date-format inconsistencies (columns with "date" in the name) ---
    for column in [c for c in df.columns if "date" in c.lower()]:
        result = date_format_consistency(df, column)
        if result["flagged_rows"]:
            state.issues.append(DetectedIssue(
                issue_id=_new_id(),
                column=column,
                issue_type="date_format",
                severity="medium",
                affected_rows=result["flagged_rows"],
                raw_observation=result["summary"],
            ))

    # --- Duplicate rows ---
    dup_result = duplicate_analysis(df)
    if dup_result["duplicate_count"] > 0:
        state.issues.append(DetectedIssue(
            issue_id=_new_id(),
            column=None,
            issue_type="duplicate",
            severity="medium",
            affected_rows=dup_result["duplicate_rows"],
            raw_observation=dup_result["summary"],
        ))

    # --- Format noise, cell level (footnotes, symbols, numbers stored as text) ---
    for fi in detect_format_issues(df):
        state.issues.append(DetectedIssue(
            issue_id=_new_id(),
            column=fi["column"],
            issue_type="format_noise",
            severity="medium",
            affected_rows=[int(i) for i in fi["row_indices"]],
            raw_observation=(
                f"{fi['affected_count']} cell(s) ({fi['affected_fraction'] * 100:.0f}%) carry "
                f"{fi['issue_type'].replace('_', ' ')}; e.g. {fi['example_before']!r} -> "
                f"{fi['example_after']!r}."
            ),
        ))

    # --- Format noise, header level (LAST on purpose). column=None marks a header issue. ---
    _, renames = normalize_column_names(df)
    if renames:
        state.issues.append(DetectedIssue(
            issue_id=_new_id(),
            column=None,
            issue_type="format_noise",
            severity="low",
            affected_rows=[],
            raw_observation=f"{len(renames)} column header(s) contain hidden/odd whitespace: "
                            f"{list(renames.keys())!r}.",
        ))

    log(AuditEntry(
        run_id=state.run_id,
        step="investigate",
        tool_used="missing_value_analysis, outlier_detection, category_consistency_analysis, "
                  "date_format_consistency, duplicate_analysis, format_cleaning.detect_format_issues",
        observation=f"Investigation complete: {len(state.issues)} issue(s) detected across the dataset.",
        reasoning_summary="Ran all deterministic inspection tools across every applicable column.",
    ))

    return state