"""
Validation Agent -- the last checkpoint. Decides accepted / rejected /
rolled_back / human_review for each issue, based on the repair's
confidence AND whether the sandboxed result actually passes validation.
No LLM used here -- this stays fully deterministic on purpose.

FORMAT NOISE (new): these repairs legitimately change column dtypes/names,
so the generic validate_schema() check does not apply. They are instead
validated by RECOMPUTING the expected result from the untouched original
file and comparing it to the sandbox (app/tools/format_cleaning.py).
"""

import pandas as pd

from app.core.config import settings
from app.core.schemas import ForensicsState, ValidationResult, Decision, DetectedIssue, RepairProposal
from app.sandbox import sandbox_manager
from app.audit.audit_logger import log, AuditEntry
from app.tools.validation import validate_schema, check_data_loss
from app.tools import format_cleaning


def _get_issue(state: ForensicsState, issue_id: str) -> DetectedIssue:
    return next(i for i in state.issues if i.issue_id == issue_id)


def _get_proposal(state: ForensicsState, issue_id: str) -> RepairProposal:
    return next(p for p in state.proposals if p.issue_id == issue_id)


def _validate_format_noise(original_df: pd.DataFrame, sandboxed_df: pd.DataFrame, issue: DetectedIssue):
    """Returns (checks, failure_detail)."""
    if issue.column is None:
        result = format_cleaning.verify_header_repair(original_df, sandboxed_df)
    else:
        info = format_cleaning.find_format_issue(original_df, issue.column)
        if info is None:
            return {"issue_rederivable": False}, "Could not re-derive the expected result from the original file."
        result = format_cleaning.verify_cell_repair_against_original(
            original_df, sandboxed_df, issue.column, info["target"]
        )
    return result["checks"], f"Format verification failed: {result['checks']}"


def run(state: ForensicsState) -> ForensicsState:
    issue = _get_issue(state, state.current_issue_id)
    proposal = _get_proposal(state, issue.issue_id)

    # Case 1: confidence never cleared the gate -- Repair Agent abstained.
    if proposal.confidence < settings.confidence_threshold:
        decision = Decision(
            issue_id=issue.issue_id,
            outcome="human_review",
            reason=f"Confidence {proposal.confidence:.2f} below threshold "
                   f"{settings.confidence_threshold:.2f}; evidence insufficient.",
        )
        state.decisions.append(decision)
        log(AuditEntry(
            run_id=state.run_id, issue_id=issue.issue_id, step="validate",
            observation="Repair Agent did not attempt a repair (low confidence).",
            reasoning_summary=decision.reason, decision=decision.outcome,
        ))
        return state

    # Case 2: no repair was actually applied for THIS issue.
    #
    # IMPORTANT: this checks proposal.applied, NOT "state.sandbox_path is
    # None" -- a sandbox may already exist because a DIFFERENT issue's
    # repair created it earlier in the run. Checking only sandbox
    # existence would incorrectly fall through to Case 3 and validate/
    # accept THIS issue as if its own repair had been applied, when the
    # sandbox might only contain some other issue's fix.
    if not proposal.applied:
        decision = Decision(
            issue_id=issue.issue_id,
            outcome="human_review",
            reason="No repair was applied for this issue (either no safe automatic "
                   "action is defined, or this issue's specific gating condition was not met).",
        )
        state.decisions.append(decision)
        log(AuditEntry(
            run_id=state.run_id, issue_id=issue.issue_id, step="validate",
            observation="No repair was applied to the sandbox for this specific issue.",
            reasoning_summary=decision.reason, decision=decision.outcome,
        ))
        return state

    # Case 3: a repair was applied to the sandbox -- validate it.
    original_df = pd.read_csv(state.dataset_path)
    sandboxed_df = pd.read_csv(state.sandbox_path)

    if proposal.action == "clean_format_noise":
        checks, failure_detail = _validate_format_noise(original_df, sandboxed_df, issue)
        tool_used = "format_cleaning verification (recomputed from original)"
    else:
        # duplicate removal legitimately reduces row count; everything else shouldn't
        max_allowed_decrease = len(original_df) - len(sandboxed_df) if proposal.action == "remove_exact_duplicates" else 0

        schema_check = validate_schema(original_df, sandboxed_df)
        loss_check = check_data_loss(original_df, sandboxed_df, max_allowed_row_decrease=max_allowed_decrease)

        checks = {
            "schema_ok": schema_check["passed"],
            "no_unexpected_data_loss": loss_check["passed"],
        }
        failure_detail = f"{schema_check['summary']} / {loss_check['summary']}"
        tool_used = "validate_schema, check_data_loss"

    passed = all(checks.values())

    state.validations.append(ValidationResult(
        issue_id=issue.issue_id,
        passed=passed,
        checks=checks,
        notes="All checks passed." if passed else "One or more validation checks failed.",
    ))

    if passed:
        sandbox_manager.drop_snapshot(state.sandbox_path)
        decision = Decision(
            issue_id=issue.issue_id,
            outcome="accepted",
            reason="Repair validated successfully in sandbox.",
        )
    else:
        # Undo ONLY this repair. Earlier accepted repairs stay in the sandbox.
        # No snapshot means this repair created the sandbox, so nothing else
        # is in it and it can be discarded outright.
        if sandbox_manager.restore_sandbox(state.sandbox_path):
            scope = "this repair undone; earlier accepted repairs preserved"
        else:
            sandbox_manager.discard_sandbox(state.sandbox_path)
            state.sandbox_path = None
            scope = "sandbox discarded (it held only this repair)"
        decision = Decision(
            issue_id=issue.issue_id,
            outcome="rolled_back",
            reason=f"Validation failed ({scope}): {failure_detail}",
        )

    state.decisions.append(decision)
    log(AuditEntry(
        run_id=state.run_id, issue_id=issue.issue_id, step="validate",
        tool_used=tool_used,
        observation=f"Validation checks: {checks}",
        reasoning_summary=decision.reason, decision=decision.outcome,
    ))

    return state