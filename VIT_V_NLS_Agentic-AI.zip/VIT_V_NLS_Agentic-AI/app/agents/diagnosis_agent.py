"""
Diagnosis Agent -- the FIRST place an LLM is used in the whole pipeline.

Given a DetectedIssue, this asks the LLM to propose an explanation
(Hypothesis) and list what evidence would confirm it, in strict JSON.
It then gathers that evidence using the deterministic tools we already
built (never the LLM itself -- evidence-gathering stays deterministic).

EXCEPTION -- format noise: footnote markers / symbols / numbers-stored-as-text /
odd header whitespace have a fully deterministic explanation, so these issues
skip the LLM entirely (saves ~minutes of CPU inference) and go straight to
verification evidence: a dry-run of the repair, checked for data loss.
"""

import pandas as pd

from app.core.schemas import ForensicsState, Hypothesis, Evidence, DetectedIssue
from app.core.data_dictionary import infer_rule_for_column
from app.llm.ollama_client import call_llm
from app.audit.audit_logger import log, AuditEntry
from app.tools.quality_analysis import constraint_check, distribution_analysis, category_consistency_analysis
from app.tools import format_cleaning

DIAGNOSIS_PROMPT = """You are a data-quality diagnostician. Given this detected \
issue, propose the most likely explanation and list what evidence would help \
confirm it.

Respond ONLY with JSON in this exact shape, nothing else:
{{"explanation": "<your explanation>", "requires_evidence": ["<evidence type>", ...]}}

Valid evidence types: "data_dictionary_rule", "related_column_consistency", \
"statistical_distribution", "pattern_frequency"

Issue type: {issue_type}
Column: {column}
Observation: {observation}
"""


def _get_issue(state: ForensicsState, issue_id: str) -> DetectedIssue:
    return next(i for i in state.issues if i.issue_id == issue_id)


def _gather_data_dictionary_evidence(state: ForensicsState, issue: DetectedIssue, df: pd.DataFrame) -> None:
    """
    Generic across ANY column, via app/core/data_dictionary.py's heuristic
    rules -- replaces the earlier version's hard-coded "only works for
    'age'" behavior. Falls back to no evidence if no rule matches the
    column name, rather than silently pretending a rule exists.

    DEFENSIVE DTYPE CHECK: even with data_dictionary.py's tokenized
    keyword matching (itself a fix for a real bug where "count" matched
    inside "native-country"), a min/max rule only makes sense for a
    genuinely numeric column. This guards against any future heuristic
    matching a text column by name coincidence (e.g. a text column
    literally storing age ranges as strings) -- constraint_check() would
    otherwise crash comparing a string Series against a numeric bound.
    """
    rule = infer_rule_for_column(issue.column)
    if rule is None or issue.column not in df.columns:
        return
    if not pd.api.types.is_numeric_dtype(df[issue.column]):
        return

    result = constraint_check(df, {issue.column: rule})
    supports = issue.column in result["violations"]
    state.evidence.append(Evidence(
        issue_id=issue.issue_id,
        source="data_dictionary_rule",
        finding=f"Column '{issue.column}' expected to satisfy {rule} based on its name pattern.",
        supports_hypothesis=supports,
    ))


def _gather_statistical_distribution_evidence(state: ForensicsState, issue: DetectedIssue, df: pd.DataFrame) -> None:
    if not issue.column or issue.column not in df.select_dtypes(include="number").columns:
        return
    dist = distribution_analysis(df, issue.column)
    if dist and "mean" in dist:
        state.evidence.append(Evidence(
            issue_id=issue.issue_id,
            source="statistical_distribution",
            finding=dist["summary"],
            supports_hypothesis=True,
        ))


def _gather_pattern_frequency_evidence(state: ForensicsState, issue: DetectedIssue, df: pd.DataFrame) -> None:
    """
    For category-inconsistency issues, checks whether the flagged
    variant is a clear minority compared to the dominant spelling -- a
    value that appears once against a heavily dominant alternative is
    good (if weak) evidence that it's a formatting slip rather than a
    genuinely different category.
    """
    if issue.issue_type != "category_inconsistency" or not issue.column:
        return

    result = category_consistency_analysis(df, issue.column)
    if not result["inconsistent_groups"]:
        return

    variants = max(result["inconsistent_groups"].values(), key=len)
    counts = {v: int((df[issue.column].astype(str) == v).sum()) for v in variants}
    total = sum(counts.values())
    max_count = max(counts.values())
    is_clear_majority_pattern = total > 0 and (max_count / total) >= 0.5

    state.evidence.append(Evidence(
        issue_id=issue.issue_id,
        source="pattern_frequency",
        finding=f"Spelling variants for this value occur as {counts}; "
                f"{'a dominant spelling exists' if is_clear_majority_pattern else 'no clear dominant spelling'}.",
        supports_hypothesis=is_clear_majority_pattern,
    ))


def _gather_related_column_consistency_evidence(state: ForensicsState, issue: DetectedIssue, df: pd.DataFrame) -> None:
    """
    For outlier issues, checks whether OTHER numeric columns in the same
    affected row(s) also look unusual. If only the flagged column is
    anomalous while the rest of the row looks ordinary, that's weak
    evidence the flagged value is an isolated data-entry error.
    """
    if issue.issue_type != "outlier" or not issue.column or not issue.affected_rows:
        return

    numeric_cols = [c for c in df.select_dtypes(include="number").columns if c != issue.column]
    if not numeric_cols:
        return

    row_idx = issue.affected_rows[0]
    if row_idx not in df.index:
        return

    other_columns_look_normal = True
    for col in numeric_cols:
        series = df[col].dropna()
        if series.empty or series.std() == 0:
            continue
        z = abs((df.loc[row_idx, col] - series.mean()) / series.std())
        if z > 2.5:
            other_columns_look_normal = False
            break

    state.evidence.append(Evidence(
        issue_id=issue.issue_id,
        source="related_column_consistency",
        finding=(
            "Other numeric values in this row look ordinary, suggesting an isolated error."
            if other_columns_look_normal else
            "Other numeric values in this row are also unusual, suggesting this may not be an isolated error."
        ),
        supports_hypothesis=other_columns_look_normal,
    ))


_EVIDENCE_GATHERERS = {
    "data_dictionary_rule": _gather_data_dictionary_evidence,
    "statistical_distribution": _gather_statistical_distribution_evidence,
    "pattern_frequency": _gather_pattern_frequency_evidence,
    "related_column_consistency": _gather_related_column_consistency_evidence,
}


def _gather_evidence(state: ForensicsState, issue: DetectedIssue, evidence_types: list[str]) -> None:
    """
    Deterministically gathers evidence for each requested type, generically
    across any column -- dispatches to the appropriate _gather_*
    function above.
    """
    df = pd.read_csv(state.dataset_path)

    for evidence_type in evidence_types:
        gatherer = _EVIDENCE_GATHERERS.get(evidence_type)
        if gatherer:
            gatherer(state, issue, df)


# ---------------------------------------------------------------------------
# Format-noise path (no LLM)
# ---------------------------------------------------------------------------
def _diagnose_format_noise(state: ForensicsState, issue: DetectedIssue) -> ForensicsState:
    df = pd.read_csv(state.dataset_path)

    if issue.column is None:
        # Header issue: safe only if normalizing creates no duplicate names.
        _, renames = format_cleaning.normalize_column_names(df)
        verification = format_cleaning.verify_header_repair(df, format_cleaning.normalize_column_names(df)[0])
        explanation = (f"{len(renames)} column header(s) contain non-breaking or irregular "
                       f"whitespace, which breaks name-based column lookups.")
        supports = verification["verification_passed"] and bool(renames)
        finding = f"Dry-run header normalization checks: {verification['checks']}."
    else:
        info = format_cleaning.find_format_issue(df, issue.column)
        if info is None:
            explanation = f"No format noise could be re-detected in '{issue.column}'."
            supports, finding = False, "Detector found nothing to repair."
        elif not info["auto_repairable"]:
            explanation = (f"Every flagged cell in '{issue.column}' consists only of annotation "
                           f"markers; stripping them would erase the cell contents.")
            supports = False
            finding = "Repair would destroy information; automatic repair not permitted."
        else:
            candidate = format_cleaning.apply_format_repair(df, info)
            verification = format_cleaning.verify_format_repair(df, candidate, info)
            explanation = (f"'{issue.column}' contains {info['issue_type'].replace('_', ' ')} "
                           f"(e.g. {info['example_before']!r} -> {info['example_after']!r}); "
                           f"cleaning is deterministic and lossless.")
            supports = verification["verification_passed"]
            finding = (f"Dry-run repair checks: {verification['checks']}; "
                       f"parse rate after cleaning {info['parse_rate_after_cleaning']:.0%}.")

    state.hypotheses.append(Hypothesis(
        issue_id=issue.issue_id,
        explanation=explanation,
        requires_evidence=["repair_verification"],
    ))
    state.evidence.append(Evidence(
        issue_id=issue.issue_id,
        source="repair_verification",
        finding=finding,
        supports_hypothesis=supports,
    ))
    log(AuditEntry(
        run_id=state.run_id,
        issue_id=issue.issue_id,
        step="diagnose",
        tool_used="format_cleaning (deterministic, no LLM)",
        observation=issue.raw_observation,
        reasoning_summary=f"{explanation} Verification {'passed' if supports else 'did not pass'}.",
    ))
    return state


def run(state: ForensicsState) -> ForensicsState:
    issue = _get_issue(state, state.current_issue_id)

    if issue.issue_type == "format_noise":
        return _diagnose_format_noise(state, issue)

    prompt = DIAGNOSIS_PROMPT.format(
        issue_type=issue.issue_type,
        column=issue.column,
        observation=issue.raw_observation,
    )
    response = call_llm(prompt, expect_json=True)

    hypothesis = Hypothesis(
        issue_id=issue.issue_id,
        explanation=response["explanation"],
        requires_evidence=response.get("requires_evidence", []),
    )
    state.hypotheses.append(hypothesis)

    _gather_evidence(state, issue, hypothesis.requires_evidence)

    log(AuditEntry(
        run_id=state.run_id,
        issue_id=issue.issue_id,
        step="diagnose",
        tool_used="LLM (Ollama)",
        observation=issue.raw_observation,
        reasoning_summary=hypothesis.explanation,
    ))

    return state