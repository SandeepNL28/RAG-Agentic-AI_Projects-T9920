"""
Thin wrapper around the local Ollama server. This is the ONLY place in the
codebase that talks to the LLM directly -- every agent calls this function
rather than making HTTP requests itself, so the LLM backend can be swapped
later without touching agent logic.

No API key is used anywhere here -- Ollama runs locally and is unauthenticated
by default.

PRODUCTION HARDENING: connection failures are retried (exponential backoff,
3 attempts). READ TIMEOUTS ARE NOT RETRIED: a read timeout means the server
is reachable but still generating, and re-sending the prompt just queues a
duplicate job behind the abandoned one, making things slower.
"""

import json
import logging
import re

import requests
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from app.core.config import settings

logger = logging.getLogger(__name__)


class LLMCallError(Exception):
    """Raised when the local Ollama server can't be reached or returns bad output."""


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    # Only retry genuine connection problems (server down / not started yet).
    # requests.exceptions.ReadTimeout is NOT a ConnectionError, so it fails fast.
    retry=retry_if_exception_type(requests.exceptions.ConnectionError),
    reraise=True,
)
def _post_to_ollama(payload: dict) -> requests.Response:
    response = requests.post(
        f"{settings.ollama_base_url}/api/generate",
        json=payload,
        timeout=settings.ollama_timeout_seconds,
    )
    response.raise_for_status()
    return response


_THINK_BLOCK = re.compile(r"<think>.*?</think>", re.DOTALL)


def call_llm(prompt: str, expect_json: bool = False) -> str | dict:
    """
    Sends a prompt to the local Ollama model and returns its response.

    If expect_json=True, the model is asked to respond in strict JSON and
    the parsed dict is returned -- this is what the Diagnosis Agent uses,
    since its output must be directly consumable by downstream Python code.
    """
    payload = {
        "model": settings.ollama_model,
        "prompt": prompt,
        "stream": False,
        "think": settings.ollama_think,
        "keep_alive": settings.ollama_keep_alive,
        "options": {"num_predict": settings.ollama_num_predict},
    }
    if expect_json:
        payload["format"] = "json"

    try:
        response = _post_to_ollama(payload)
    except requests.exceptions.ReadTimeout as exc:
        logger.error("llm_read_timeout", extra={"timeout": settings.ollama_timeout_seconds})
        raise LLMCallError(
            f"Ollama was reachable but did not finish within "
            f"{settings.ollama_timeout_seconds}s (model: {settings.ollama_model}). "
            f"Try a smaller num_predict, a smaller model, or a larger "
            f"ollama_timeout_seconds."
        ) from exc
    except requests.RequestException as exc:
        logger.error("llm_call_failed", extra={"error": str(exc), "model": settings.ollama_model})
        raise LLMCallError(
            f"Could not reach Ollama at {settings.ollama_base_url} after retries. "
            f"Is 'ollama serve' running? Original error: {exc}"
        ) from exc

    raw_text = response.json().get("response", "")
    # Safety net: if an older Ollama ignores "think": false and inlines the
    # reasoning, strip it so it can't break JSON parsing.
    raw_text = _THINK_BLOCK.sub("", raw_text).strip()

    if expect_json:
        try:
            return json.loads(raw_text)
        except json.JSONDecodeError as exc:
            logger.error("llm_json_parse_failed", extra={"raw_output": raw_text})
            raise LLMCallError(f"Model did not return valid JSON. Raw output: {raw_text!r}") from exc

    return raw_text