"""
Manages disposable sandbox copies of a dataset. Repairs are ALWAYS applied
to the file this module returns, never to the original dataset_path -- this
is the structural enforcement of the "never touch the original" safety rule.

PER-REPAIR ROLLBACK: the sandbox is shared by every repair in a run, so
discarding it on one failed validation would also throw away earlier,
already-accepted repairs. Instead, the Repair Agent snapshots the sandbox
before each repair (snapshot_sandbox) and the Validation Agent restores that
snapshot if THIS repair fails (restore_sandbox) -- earlier fixes survive.
"""

import os
import shutil
import uuid

from app.core.config import settings


def create_sandbox(original_path: str) -> str:
    """Copies the dataset to a new disposable file and returns its path."""
    os.makedirs(settings.sandbox_dir, exist_ok=True)
    ext = os.path.splitext(original_path)[1] or ".csv"
    sandbox_path = os.path.join(settings.sandbox_dir, f"{uuid.uuid4()}{ext}")
    shutil.copy(original_path, sandbox_path)
    return sandbox_path


def discard_sandbox(sandbox_path: str) -> None:
    """Deletes a sandbox copy (and any pending snapshot of it)."""
    drop_snapshot(sandbox_path)
    if sandbox_path and os.path.exists(sandbox_path):
        os.remove(sandbox_path)


def _snapshot_path(sandbox_path: str) -> str:
    return sandbox_path + ".pre"


def snapshot_sandbox(sandbox_path: str) -> None:
    """Saves the sandbox's current state so a single repair can be undone."""
    shutil.copy(sandbox_path, _snapshot_path(sandbox_path))


def restore_sandbox(sandbox_path: str) -> bool:
    """Undoes the most recent repair. Returns False if no snapshot exists
    (i.e. the sandbox was created by that very repair)."""
    snap = _snapshot_path(sandbox_path)
    if not os.path.exists(snap):
        return False
    shutil.copy(snap, sandbox_path)
    os.remove(snap)
    return True


def drop_snapshot(sandbox_path: str) -> None:
    """Deletes the snapshot once a repair is accepted (or never applied)."""
    if sandbox_path:
        snap = _snapshot_path(sandbox_path)
        if os.path.exists(snap):
            os.remove(snap)