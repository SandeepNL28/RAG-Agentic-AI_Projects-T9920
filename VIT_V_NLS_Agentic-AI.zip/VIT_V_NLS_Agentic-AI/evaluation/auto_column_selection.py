"""
Automatic column selection for benchmark scenarios. Manually inspecting
and hand-picking outlier/missing/category columns for every new dataset
(as was done for Titanic/Adult Income/German Credit) doesn't scale to the
original project spec's target of 20-30 datasets. This module picks
suitable columns automatically, applying the same reasoning used when
picking them by hand:

  - outlier_column / missing_column: numeric, with NO pre-existing
    missing values (injecting synthetic missingness/outliers on top of
    real missingness would contaminate the ground truth -- this was the
    exact reasoning applied manually to avoid Titanic's 'age'/'fare' and
    Adult Income's 'workclass'/'occupation'/'native-country').
  - category_column: text, with no pre-existing missing values, and a
    cardinality in a sensible range -- too few unique values (e.g. a
    binary flag) leaves little room to inject meaningful spelling
    variants; too many (e.g. a free-text 'name' column where almost
    every value is unique) makes "category inconsistency" a poor fit
    conceptually, since there's no real notion of a "dominant spelling"
    for a column that's supposed to have mostly-unique values.
"""

import pandas as pd


def _clean_numeric_columns(df: pd.DataFrame) -> list[str]:
    numeric_cols = df.select_dtypes(include="number").columns
    return [
        col for col in numeric_cols
        if df[col].isna().sum() == 0 and df[col].std() > 0
    ]


def _clean_text_columns(df: pd.DataFrame, min_unique: int = 2, max_unique_ratio: float = 0.5) -> list[str]:
    """
    max_unique_ratio caps cardinality relative to row count -- e.g. 0.5
    means a column can have at most half as many unique values as rows,
    which excludes near-unique free-text columns like 'name' or 'ticket'.
    """
    text_cols = [c for c in df.columns if pd.api.types.is_string_dtype(df[c])]
    suitable = []
    n_rows = len(df)
    for col in text_cols:
        if df[col].isna().sum() > 0:
            continue
        n_unique = df[col].nunique()
        if n_unique < min_unique:
            continue
        if n_rows > 0 and (n_unique / n_rows) > max_unique_ratio:
            continue
        suitable.append(col)
    return suitable


def auto_select_columns(df: pd.DataFrame) -> dict:
    """
    Returns {"outlier_column": ..., "missing_column": ..., "category_column": ...}
    or raises ValueError with a clear explanation if no suitable column
    exists for one of the roles -- explicit failure is better than
    silently picking a bad column and producing a contaminated benchmark.
    """
    clean_numeric = _clean_numeric_columns(df)
    clean_text = _clean_text_columns(df)

    if len(clean_numeric) < 2:
        raise ValueError(
            f"Need at least 2 clean numeric columns (no missing values, non-zero variance) "
            f"for outlier_column and missing_column, found {len(clean_numeric)}: {clean_numeric}"
        )
    if len(clean_text) < 1:
        raise ValueError(
            f"Need at least 1 clean text column (no missing values, sensible cardinality) "
            f"for category_column, found none among: {list(df.columns)}"
        )

    return {
        "outlier_column": clean_numeric[0],
        "missing_column": clean_numeric[1],
        "category_column": clean_text[0],
    }