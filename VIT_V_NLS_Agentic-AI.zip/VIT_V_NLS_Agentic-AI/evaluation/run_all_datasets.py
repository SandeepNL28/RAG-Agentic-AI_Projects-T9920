"""
Batch evaluation runner. Scans a folder for CSV datasets, runs the full
multi-seed evaluation on each (with automatic column selection), and
aggregates results both per-dataset and across the entire batch. This is
what makes scaling toward the original project spec's 20-30 dataset
target a "drop files in a folder, run one command" operation rather than
a manual per-dataset process.

Usage:
    python -m evaluation.run_all_datasets

    (requires `ollama serve` running, since this uses the REAL LLM by
    default when run as a script -- tests substitute a mock instead)
"""

import glob
import os

import pandas as pd

from evaluation.run_multi_seed_evaluation import run_multi_seed_evaluation, AggregatedMetric
from evaluation.auto_column_selection import auto_select_columns


def run_all_datasets(
    datasets_dir: str = "benchmark/datasets",
    seeds: list[int] | None = None,
    max_rows_per_dataset: int = 2000,
    subsample_seed: int = 0,
) -> dict:
    """
    Runs the full multi-seed evaluation on every CSV file found in
    `datasets_dir`. Datasets larger than `max_rows_per_dataset` are
    subsampled for reasonable local runtime (matching the approach used
    manually for Adult Income earlier). A dataset that has no suitable
    columns for corruption injection (e.g. all-missing or all-unique
    columns) is skipped with a clear reason rather than crashing the
    whole batch -- one bad dataset shouldn't block every other one.
    """
    if seeds is None:
        seeds = list(range(1, 11))

    csv_paths = sorted(glob.glob(os.path.join(datasets_dir, "*.csv")))
    if not csv_paths:
        raise FileNotFoundError(
            f"No CSV files found in '{datasets_dir}'. "
            f"Run scripts/fetch_datasets.py first, or point datasets_dir elsewhere."
        )

    per_dataset_results = {}
    skipped_datasets = []

    cross_dataset_metrics = {
        "baseline1_repair_accuracy": AggregatedMetric(),
        "baseline2_repair_accuracy": AggregatedMetric(),
        "proposed_precision": AggregatedMetric(),
        "proposed_recall": AggregatedMetric(),
        "proposed_f1": AggregatedMetric(),
        "proposed_safe_repair_rate": AggregatedMetric(),
        "proposed_false_repair_rate": AggregatedMetric(),
        "proposed_autonomy_rate": AggregatedMetric(),
    }
    total_seed_runs = 0

    for csv_path in csv_paths:
        dataset_name = os.path.splitext(os.path.basename(csv_path))[0]
        print(f"[{dataset_name}] loading...")
        df = pd.read_csv(csv_path)

        if len(df) > max_rows_per_dataset:
            df = df.sample(n=max_rows_per_dataset, random_state=subsample_seed).reset_index(drop=True)

        try:
            auto_select_columns(df)
        except ValueError as exc:
            print(f"[{dataset_name}] SKIPPED: {exc}")
            skipped_datasets.append({"dataset": dataset_name, "reason": str(exc)})
            continue

        print(f"[{dataset_name}] running {len(seeds)} seeds...")
        result = run_multi_seed_evaluation(seeds=seeds, clean_df=df)
        per_dataset_results[dataset_name] = {
            "n_succeeded": result["n_seeds_succeeded"],
            "failed_seeds": result["failed_seeds"],
            "aggregated": result["aggregated"],
        }

        for seed_entry in result["per_seed_results"]:
            r = seed_entry["result"]
            total_seed_runs += 1
            cross_dataset_metrics["baseline1_repair_accuracy"].add(r["baseline1_rule_based"]["repair_accuracy"])
            cross_dataset_metrics["baseline2_repair_accuracy"].add(r["baseline2_fixed_llm"]["repair_accuracy"])
            cross_dataset_metrics["proposed_precision"].add(r["proposed_system"]["detection"]["precision"])
            cross_dataset_metrics["proposed_recall"].add(r["proposed_system"]["detection"]["recall"])
            cross_dataset_metrics["proposed_f1"].add(r["proposed_system"]["detection"]["f1"])
            cross_dataset_metrics["proposed_safe_repair_rate"].add(r["proposed_system"]["safe_repair_rate"])
            cross_dataset_metrics["proposed_false_repair_rate"].add(r["proposed_system"]["false_repair_rate"])
            cross_dataset_metrics["proposed_autonomy_rate"].add(r["proposed_system"]["autonomy_rate"])

    for metric in cross_dataset_metrics.values():
        metric.total_runs = total_seed_runs

    return {
        "datasets_evaluated": list(per_dataset_results.keys()),
        "datasets_skipped": skipped_datasets,
        "total_seed_runs": total_seed_runs,
        "per_dataset": per_dataset_results,
        "cross_dataset_aggregated": {name: metric.summary() for name, metric in cross_dataset_metrics.items()},
    }


if __name__ == "__main__":
    import json
    results = run_all_datasets()
    print()
    print("=" * 60)
    print(f"Datasets evaluated: {results['datasets_evaluated']}")
    print(f"Datasets skipped: {[d['dataset'] for d in results['datasets_skipped']]}")
    print(f"Total seed-runs across all datasets: {results['total_seed_runs']}")
    print("=" * 60)
    print(json.dumps(results["cross_dataset_aggregated"], indent=2, default=str))