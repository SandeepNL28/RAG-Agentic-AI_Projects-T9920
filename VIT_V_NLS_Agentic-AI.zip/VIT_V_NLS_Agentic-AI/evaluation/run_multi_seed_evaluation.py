"""
Runs the full evaluation across MANY seeds and aggregates the results.
One run of run_full_evaluation() is a smoke test; this is what turns it
into something with actual statistical weight -- mean, std, and how many
runs each metric was even computable over (since Safe Repair Rate can be
undefined/None on any given run if nothing was accepted).
"""

import statistics
from dataclasses import dataclass, field
from evaluation.auto_column_selection import auto_select_columns
import pandas as pd

from evaluation.run_evaluation import run_full_evaluation


@dataclass
class AggregatedMetric:
    """
    Mean/std/min/max over however many runs actually produced a value for
    this metric, plus how many runs that was out of the total -- reported
    explicitly rather than silently averaging over a partial sample.
    """
    values: list[float] = field(default_factory=list)
    total_runs: int = 0

    def add(self, value):
        if value is not None:
            self.values.append(value)

    def summary(self) -> dict:
        n = len(self.values)
        if n == 0:
            return {"mean": None, "std": None, "min": None, "max": None, "n_defined": 0, "n_total": self.total_runs}
        return {
            "mean": round(statistics.mean(self.values), 4),
            "std": round(statistics.stdev(self.values), 4) if n > 1 else 0.0,
            "min": round(min(self.values), 4),
            "max": round(max(self.values), 4),
            "n_defined": n,
            "n_total": self.total_runs,
        }


def run_multi_seed_evaluation(
    seeds: list[int],
    clean_df: pd.DataFrame | None = None,
    outlier_column: str | None = None,
    missing_column: str | None = None,
    category_column: str | None = None,
) -> dict:
    """
    Runs run_full_evaluation() once per seed and aggregates every metric
    across all runs. The LLM must already be reachable, or call_llm must
    be monkeypatched by the caller for every call across every seed.

    COLUMN AUTO-DETECTION: if clean_df is provided but any of
    outlier_column/missing_column/category_column is left as None, they
    are chosen automatically via evaluation/auto_column_selection.py.
    If clean_df is None (using the built-in synthetic dataset), the
    historical defaults (age / annual_income / city) are used instead.
    """
    if clean_df is None:
        outlier_column = outlier_column or "age"
        missing_column = missing_column or "annual_income"
        category_column = category_column or "city"
    elif outlier_column is None or missing_column is None or category_column is None:
        auto = auto_select_columns(clean_df)
        outlier_column = outlier_column or auto["outlier_column"]
        missing_column = missing_column or auto["missing_column"]
        category_column = category_column or auto["category_column"]

    metrics_to_track = {
        "baseline1_repair_accuracy": AggregatedMetric(total_runs=len(seeds)),
        "baseline2_repair_accuracy": AggregatedMetric(total_runs=len(seeds)),
        
        "proposed_precision": AggregatedMetric(total_runs=len(seeds)),
        "proposed_recall": AggregatedMetric(total_runs=len(seeds)),
        "proposed_f1": AggregatedMetric(total_runs=len(seeds)),
        "proposed_safe_repair_rate": AggregatedMetric(total_runs=len(seeds)),
        "proposed_false_repair_rate": AggregatedMetric(total_runs=len(seeds)),
        "proposed_autonomy_rate": AggregatedMetric(total_runs=len(seeds)),
    }

    per_seed_results = []
    failed_seeds = []

    for seed in seeds:
        try:
            result = run_full_evaluation(
                seed=seed, clean_df=clean_df,
                outlier_column=outlier_column, missing_column=missing_column, category_column=category_column,
            )
        except Exception as exc:  # noqa: BLE001 -- one bad seed shouldn't kill the whole batch
            failed_seeds.append({"seed": seed, "error": str(exc)})
            continue

        per_seed_results.append({"seed": seed, "result": result})

        metrics_to_track["baseline1_repair_accuracy"].add(result["baseline1_rule_based"]["repair_accuracy"])
        metrics_to_track["baseline2_repair_accuracy"].add(result["baseline2_fixed_llm"]["repair_accuracy"])
        metrics_to_track["proposed_precision"].add(result["proposed_system"]["detection"]["precision"])
        metrics_to_track["proposed_recall"].add(result["proposed_system"]["detection"]["recall"])
        metrics_to_track["proposed_f1"].add(result["proposed_system"]["detection"]["f1"])
        metrics_to_track["proposed_safe_repair_rate"].add(result["proposed_system"]["safe_repair_rate"])
        metrics_to_track["proposed_false_repair_rate"].add(result["proposed_system"]["false_repair_rate"])
        metrics_to_track["proposed_autonomy_rate"].add(result["proposed_system"]["autonomy_rate"])

    return {
        "n_seeds_requested": len(seeds),
        "n_seeds_succeeded": len(per_seed_results),
        "failed_seeds": failed_seeds,
        "aggregated": {name: metric.summary() for name, metric in metrics_to_track.items()},
        "per_seed_results": per_seed_results,
    }


if __name__ == "__main__":
    import json
    results = run_multi_seed_evaluation(seeds=list(range(1, 11)))
    print(json.dumps({"n_seeds_succeeded": results["n_seeds_succeeded"], "aggregated": results["aggregated"]}, indent=2, default=str))