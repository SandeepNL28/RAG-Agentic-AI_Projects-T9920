"""
Live Investigation Console -- real-time Streamlit dashboard for the
Autonomous Dataset Forensics Agent.

It is a thin client over the FastAPI backend: it never touches the data or
the agents directly. While a run is in progress it consumes the backend's
WebSocket endpoint (/runs/{run_id}/live), so the pipeline strip, progress
bar, counters and agent feed update the moment each LangGraph node
finishes. If the WebSocket is unavailable it falls back to polling.

Run (three terminals):
    ollama serve
    uvicorn app.api.main:app --port 8000
    streamlit run dashboard/live_app.py
"""

from __future__ import annotations

import html
import io
import json
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime

import numpy as np
import pandas as pd
import requests
import streamlit as st

DEFAULT_API_URL = os.environ.get("FORENSICS_API_URL", "http://localhost:8001")

PIPELINE_STAGES = [
    ("plan", "Planner", "Decides what happens next"),
    ("investigate", "Investigate", "Runs the inspection tools"),
    ("diagnose", "Diagnose", "Hypothesis + evidence"),
    ("repair", "Repair", "Sandbox fix, only if evidence clears the gate"),
    ("validate", "Validate", "Accept, roll back, or escalate"),
]

STEP_COLORS = {
    "plan": "#94a3b8", "investigate": "#38bdf8", "diagnose": "#a78bfa",
    "repair": "#fbbf24", "validate": "#34d399", "system": "#64748b",
}

OUTCOME_STYLE = {
    "accepted": ("#16a34a", "Accepted"),
    "rolled_back": ("#d97706", "Rolled back"),
    "human_review": ("#7c3aed", "Human review"),
    "rejected": ("#dc2626", "Rejected"),
    "pending": ("#64748b", "Pending"),
}

FINAL_EVENTS = ("run_completed", "run_failed")


# ---------------------------------------------------------------------------
# Pure helpers (no Streamlit calls -- these are unit-testable)
# ---------------------------------------------------------------------------

def api_ws_url(api_url: str, run_id: str) -> str:
    base = api_url.rstrip("/")
    if base.startswith("https://"):
        base = "wss://" + base[len("https://"):]
    elif base.startswith("http://"):
        base = "ws://" + base[len("http://"):]
    return f"{base}/runs/{run_id}/live"


def estimate_progress(issues: int, decisions: int, status: str) -> float:
    """Real progress once the issue count is known: decisions made / issues found."""
    if status == "completed":
        return 1.0
    if issues <= 0:
        return 0.05
    return min(0.98, 0.10 + 0.88 * (decisions / issues))


def build_demo_csv() -> bytes:
    """A messy customer table with known, planted problems -- handy for demos."""
    cities = ["New York", "Boston", "Chicago", "Seattle", "Denver", "Austin"]
    rows = []
    for i in range(1, 41):
        rows.append({
            "customer_id": i,
            "name": f"Customer {i:02d}",
            "age": 22 + (i * 7) % 38,
            "city": cities[i % 6],
            "annual_income": 45000 + (i % 20) * 2500,
            "signup_date": f"2023-{1 + (i % 12):02d}-{1 + (i % 27):02d}",
        })
    df = pd.DataFrame(rows)
    df.loc[6, "age"] = 240                                   # impossible age
    df.loc[[3, 17, 25], "annual_income"] = None              # missing values
    df.loc[[11, 17], "city"] = ["new york", "NEW YORK"]      # inconsistent categories
    df.loc[[4, 13], "signup_date"] = ["03/15/2023", "07-04-2023"]  # mixed date formats
    df = pd.concat([df, df.iloc[[8]]], ignore_index=True)    # exact duplicate row
    return df.to_csv(index=False).encode("utf-8")


@dataclass
class LiveState:
    started: float
    status: str = "running"          # running | completed | failed
    error: str | None = None
    active: str = "plan"
    seen: list = field(default_factory=list)
    issues: int = 0
    decisions: int = 0
    feed: list = field(default_factory=list)
    audit_seen: int = 0


def add_feed(live: LiveState, badge: str, text: str, decision: str | None = None) -> None:
    live.feed.append({
        "ts": datetime.now().strftime("%H:%M:%S"),
        "badge": badge, "text": text, "decision": decision,
    })


def apply_event(live: LiveState, ev: dict) -> None:
    """Folds one backend WebSocket event into the live state."""
    kind = ev.get("type")
    if kind == "run_started":
        add_feed(live, "system", "Investigation started on the server.")
    elif kind == "step_completed":
        node = ev.get("node", "?")
        live.active = node
        if node not in live.seen:
            live.seen.append(node)
        live.issues = max(live.issues, int(ev.get("issues_so_far", 0)))
        live.decisions = max(live.decisions, int(ev.get("decisions_so_far", 0)))
    elif kind == "run_completed":
        live.status = "completed"
        add_feed(live, "system", "Investigation complete.")
    elif kind == "run_failed":
        live.status = "failed"
        live.error = ev.get("error") or "unknown error"
        add_feed(live, "system", f"Run failed: {live.error}")


def absorb_audit(live: LiveState, entries: list[dict]) -> None:
    """Adds unseen audit-trail entries to the feed and derives counters from them,
    so the polling fallback still shows real progress."""
    for entry in entries[live.audit_seen:]:
        text = entry.get("reasoning_summary") or entry.get("observation") or ""
        add_feed(live, entry.get("step", "system"), text, entry.get("decision"))
        step = entry.get("step")
        if step:
            live.active = step
            if step not in live.seen:
                live.seen.append(step)
        if step == "investigate":
            match = re.search(r"(\d+)\s+issue", entry.get("observation", ""))
            if match:
                live.issues = max(live.issues, int(match.group(1)))
    live.audit_seen = len(entries)
    validated = sum(1 for e in entries if e.get("step") == "validate")
    live.decisions = max(live.decisions, validated)


def summarize_outcomes(issues: list[dict]) -> dict:
    counts = {k: 0 for k in OUTCOME_STYLE}
    for issue in issues:
        decision = issue.get("decision")
        counts[decision["outcome"] if decision else "pending"] += 1
    total = len(issues)
    counts["total"] = total
    counts["autonomy_rate"] = (counts["accepted"] + counts["rejected"]) / total if total else 0.0
    return counts


def issues_dataframe(issues: list[dict]) -> pd.DataFrame:
    rows = []
    for issue in issues:
        decision = issue.get("decision") or {}
        rows.append({
            "Column": issue.get("column") or "(whole table)",
            "Issue": issue.get("issue_type"),
            "Severity": issue.get("severity"),
            "Decision": OUTCOME_STYLE.get(decision.get("outcome", "pending"), ("", "Pending"))[1],
            "Why": decision.get("reason", ""),
            "Observation": issue.get("raw_observation", ""),
        })
    return pd.DataFrame(rows)


def group_audit_by_issue(audit: list[dict]) -> tuple[dict, list]:
    per_issue: dict = {}
    global_entries = []
    for entry in audit:
        if entry.get("issue_id"):
            per_issue.setdefault(entry["issue_id"], []).append(entry)
        else:
            global_entries.append(entry)
    return per_issue, global_entries


def diff_mask(before: pd.DataFrame, after: pd.DataFrame) -> pd.DataFrame:
    """Boolean mask of cells whose value changed. Numeric values that differ only in
    formatting (34 vs 34.0) are NOT counted as changes."""
    n = min(len(before), len(after))
    common = [c for c in before.columns if c in after.columns]
    a = before.iloc[:n].reset_index(drop=True)
    b = after.iloc[:n].reset_index(drop=True)
    mask = pd.DataFrame(False, index=range(n), columns=common)
    for col in common:
        an = pd.to_numeric(a[col], errors="coerce")
        bn = pd.to_numeric(b[col], errors="coerce")
        both_numeric = an.notna() & bn.notna()
        num_changed = both_numeric & ~pd.Series(np.isclose(an, bn), index=an.index)
        a_txt = a[col].astype("string").fillna("")
        b_txt = b[col].astype("string").fillna("")
        text_changed = (~both_numeric) & (a_txt != b_txt)
        mask[col] = (num_changed | text_changed).to_numpy(dtype=bool)
    return mask


def compare_datasets(before: pd.DataFrame, after: pd.DataFrame) -> dict:
    mask = diff_mask(before, after)
    return {
        "mask": mask,
        "cells_changed": int(mask.to_numpy().sum()) if mask.size else 0,
        "rows_before": len(before),
        "rows_after": len(after),
        "rows_removed": max(0, len(before) - len(after)),
    }


def build_report_markdown(name: str, run_id: str, issues: list[dict], audit: list[dict], changes: dict | None) -> str:
    counts = summarize_outcomes(issues)
    per_issue, _ = group_audit_by_issue(audit)
    lines = [
        f"# Forensic report -- {name}",
        "",
        f"- Run ID: `{run_id}`",
        f"- Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"- Issues found: **{counts['total']}**",
        f"- Accepted repairs: {counts['accepted']} | Rolled back: {counts['rolled_back']} | "
        f"Sent to human review: {counts['human_review']} | Rejected: {counts['rejected']}",
        f"- Autonomy rate (resolved without a human): {counts['autonomy_rate']:.0%}",
    ]
    if changes:
        lines.append(
            f"- Dataset delta: {changes['cells_changed']} cell(s) changed, "
            f"{changes['rows_removed']} row(s) removed ({changes['rows_before']} -> {changes['rows_after']})"
        )
    lines += ["", "The original file is never modified; all repairs run on a sandbox copy.", "", "## Issues and decisions", ""]
    for issue in issues:
        decision = issue.get("decision") or {}
        label = OUTCOME_STYLE.get(decision.get("outcome", "pending"), ("", "Pending"))[1]
        lines += [
            f"### {issue.get('column') or '(whole table)'} -- {issue.get('issue_type')} ({issue.get('severity')})",
            f"- Observation: {issue.get('raw_observation', '')}",
            f"- Decision: **{label}** -- {decision.get('reason', 'n/a')}",
            "- Trace:",
        ]
        for entry in per_issue.get(issue.get("issue_id"), []):
            lines.append(
                f"  - `{entry.get('step')}` via {entry.get('tool_used') or 'n/a'}: "
                f"{entry.get('reasoning_summary') or entry.get('observation')}"
            )
        lines.append("")
    return "\n".join(lines)


# ---- HTML renderers -------------------------------------------------------

def render_pipeline_html(active: str, seen: list, status: str) -> str:
    parts = []
    for key, label, desc in PIPELINE_STAGES:
        if status == "completed":
            cls = "done"
        elif status == "failed" and key == active:
            cls = "failed"
        elif key == active and status == "running":
            cls = "active"
        elif key in seen:
            cls = "done"
        else:
            cls = "idle"
        parts.append(
            f'<div class="stage {cls}"><div class="stage-name">{html.escape(label)}</div>'
            f'<div class="stage-desc">{html.escape(desc)}</div></div>'
        )
    return f'<div class="stage-strip">{"".join(parts)}</div>'


def render_feed_html(feed: list, limit: int = 16) -> str:
    if not feed:
        return '<div class="feed"><div class="feed-row"><span class="txt">Waiting for the first agent step...</span></div></div>'
    rows = []
    for item in reversed(feed[-limit:]):
        color = STEP_COLORS.get(item["badge"], "#64748b")
        pill = ""
        if item.get("decision"):
            dcolor, dlabel = OUTCOME_STYLE.get(item["decision"], ("#64748b", item["decision"]))
            pill = (f'<span class="pill" style="background:{dcolor}22;color:{dcolor};'
                    f'border:1px solid {dcolor}66">{html.escape(dlabel)}</span>')
        rows.append(
            f'<div class="feed-row"><span class="ts">{item["ts"]}</span>'
            f'<span class="badge" style="color:{color};border-color:{color}55">{html.escape(item["badge"])}</span>'
            f'<span class="txt">{html.escape(str(item["text"]))}</span>{pill}</div>'
        )
    return f'<div class="feed">{"".join(rows)}</div>'


def metric_cards_html(live: LiveState, elapsed: float) -> str:
    cards = [
        ("Issues found", str(live.issues)),
        ("Decisions made", f"{live.decisions}/{live.issues}" if live.issues else "0"),
        ("Active stage", live.active.capitalize()),
        ("Elapsed", f"{elapsed:0.1f}s"),
    ]
    inner = "".join(
        f'<div class="card"><div class="card-value">{html.escape(v)}</div>'
        f'<div class="card-label">{html.escape(k)}</div></div>' for k, v in cards
    )
    return f'<div class="cards">{inner}</div>'


def status_pill_html(live: LiveState) -> str:
    color = {"running": "#38bdf8", "completed": "#22c55e", "failed": "#ef4444"}[live.status]
    return (f'<span class="status" style="color:{color};border-color:{color}88">'
            f'<span class="dot" style="background:{color}"></span>{live.status.upper()}</span>')


CSS = """
<style>
.stage-strip{display:flex;gap:10px;margin:4px 0 14px 0}
.stage{flex:1;padding:12px 14px;border-radius:12px;border:1px solid #334155;background:#0f172a;color:#94a3b8}
.stage-name{font-weight:700;font-size:14px}.stage-desc{font-size:11px;opacity:.8;margin-top:2px}
.stage.active{border-color:#60a5fa;color:#e2e8f0;box-shadow:0 0 0 1px #60a5fa,0 0 18px rgba(96,165,250,.35);animation:pulse 1.3s infinite}
.stage.done{border-color:#166534;background:#052e16;color:#bbf7d0}
.stage.failed{border-color:#991b1b;background:#450a0a;color:#fecaca}
@keyframes pulse{50%{box-shadow:0 0 0 1px #60a5fa,0 0 30px rgba(96,165,250,.6)}}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:10px 0}
.card{background:#0f172a;border:1px solid #1e293b;border-radius:12px;padding:14px;text-align:center}
.card-value{font-size:26px;font-weight:700;color:#e2e8f0}.card-label{font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:#64748b;margin-top:2px}
.feed{max-height:360px;overflow-y:auto;background:#0b1220;border:1px solid #1e293b;border-radius:12px}
.feed-row{display:flex;gap:10px;align-items:baseline;padding:9px 12px;border-bottom:1px solid #1e293b;font-size:13px;color:#cbd5e1}
.ts{color:#475569;font-family:monospace;font-size:11px}
.badge{border:1px solid;border-radius:999px;padding:1px 8px;font-size:10px;font-weight:700;text-transform:uppercase}
.pill{border-radius:999px;padding:1px 9px;font-size:11px;font-weight:700;margin-left:auto}
.txt{flex:1}
.status{border:1px solid;border-radius:999px;padding:3px 12px;font-size:12px;font-weight:700;letter-spacing:.06em}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:7px}
</style>
"""

ARCHITECTURE_DOT = """
digraph G { rankdir=LR; node [shape=box, style="rounded,filled", fillcolor="#0f172a", color="#334155", fontcolor="#e2e8f0"];
  edge [color="#64748b"];
  Upload -> Investigate -> Diagnose -> Gate [label="evidence"];
  Gate [shape=diamond, label="Confidence\\n>= threshold?"];
  Gate -> Repair [label="yes"]; Gate -> Human [label="no (abstain)"];
  Repair [label="Repair\\n(sandbox copy)"]; Repair -> Validate;
  Validate -> Accepted [label="passes"]; Validate -> RolledBack [label="fails"];
  Human [label="Human review"]; RolledBack [label="Rolled back"]; }
"""


# ---------------------------------------------------------------------------
# API access + live streaming
# ---------------------------------------------------------------------------

def api_get(api_url: str, path: str, timeout: int = 10):
    response = requests.get(f"{api_url.rstrip('/')}{path}", timeout=timeout)
    response.raise_for_status()
    return response.json()


def check_health(api_url: str) -> tuple[bool, int | None]:
    try:
        t0 = time.time()
        response = requests.get(f"{api_url.rstrip('/')}/health", timeout=2)
        return response.status_code == 200, int((time.time() - t0) * 1000)
    except requests.RequestException:
        return False, None


def upload_and_start(api_url: str, filename: str, data: bytes) -> str:
    base = api_url.rstrip("/")
    up = requests.post(f"{base}/datasets/upload", files={"file": (filename, data, "text/csv")}, timeout=60)
    up.raise_for_status()
    start = requests.post(f"{base}/runs/start", params={"dataset_id": up.json()["dataset_id"]}, timeout=30)
    start.raise_for_status()
    return start.json()["run_id"]


def ws_events(api_url: str, run_id: str):
    """Yields backend events as they are pushed; yields {"type": "_idle"} on a quiet 2s."""
    from websockets.sync.client import connect
    with connect(api_ws_url(api_url, run_id), open_timeout=10) as ws:
        while True:
            try:
                raw = ws.recv(timeout=2)
            except TimeoutError:
                yield {"type": "_idle"}
                continue
            event = json.loads(raw)
            yield event
            if event.get("type") in FINAL_EVENTS:
                return


def poll_events(max_seconds: int = 900):
    started = time.time()
    while time.time() - started < max_seconds:
        time.sleep(1.0)
        yield {"type": "_idle"}
    yield {"type": "run_failed", "error": "Timed out waiting for the run to finish."}


def run_live(api_url: str, run_id: str, use_websocket: bool, ui, live: LiveState) -> None:
    """Drives the live UI until the run ends. `ui` only needs a .render(live) method."""

    def consume(events) -> None:
        for event in events:
            if event["type"] == "_idle":
                try:
                    status = api_get(api_url, f"/runs/{run_id}/status")
                    if status["status"] == "completed":
                        event = {"type": "run_completed"}
                    elif status["status"] == "failed":
                        event = {"type": "run_failed", "error": status.get("error")}
                except requests.RequestException:
                    pass
            apply_event(live, event)
            try:
                absorb_audit(live, api_get(api_url, f"/runs/{run_id}/audit"))
            except requests.RequestException:
                pass
            ui.render(live)
            if live.status != "running":
                return

    if use_websocket:
        try:
            consume(ws_events(api_url, run_id))
        except Exception as exc:  # noqa: BLE001 -- any transport failure falls back to polling
            add_feed(live, "system", f"WebSocket unavailable ({type(exc).__name__}); switching to polling.")
    if live.status == "running":
        consume(poll_events())


# ---------------------------------------------------------------------------
# Streamlit UI
# ---------------------------------------------------------------------------

class LiveUI:
    def __init__(self):
        self.status = st.empty()
        self.strip = st.empty()
        self.progress = st.empty()
        self.cards = st.empty()
        st.markdown("##### Live agent feed")
        self.feed = st.empty()

    def render(self, live: LiveState) -> None:
        elapsed = time.time() - live.started
        self.status.markdown(status_pill_html(live), unsafe_allow_html=True)
        self.strip.markdown(render_pipeline_html(live.active, live.seen, live.status), unsafe_allow_html=True)
        self.progress.progress(estimate_progress(live.issues, live.decisions, live.status),
                               text=f"{live.decisions} of {live.issues or '?'} issues resolved")
        self.cards.markdown(metric_cards_html(live, elapsed), unsafe_allow_html=True)
        self.feed.markdown(render_feed_html(live.feed), unsafe_allow_html=True)


def run_investigation(api_url: str, filename: str, data: bytes, use_websocket: bool) -> None:
    ui = LiveUI()
    live = LiveState(started=time.time())
    add_feed(live, "system", f"Uploading {filename} ({len(data):,} bytes)...")
    ui.render(live)
    try:
        run_id = upload_and_start(api_url, filename, data)
    except requests.RequestException as exc:
        st.error(f"Could not start the run: {exc}")
        return
    add_feed(live, "system", f"Run {run_id[:8]} started (transport: {'WebSocket' if use_websocket else 'polling'}).")
    ui.render(live)

    run_live(api_url, run_id, use_websocket, ui, live)

    if live.status != "completed":
        st.error(f"The investigation failed: {live.error}")
        return
    try:
        issues = api_get(api_url, f"/runs/{run_id}/issues")
        audit = api_get(api_url, f"/runs/{run_id}/audit")
        cleaned = requests.get(f"{api_url.rstrip('/')}/runs/{run_id}/download", timeout=30)
        cleaned.raise_for_status()
    except requests.RequestException as exc:
        st.error(f"Run finished but results could not be fetched: {exc}")
        return
    st.session_state["results"] = {
        "run_id": run_id, "name": filename, "issues": issues, "audit": audit,
        "original": data, "cleaned": cleaned.content,
    }


def render_results(res: dict) -> None:
    issues, audit = res["issues"], res["audit"]
    counts = summarize_outcomes(issues)
    before = pd.read_csv(io.BytesIO(res["original"]))
    after = pd.read_csv(io.BytesIO(res["cleaned"]))
    changes = compare_datasets(before, after)

    st.divider()
    st.subheader("Results")
    cols = st.columns(5)
    cols[0].metric("Issues found", counts["total"])
    cols[1].metric("Accepted repairs", counts["accepted"])
    cols[2].metric("Rolled back", counts["rolled_back"])
    cols[3].metric("Sent to human review", counts["human_review"])
    cols[4].metric("Autonomy rate", f"{counts['autonomy_rate']:.0%}")

    tab_issues, tab_trace, tab_diff, tab_dl = st.tabs(
        ["Issues & decisions", "Agent trajectory", "Before / after", "Downloads"])

    with tab_issues:
        st.dataframe(issues_dataframe(issues), hide_index=True)
        chart = pd.DataFrame({"issues": [counts[k] for k in ("accepted", "rolled_back", "human_review", "rejected")]},
                             index=["Accepted", "Rolled back", "Human review", "Rejected"])
        st.bar_chart(chart)

    with tab_trace:
        per_issue, global_entries = group_audit_by_issue(audit)
        for issue in issues:
            decision = issue.get("decision") or {}
            label = OUTCOME_STYLE.get(decision.get("outcome", "pending"), ("", "Pending"))[1]
            title = f"{issue.get('column') or '(whole table)'} | {issue.get('issue_type')} -> {label}"
            with st.expander(title):
                st.caption(decision.get("reason", ""))
                for entry in per_issue.get(issue.get("issue_id"), []):
                    st.markdown(f"**{entry['step']}** via `{entry.get('tool_used') or 'n/a'}`  \n"
                                f"{entry.get('reasoning_summary') or entry.get('observation')}")
        if global_entries:
            with st.expander("Run-level steps"):
                for entry in global_entries:
                    st.markdown(f"**{entry['step']}** -- {entry.get('reasoning_summary')}")

    with tab_diff:
        st.write(f"**{changes['cells_changed']}** cell(s) changed, **{changes['rows_removed']}** row(s) removed "
                 f"({changes['rows_before']} -> {changes['rows_after']}). Changed cells are highlighted.")
        left, right = st.columns(2)
        left.caption("Original (never modified)")
        left.dataframe(before, hide_index=True)
        right.caption("Cleaned output")
        mask = changes["mask"]
        view = after.iloc[:len(mask)]

        def highlight(column):
            flags = mask[column.name] if column.name in mask.columns else [False] * len(column)
            return ["background-color:#854d0e;color:#fef3c7" if f else "" for f in flags]

        right.dataframe(view.style.apply(highlight, axis=0), hide_index=True)

    with tab_dl:
        stem = os.path.splitext(res["name"])[0]
        st.download_button("Download cleaned dataset (CSV)", res["cleaned"], f"cleaned_{stem}.csv", "text/csv")
        st.download_button("Download forensic report (Markdown)",
                           build_report_markdown(res["name"], res["run_id"], issues, audit, changes),
                           f"forensic_report_{stem}.md", "text/markdown")
        st.download_button("Download audit log (JSON)", json.dumps(audit, indent=2),
                           f"audit_log_{stem}.json", "application/json")


def main() -> None:
    st.set_page_config(page_title="Dataset Forensics | Live Console", page_icon="🔎", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)

    with st.sidebar:
        st.header("Connection")
        api_url = st.text_input("API URL", DEFAULT_API_URL)
        online, latency = check_health(api_url)
        if online:
            st.success(f"API online ({latency} ms)")
        else:
            st.error("API offline. Start it with: uvicorn app.api.main:app --port 8000")
        transport = st.radio("Live transport", ["WebSocket (push)", "Polling (fallback)"])
        st.header("Dataset")
        source = st.radio("Source", ["Upload a CSV", "Built-in demo dataset"])
        st.caption("The original file is never modified. Repairs run on a sandbox copy, are validated, "
                   "and are rolled back if they fail.")

    st.title("🔎 Autonomous Dataset Forensics Agent")
    st.caption("Evidence-gated data-quality investigation, safe repair, and validation, streamed live.")

    filename, data = None, None
    if source == "Upload a CSV":
        uploaded = st.file_uploader("Drop a dataset", type=["csv"])
        if uploaded:
            filename, data = uploaded.name, uploaded.getvalue()
    else:
        filename, data = "demo_customers.csv", build_demo_csv()
        st.info("Demo dataset with planted problems: an impossible age (240), missing incomes, "
                "inconsistent city spellings, mixed date formats, and one exact duplicate row.")
        st.dataframe(pd.read_csv(io.BytesIO(data)).head(12), hide_index=True)

    if st.button("▶  Run investigation", type="primary", disabled=not (data and online)):
        st.session_state.pop("results", None)
        run_investigation(api_url, filename, data, transport.startswith("WebSocket"))

    if "results" in st.session_state:
        render_results(st.session_state["results"])

    with st.expander("How the agent decides"):
        st.graphviz_chart(ARCHITECTURE_DOT)


if __name__ == "__main__":
    main()