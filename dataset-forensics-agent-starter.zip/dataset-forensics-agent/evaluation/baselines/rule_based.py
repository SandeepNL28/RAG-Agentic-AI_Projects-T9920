"""
Baseline 1: Traditional Rule-Based Pipeline.

Deliberately dumb, on purpose -- this is the honest "no AI reasoning at
all" comparison point. It applies fixed statistical rules to every column
blindly, with zero investigation, zero evidence, and zero confidence
assessment. This is what the proposed evidence-gated system should
outperform on Safe Repair Rate / False Repair Rate.
"""

import pandas as pd


def run_rule_based_pipeline(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Numeric columns are upcast to float64 up front. Without this,
    # assigning a float mean into an originally-integer column (e.g. a
    # column of whole-number ages with no missing values, so pandas
    # inferred int64) raises a TypeError under pandas >= 2.x/3.x's
    # stricter dtype-safety rules -- a real compatibility bug caught
    # while testing this function against a plain integer column.
    numeric_cols = df.select_dtypes(include="number").columns
    df[numeric_cols] = df[numeric_cols].astype("float64")

    # Rule: replace any numeric outlier (>3 std devs from the mean) with
    # the column mean. No evidence, no confidence check, no validation.
    for col in numeric_cols:
        series = df[col].dropna()
        if series.empty or series.std() == 0:
            continue
        mean, std = series.mean(), series.std()
        outlier_mask = (df[col] - mean).abs() > 3 * std
        df.loc[outlier_mask, col] = mean

    # Rule: fill any missing numeric value with the column mean.
    for col in numeric_cols:
        if df[col].isna().any():
            df[col] = df[col].fillna(df[col].mean())

    # Rule: lowercase every text column, blindly, as a crude attempt at
    # category normalization -- no check whether this is even appropriate
    # for that column.
    for col in df.columns:
        if pd.api.types.is_string_dtype(df[col]):
            df[col] = df[col].str.lower()

    # Rule: drop exact duplicate rows.
    df = df.drop_duplicates().reset_index(drop=True)

    return df
