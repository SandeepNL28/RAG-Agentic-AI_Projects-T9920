"""
Baseline 2: Fixed LLM Workflow.

Uses the SAME LLM and the SAME detection tools as the proposed system --
this is deliberate, so the comparison isolates exactly one variable:
evidence-gating. This baseline detects issues, asks the LLM once per
issue for a fix, and applies it directly. No hypothesis, no evidence
gathering, no confidence threshold, no sandbox, no validation, no
abstention. This is what "AI that acts without justification" looks like.
"""

import pandas as pd

from app.llm.ollama_client import call_llm
from app.tools.quality_analysis import (
    missing_value_analysis,
    outlier_detection,
    category_consistency_analysis,
)

FIX_PROMPT = """You are fixing a data quality issue. Given this problem, \
respond ONLY with JSON: {{"action": "<one of: impute, normalize, ignore>", \
"fixed_value": "<value or null>"}}

Issue type: {issue_type}
Column: {column}
Observation: {observation}
"""


def run_fixed_llm_workflow(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Same detection as the proposed system, for a fair comparison.
    missing = missing_value_analysis(df)
    for column, info in missing.items():
        decision = call_llm(
            FIX_PROMPT.format(issue_type="missing_value", column=column, observation=f"{info['missing_count']} missing values"),
            expect_json=True,
        )
        # Applied DIRECTLY -- no confidence check, no sandbox, no validation.
        if decision.get("action") == "impute" and pd.api.types.is_numeric_dtype(df[column]):
            df[column] = df[column].fillna(df[column].mean())

    for column in df.select_dtypes(include="number").columns:
        result = outlier_detection(df, column)
        if result["flagged_rows"]:
            decision = call_llm(
                FIX_PROMPT.format(issue_type="outlier", column=column, observation=result["summary"]),
                expect_json=True,
            )
            if decision.get("action") == "impute":
                mean_value = df[column].mean()
                df.loc[result["flagged_rows"], column] = mean_value

    for column in df.columns:
        if pd.api.types.is_string_dtype(df[column]):
            result = category_consistency_analysis(df, column)
            if result["inconsistent_groups"]:
                decision = call_llm(
                    FIX_PROMPT.format(issue_type="category_inconsistency", column=column, observation=result["summary"]),
                    expect_json=True,
                )
                if decision.get("action") == "normalize":
                    for _, variants in result["inconsistent_groups"].items():
                        canonical = sorted(variants)[0]  # simplistic, unlike the real system's frequency-based choice
                        df.loc[df[column].isin(variants), column] = canonical

    return df
