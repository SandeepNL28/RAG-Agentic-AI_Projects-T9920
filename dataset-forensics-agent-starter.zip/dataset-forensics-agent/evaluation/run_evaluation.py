"""
The evaluation harness: builds a corrupted benchmark scenario from clean
synthetic data, runs the proposed system (the real LangGraph pipeline) and
both baselines against it, and scores every system against the tracked
ground truth. This is what actually answers the project's research
questions with real numbers, rather than just "the system runs."

SCOPE NOTE: this uses one synthetic, moderately-sized clean dataset (30
rows) rather than the full 20-30 real UCI/OpenML dataset target from the
project spec. Real datasets couldn't be fetched in the environment that
built this (no network access to openml.org) -- see scripts/fetch_datasets.py
for the ready-to-run fetcher. This harness is a correctly-structured
starting point to scale up from, not the final research-scale run.
"""

import uuid
import pandas as pd

from app.core.schemas import ForensicsState
from app.graph.workflow import build_graph
from benchmark.corrupt import (
    inject_outliers,
    inject_missing_values,
    inject_category_noise,
    inject_duplicates,
)
from evaluation.baselines.rule_based import run_rule_based_pipeline
from evaluation.baselines.fixed_llm_workflow import run_fixed_llm_workflow
from evaluation import metrics


def build_clean_dataset(n_rows: int = 30) -> pd.DataFrame:
    """A synthetic but realistic clean dataset -- large enough that
    outlier detection isn't distorted by small-sample z-score masking."""
    cities = ["New York", "Boston", "Chicago", "Seattle", "Denver", "Austin"]
    return pd.DataFrame({
        "customer_id": range(1, n_rows + 1),
        "age": [25 + (i % 40) for i in range(n_rows)],
        "city": [cities[i % len(cities)] for i in range(n_rows)],
        "annual_income": [45000 + (i % 20) * 2000 for i in range(n_rows)],
    })


def build_benchmark_scenario(seed: int = 42) -> tuple[pd.DataFrame, list[dict]]:
    """
    Returns a corrupted DataFrame and a list of ground_truth records
    describing exactly what was injected. Four corruption types are
    combined into one scenario, each on a different column.
    """
    df = build_clean_dataset()
    ground_truths = []

    df, gt = inject_outliers(df, "age", frac=0.1, factor=8, seed=seed)
    ground_truths.append(gt)

    df, gt = inject_missing_values(df, "annual_income", frac=0.1, seed=seed)
    ground_truths.append(gt)

    df, gt = inject_category_noise(df, "city", frac=0.2, seed=seed)
    ground_truths.append(gt)

    df, gt = inject_duplicates(df, frac=0.1, seed=seed)
    ground_truths.append(gt)

    return df, ground_truths


def _true_corrupted_columns(ground_truths: list[dict]) -> set:
    return {gt["column"] for gt in ground_truths if "column" in gt}


def score_baseline_output(output_df: pd.DataFrame, ground_truths: list[dict]) -> dict:
    """
    Simple value-match scoring for baselines, which have no concept of an
    explicit accept/reject decision -- this is itself a meaningful,
    reportable structural difference from the proposed system, not just a
    scoring convenience.
    """
    total_checked = 0
    total_correct = 0

    for gt in ground_truths:
        if gt["corruption_type"] == "duplicate":
            expected_final_rows = gt["original_row_count"]
            total_checked += 1
            if len(output_df) == expected_final_rows:
                total_correct += 1
            continue

        column = gt["column"]
        if column not in output_df.columns:
            total_checked += len(gt["true_values"])
            continue

        for row_idx, true_value in gt["true_values"].items():
            total_checked += 1
            if row_idx >= len(output_df):
                continue
            actual_value = output_df.iloc[row_idx][column] if row_idx < len(output_df) else None
            if _values_match(actual_value, true_value):
                total_correct += 1

    return {
        "repair_accuracy": round(total_correct / total_checked, 4) if total_checked else 0.0,
        "total_checked": total_checked,
        "total_correct": total_correct,
    }


def _values_match(actual, expected) -> bool:
    if pd.isna(actual) and pd.isna(expected):
        return True
    if isinstance(expected, str):
        return str(actual).strip().lower() == str(expected).strip().lower()
    try:
        return abs(float(actual) - float(expected)) < 1e-6
    except (TypeError, ValueError):
        return actual == expected


def score_proposed_system(final_state: ForensicsState, output_df: pd.DataFrame, ground_truths: list[dict]) -> dict:
    """
    Scores the proposed system using its own structured decisions --
    this is what makes Safe Repair Rate / False Repair Rate computable at
    all, unlike the baselines above.
    """
    detected_columns = {issue.column for issue in final_state.issues if issue.column}
    true_columns = _true_corrupted_columns(ground_truths)
    detection_metrics = metrics.precision_recall_f1(detected_columns, true_columns)

    gt_by_column = {gt["column"]: gt for gt in ground_truths if "column" in gt}
    decisions_by_issue = {d.issue_id: d for d in final_state.decisions}

    scored_repairs = []
    for issue in final_state.issues:
        decision = decisions_by_issue.get(issue.issue_id)
        if decision is None or issue.column not in gt_by_column:
            continue

        gt = gt_by_column[issue.column]
        row_idx = issue.affected_rows[0] if issue.affected_rows else None
        if row_idx is None or row_idx not in gt["true_values"]:
            continue

        true_value = gt["true_values"][row_idx]
        actual_value = output_df.iloc[row_idx][issue.column] if row_idx < len(output_df) else None
        correct = _values_match(actual_value, true_value)

        scored_repairs.append({"outcome": decision.outcome, "correct": correct})

    return {
        "detection": detection_metrics,
        "safe_repair_rate": metrics.safe_repair_rate(scored_repairs),
        "false_repair_rate": metrics.false_repair_rate(scored_repairs),
        "autonomy_rate": metrics.autonomy_rate(scored_repairs),
        "scored_repair_count": len(scored_repairs),
    }


def run_full_evaluation(seed: int = 42) -> dict:
    """
    Runs all three systems against the SAME corrupted scenario and
    returns a comparison dict. The LLM must already be reachable (a real
    `ollama serve` running) OR call_llm must be monkeypatched by the
    caller -- see tests/test_run_evaluation.py for how this is verified
    without a live model.
    """
    corrupted_df, ground_truths = build_benchmark_scenario(seed=seed)

    # --- Baseline 1: rule-based ---
    baseline1_output = run_rule_based_pipeline(corrupted_df)
    baseline1_scores = score_baseline_output(baseline1_output, ground_truths)

    # --- Baseline 2: fixed LLM workflow ---
    baseline2_output = run_fixed_llm_workflow(corrupted_df)
    baseline2_scores = score_baseline_output(baseline2_output, ground_truths)

    # --- Proposed system: full evidence-gated agent ---
    dataset_path = "/tmp/eval_scenario_corrupted.csv"
    corrupted_df.to_csv(dataset_path, index=False)

    graph = build_graph()
    run_id = str(uuid.uuid4())
    initial_state = ForensicsState(run_id=run_id, dataset_path=dataset_path)
    final_state_dict = graph.invoke(initial_state, config={"recursion_limit": 100})
    final_state = ForensicsState(**final_state_dict)

    proposed_output_path = final_state.sandbox_path or dataset_path
    proposed_output = pd.read_csv(proposed_output_path)
    proposed_scores = score_proposed_system(final_state, proposed_output, ground_truths)

    return {
        "baseline1_rule_based": baseline1_scores,
        "baseline2_fixed_llm": baseline2_scores,
        "proposed_system": proposed_scores,
    }


if __name__ == "__main__":
    results = run_full_evaluation()
    import json
    print(json.dumps(results, indent=2, default=str))
