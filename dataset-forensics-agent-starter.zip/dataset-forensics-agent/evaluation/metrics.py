"""
Evaluation metrics. These turn "the system ran" into "the system is
measurably good (or not)" -- this is what your project's research
questions (RQ1-RQ4) actually get answered by.
"""


def precision_recall_f1(detected_columns: set, true_corrupted_columns: set) -> dict:
    """
    Detection quality: of the columns known to be corrupted (ground
    truth), how many did the system actually flag as having an issue
    (recall), and of what it flagged, how much was genuinely corrupted
    (precision)?
    """
    true_positives = len(detected_columns & true_corrupted_columns)
    false_positives = len(detected_columns - true_corrupted_columns)
    false_negatives = len(true_corrupted_columns - detected_columns)

    precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) else 0.0
    recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0

    return {
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "true_positives": true_positives,
        "false_positives": false_positives,
        "false_negatives": false_negatives,
    }


def safe_repair_rate(scored_repairs: list[dict]) -> float | None:
    """
    Safe Repair Rate = correct accepted repairs / total accepted repairs.

    `scored_repairs` is a list of {"outcome": "accepted"/"rejected"/...,
    "correct": bool} dicts, one per issue that reached a final decision.
    Returns None (undefined) if nothing was ever accepted -- this should
    be reported as "N/A", not silently treated as 0% or 100%.
    """
    accepted = [r for r in scored_repairs if r["outcome"] == "accepted"]
    if not accepted:
        return None
    correct = sum(1 for r in accepted if r["correct"])
    return round(correct / len(accepted), 4)


def false_repair_rate(scored_repairs: list[dict]) -> float:
    """
    False Repair Rate = incorrect automatic repairs / total automatic
    repairs. "Automatic" here means the system actually took an action
    (accepted OR rolled_back) rather than abstaining to human_review.
    """
    automatic = [r for r in scored_repairs if r["outcome"] in ("accepted", "rolled_back")]
    if not automatic:
        return 0.0
    incorrect = sum(1 for r in automatic if not r["correct"])
    return round(incorrect / len(automatic), 4)


def autonomy_rate(scored_repairs: list[dict]) -> float:
    """
    Autonomy Rate = fraction of issues resolved WITHOUT human review
    (either accepted or a deliberate, confident rejection) -- measures
    practical efficiency, separately from correctness.
    """
    if not scored_repairs:
        return 0.0
    resolved_without_human = sum(1 for r in scored_repairs if r["outcome"] != "human_review")
    return round(resolved_without_human / len(scored_repairs), 4)


def diagnosis_accuracy(diagnoses: list[dict]) -> float:
    """
    Diagnosis Accuracy = of issues where the agent formed a hypothesis,
    how often did its predicted issue_type match the corruption_type that
    was actually injected (the objective ground truth, since the
    benchmark's corruptions are engineered, not naturally occurring)?

    `diagnoses` is a list of {"predicted_type": str, "true_type": str}.
    """
    if not diagnoses:
        return 0.0
    correct = sum(1 for d in diagnoses if d["predicted_type"] == d["true_type"])
    return round(correct / len(diagnoses), 4)
