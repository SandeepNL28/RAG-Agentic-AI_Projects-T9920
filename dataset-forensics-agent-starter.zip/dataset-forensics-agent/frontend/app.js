// Autonomous Dataset Forensics Agent -- interactive real-time dashboard
//
// This is a genuinely real-time client: instead of polling the API on a
// timer, it opens a WebSocket connection to /runs/{run_id}/live and
// updates the UI the INSTANT each agent step completes on the backend
// (see app/api/routers/runs.py's use of graph.stream() + the event
// broadcaster). Nothing here is faked or simulated for demo purposes.

const API_BASE = window.location.origin;

const els = {
  connStatus: document.getElementById("connStatus"),
  uploadCard: document.getElementById("uploadCard"),
  dropzone: document.getElementById("dropzone"),
  fileInput: document.getElementById("fileInput"),
  dropzoneText: document.getElementById("dropzoneText"),
  runButton: document.getElementById("runButton"),
  progressCard: document.getElementById("progressCard"),
  progressBar: document.getElementById("progressBar"),
  progressLabel: document.getElementById("progressLabel"),
  progressCounts: document.getElementById("progressCounts"),
  liveFeed: document.getElementById("liveFeed"),
  resultsSection: document.getElementById("resultsSection"),
  metricsRow: document.getElementById("metricsRow"),
  issuesBody: document.getElementById("issuesBody"),
  auditTrail: document.getElementById("auditTrail"),
  downloadLink: document.getElementById("downloadLink"),
  errorBanner: document.getElementById("errorBanner"),
};

let selectedFile = null;

// ---------------------------------------------------------------------
// Upload UI wiring
// ---------------------------------------------------------------------

els.dropzone.addEventListener("click", () => els.fileInput.click());

els.dropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  els.dropzone.classList.add("dragover");
});
els.dropzone.addEventListener("dragleave", () => {
  els.dropzone.classList.remove("dragover");
});
els.dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  els.dropzone.classList.remove("dragover");
  if (e.dataTransfer.files.length > 0) {
    setSelectedFile(e.dataTransfer.files[0]);
  }
});

els.fileInput.addEventListener("change", () => {
  if (els.fileInput.files.length > 0) {
    setSelectedFile(els.fileInput.files[0]);
  }
});

function setSelectedFile(file) {
  selectedFile = file;
  els.dropzoneText.textContent = `Selected: ${file.name}`;
  els.runButton.disabled = false;
}

els.runButton.addEventListener("click", startInvestigation);

// ---------------------------------------------------------------------
// Main flow: upload -> start run -> live WebSocket updates -> results
// ---------------------------------------------------------------------

async function startInvestigation() {
  hideError();
  els.runButton.disabled = true;
  setConnStatus("blue", "Uploading...");

  try {
    const datasetId = await uploadDataset(selectedFile);
    const runId = await startRun(datasetId);

    els.uploadCard.classList.add("hidden");
    els.progressCard.classList.remove("hidden");
    setConnStatus("blue", "Investigating...");

    streamRun(runId);
  } catch (err) {
    showError(`Failed to start investigation: ${err.message}`);
    setConnStatus("red", "Error");
    els.runButton.disabled = false;
  }
}

async function uploadDataset(file) {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${API_BASE}/datasets/upload`, {
    method: "POST",
    body: formData,
  });
  if (!response.ok) {
    const detail = await safeJson(response);
    throw new Error(detail?.detail || `Upload failed (${response.status})`);
  }
  const data = await response.json();
  return data.dataset_id;
}

async function startRun(datasetId) {
  const response = await fetch(`${API_BASE}/runs/start?dataset_id=${encodeURIComponent(datasetId)}`, {
    method: "POST",
  });
  if (!response.ok) {
    const detail = await safeJson(response);
    throw new Error(detail?.detail || `Could not start run (${response.status})`);
  }
  const data = await response.json();
  return data.run_id;
}

function streamRun(runId) {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const ws = new WebSocket(`${protocol}//${window.location.host}/runs/${runId}/live`);

  let stepCount = 0;
  // Rough progress estimate: most single-issue investigations take ~4
  // steps (diagnose/repair/validate/plan) per issue plus the initial
  // investigate step. This is a UX approximation, not a precise metric.
  const ESTIMATED_STEPS = 12;

  ws.onopen = () => {
    addFeedItem("connected", "Live connection established.");
  };

  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    handleEvent(data, runId);

    if (data.type === "step_completed") {
      stepCount += 1;
      const pct = Math.min(95, Math.round((stepCount / ESTIMATED_STEPS) * 100));
      els.progressBar.style.width = `${pct}%`;
      els.progressLabel.textContent = `Running: ${data.node}`;
      els.progressCounts.textContent = `${data.issues_so_far} issue(s) found · ${data.decisions_so_far} decision(s) made`;
    }
  };

  ws.onerror = () => {
    showError("Lost connection to the live event stream. The run may still be processing on the server -- refresh to check its final status.");
    setConnStatus("red", "Connection lost");
  };

  ws.onclose = () => {
    // Normal close after run_completed/run_failed is expected and not an error.
  };
}

function handleEvent(data, runId) {
  switch (data.type) {
    case "run_started":
      addFeedItem("started", "Investigation started.");
      break;
    case "step_completed":
      addFeedItem(data.node, describeStep(data.node, data));
      break;
    case "run_completed":
      addFeedItem("done", "Investigation complete. Loading results...");
      els.progressBar.style.width = "100%";
      setConnStatus("green", "Completed");
      loadResults(runId);
      break;
    case "run_failed":
      addFeedItem("failed", `Run failed: ${data.error || "unknown error"}`);
      setConnStatus("red", "Failed");
      showError(`The investigation failed: ${data.error || "unknown error"}`);
      break;
  }
}

function describeStep(node, data) {
  const descriptions = {
    investigate: "Scanning dataset for quality issues...",
    diagnose: "Forming a hypothesis about the current issue...",
    repair: "Evaluating whether enough evidence exists to repair safely...",
    validate: "Validating the outcome and recording a decision...",
    plan: "Deciding what to investigate next...",
  };
  return descriptions[node] || `Step completed: ${node}`;
}

function addFeedItem(badge, text) {
  const item = document.createElement("div");
  item.className = "feed-item";
  item.innerHTML = `<span class="feed-badge">${badge}</span><span class="feed-text">${text}</span>`;
  els.liveFeed.appendChild(item);
  els.liveFeed.scrollTop = els.liveFeed.scrollHeight;
}

// ---------------------------------------------------------------------
// Results rendering
// ---------------------------------------------------------------------

async function loadResults(runId) {
  const [issues, audit] = await Promise.all([
    fetchJson(`${API_BASE}/runs/${runId}/issues`),
    fetchJson(`${API_BASE}/runs/${runId}/audit`),
  ]);

  renderMetrics(issues);
  renderIssuesTable(issues);
  renderAuditTrail(audit);

  els.downloadLink.href = `${API_BASE}/runs/${runId}/download`;

  els.progressCard.classList.add("hidden");
  els.resultsSection.classList.remove("hidden");
}

function renderMetrics(issues) {
  const counts = { accepted: 0, rejected: 0, rolled_back: 0, human_review: 0 };
  issues.forEach((issue) => {
    if (issue.decision) {
      counts[issue.decision.outcome] = (counts[issue.decision.outcome] || 0) + 1;
    }
  });
  const autonomyResolved = counts.accepted + counts.rejected;
  const autonomyRate = issues.length ? Math.round((autonomyResolved / issues.length) * 100) : 0;

  const metrics = [
    { label: "Issues Found", value: issues.length },
    { label: "Accepted Repairs", value: counts.accepted },
    { label: "Rolled Back", value: counts.rolled_back },
    { label: "Human Review", value: counts.human_review },
    { label: "Autonomy Rate", value: `${autonomyRate}%` },
  ];

  els.metricsRow.innerHTML = metrics
    .map((m) => `<div class="metric-card"><div class="metric-value">${m.value}</div><div class="metric-label">${m.label}</div></div>`)
    .join("");
}

function renderIssuesTable(issues) {
  els.issuesBody.innerHTML = issues
    .map((issue) => {
      const outcome = issue.decision ? issue.decision.outcome : "pending";
      const reason = issue.decision ? issue.decision.reason : "";
      return `
        <tr>
          <td>${escapeHtml(issue.column ?? "-")}</td>
          <td>${escapeHtml(issue.issue_type)}</td>
          <td>${escapeHtml(issue.severity)}</td>
          <td>${escapeHtml(issue.raw_observation)}</td>
          <td><span class="badge badge-${outcome}">${outcome.replace("_", " ")}</span></td>
          <td class="muted">${escapeHtml(reason)}</td>
        </tr>`;
    })
    .join("");
}

function renderAuditTrail(entries) {
  els.auditTrail.innerHTML = entries
    .map(
      (entry) => `
      <details class="audit-entry">
        <summary>[${escapeHtml(entry.step)}] ${escapeHtml(entry.reasoning_summary)}</summary>
        <div class="detail">
          <div><strong>Tool used:</strong> ${escapeHtml(entry.tool_used || "n/a")}</div>
          <div><strong>Observation:</strong> ${escapeHtml(entry.observation)}</div>
          ${entry.decision ? `<div><strong>Decision:</strong> ${escapeHtml(entry.decision)}</div>` : ""}
        </div>
      </details>`
    )
    .join("");
}

// ---------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------

function setConnStatus(color, text) {
  els.connStatus.innerHTML = `<span class="dot dot-${color}"></span> ${text}`;
}

function showError(message) {
  els.errorBanner.textContent = message;
  els.errorBanner.classList.remove("hidden");
}
function hideError() {
  els.errorBanner.classList.add("hidden");
}

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Request to ${url} failed (${response.status})`);
  return response.json();
}

async function safeJson(response) {
  try {
    return await response.json();
  } catch {
    return null;
  }
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
