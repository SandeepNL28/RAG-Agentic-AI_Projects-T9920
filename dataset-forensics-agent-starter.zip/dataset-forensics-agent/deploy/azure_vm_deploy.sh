#!/usr/bin/env bash
#
# Deploys the Autonomous Dataset Forensics Agent to a single Azure VM
# using Docker Compose. A VM (not App Service / serverless) is used
# deliberately: Ollama needs a persistent, always-on process with
# predictable CPU/RAM, which serverless platforms handle poorly.
#
# PREREQUISITES:
#   - Azure CLI installed and logged in (`az login`)
#   - An Azure subscription with quota for the chosen VM size
#
# This script provisions the VM and opens the necessary ports. You still
# need to SSH in afterwards to install Docker and pull the code -- see
# the printed instructions at the end.
#
# Usage:
#   chmod +x deploy/azure_vm_deploy.sh
#   ./deploy/azure_vm_deploy.sh

set -euo pipefail

RESOURCE_GROUP="forensics-agent-rg"
LOCATION="eastus"
VM_NAME="forensics-agent-vm"
VM_SIZE="Standard_D4s_v3"   # 4 vCPUs, 16GB RAM -- matches the project's
                             # target hardware profile (CPU-only, 16GB RAM)
ADMIN_USERNAME="azureuser"

echo "== Creating resource group: $RESOURCE_GROUP in $LOCATION =="
az group create --name "$RESOURCE_GROUP" --location "$LOCATION"

echo "== Creating VM: $VM_NAME ($VM_SIZE) =="
az vm create \
  --resource-group "$RESOURCE_GROUP" \
  --name "$VM_NAME" \
  --image "Ubuntu2204" \
  --size "$VM_SIZE" \
  --admin-username "$ADMIN_USERNAME" \
  --generate-ssh-keys

echo "== Opening port 8000 (API + frontend) =="
az vm open-port \
  --resource-group "$RESOURCE_GROUP" \
  --name "$VM_NAME" \
  --port 8000 \
  --priority 900

# Port 11434 (Ollama) is deliberately NOT opened to the public internet --
# it should only be reachable from the API container over the internal
# Docker network, not exposed externally. This is a basic but meaningful
# production security decision.

PUBLIC_IP=$(az vm show \
  --resource-group "$RESOURCE_GROUP" \
  --name "$VM_NAME" \
  --show-details \
  --query publicIps \
  --output tsv)

echo ""
echo "=================================================================="
echo "VM created. Public IP: $PUBLIC_IP"
echo "=================================================================="
echo ""
echo "Next steps -- SSH in and set up Docker:"
echo ""
echo "  ssh ${ADMIN_USERNAME}@${PUBLIC_IP}"
echo ""
echo "  # On the VM:"
echo "  curl -fsSL https://get.docker.com | sudo sh"
echo "  sudo usermod -aG docker \$USER"
echo "  # log out and back in for the group change to take effect, then:"
echo ""
echo "  git clone <your-repo-url> forensics-agent"
echo "  cd forensics-agent"
echo "  cp .env.example .env"
echo "  docker compose -f docker/docker-compose.yml up -d"
echo "  docker compose -f docker/docker-compose.yml exec ollama ollama pull qwen3:4b"
echo ""
echo "  Then visit: http://${PUBLIC_IP}:8000"
echo "=================================================================="
