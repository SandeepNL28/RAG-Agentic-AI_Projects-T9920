# Autonomous Dataset Forensics Agent — Starter Scaffold

This is the Phase-1 starting point for the project: the shared data models
and the first two deterministic quality-analysis tools, fully tested against
a small sample dataset with known, intentional issues.

Nothing here uses the LLM or LangGraph yet — that comes next, once these
tools are solid.

## Fetching the real datasets for this project

Per the project spec, this uses UCI/OpenML datasets. A ready-to-run script
is included:

```powershell
python -m pip install scikit-learn   # already in requirements.txt
python scripts\fetch_datasets.py
```

This downloads and saves three datasets as clean CSVs into
`benchmark/datasets/`:

| File | Rows | Purpose |
|---|---|---|
| `titanic.csv` | 891 | Small, fast to iterate on during early development |
| `adult_income.csv` | ~48,800 | Realistic mix of numeric + categorical for later-stage testing |
| `german_credit.csv` | 1,000 | Rich categorical columns for `category_consistency_analysis()` |

These stay as your **ground truth** — you'll write `benchmark/corrupt.py`
next to create deliberately-corrupted copies of these, so you always know
the "right answer" when scoring the agent later.

## What's included

```
dataset-forensics-agent/
├── app/
│   ├── core/
│   │   ├── config.py      # settings (confidence threshold, paths, etc.)
│   │   └── schemas.py     # Pydantic models: DetectedIssue, Hypothesis,
│   │                      # Evidence, RepairProposal, ForensicsState...
│   └── tools/
│       └── quality_analysis.py   # missing_value_analysis(), outlier_detection(),
│                                  # duplicate_analysis() — no LLM, pure Python
├── sample_data/
│   └── sample_customers.csv      # 10 rows with intentional issues:
│                                  #   - 1 missing age
│                                  #   - 1 missing annual_income
│                                  #   - 1 impossible age (240)
├── tests/
│   └── test_tools.py             # unit tests proving the tools work
└── README.md
```

## How to use this in your existing project folder

Copy the `app/`, `sample_data/`, and `tests/` folders (and this README)
directly into your `C:\LTM-Projects\Agentic_ Ai-Project` folder, merging
with what's already there. Your `requirements.txt` and `.venv` from before
already have everything these files need (pandas, scipy, pydantic,
pydantic-settings, pytest).

## Run the tests

```powershell
cd C:\LTM-Projects\Agentic_ Ai-Project
.venv\Scripts\Activate.ps1
python -m pytest -v
```

You should see 4 tests pass:

```
tests/test_tools.py::test_missing_value_analysis_finds_known_gaps PASSED
tests/test_tools.py::test_outlier_detection_flags_the_age_240_row PASSED
tests/test_tools.py::test_outlier_detection_handles_no_outliers_gracefully PASSED
tests/test_tools.py::test_duplicate_analysis_runs_without_error PASSED
```

## Try it interactively

```powershell
python
>>> import pandas as pd
>>> from app.tools.quality_analysis import missing_value_analysis, outlier_detection
>>> df = pd.read_csv("sample_data/sample_customers.csv")
>>> missing_value_analysis(df)
>>> outlier_detection(df, "age", z_thresh=2.5)
```

## A real bug this scaffold already taught us

The outlier test initially failed at the default z-score threshold (3.0)
because with only 9 data points, a single extreme value (age = 240) inflates
the standard deviation so much it partially "masks" itself — a well-known
limitation of z-score outlier detection on small samples. The test now uses
`z_thresh=2.5` and documents this. Keep this in mind later: the real
Investigation Agent may need a more robust method (e.g. IQR-based detection)
for small or heavily-skewed columns instead of a fixed z-score cutoff.


## Next steps (after this scaffold works for you)

**The benchmark and evaluation framework is now built and tested (99
tests passing) -- this is the final piece from the original roadmap.**
Every research metric the project's RQ1-RQ4 depend on is now computable
with real numbers, not just described.

### What's new

- **`benchmark/corrupt.py`** -- controlled corruption injection (outliers,
  missing values, category noise, duplicates, date-format noise), each
  returning the corrupted data AND a tracked ground_truth record.
- **`evaluation/metrics.py`** -- Precision/Recall/F1, Safe Repair Rate,
  False Repair Rate, Autonomy Rate, Diagnosis Accuracy -- every value
  verified against hand-calculated expected results in
  `tests/test_metrics.py`.
- **`evaluation/baselines/rule_based.py`** (Baseline 1) and
  **`fixed_llm_workflow.py`** (Baseline 2) -- both implemented and tested.
- **`evaluation/run_evaluation.py`** -- runs the REAL proposed system
  (the actual compiled LangGraph pipeline) alongside both baselines on
  the same corrupted scenario, and scores all three against ground truth.

### Run it yourself and see real numbers

```powershell
python -c "
from unittest.mock import patch
from app.agents import diagnosis_agent
from evaluation.baselines import fixed_llm_workflow
from evaluation import run_evaluation
import json

def fake_diagnosis_llm(prompt, expect_json=True):
    return {'explanation': 'test', 'requires_evidence': ['statistical_distribution', 'data_dictionary_rule']}
def fake_baseline_llm(prompt, expect_json=True):
    return {'action': 'impute' if 'impute' in prompt.lower() or 'outlier' in prompt.lower() else 'normalize', 'fixed_value': None}

with patch.object(diagnosis_agent, 'call_llm', fake_diagnosis_llm), \
     patch.object(fixed_llm_workflow, 'call_llm', fake_baseline_llm):
    results = run_evaluation.run_full_evaluation(seed=7)
print(json.dumps(results, indent=2, default=str))
"
```

Or, with `ollama serve` running, remove the `patch.object(...)` mocking
and call `run_evaluation.run_full_evaluation()` directly to get results
from your REAL local Qwen3 4B model instead of a mocked response.

### An honest read of the numbers this produces right now

A real run (seed=7) currently produces: Baseline 1 (rule-based) ~54%
repair accuracy, Baseline 2 (fixed LLM, no gating) ~46% repair accuracy,
and the proposed system: detection F1=0.80, but Safe Repair Rate = `null`
and autonomy rate = 0.0 -- meaning it correctly ABSTAINED rather than
guess, while both baselines went ahead and were wrong roughly half the
time. This is a genuinely good illustration of the core thesis.

**Important caveat, stated directly:** `scored_repair_count` in that run
is only 1 -- meaning just one single issue could be scored against ground
truth. This is partly because `diagnosis_agent.py`'s evidence-gathering is
still hard-coded to only check `data_dictionary_rule` for the `age`
column (a known simplification flagged earlier in this README) -- so the
system structurally can't gather strong evidence for other issue types
yet. **This is a working, correctly-wired evaluation harness producing
real numbers -- it is NOT YET a statistically meaningful research result.**
To get there:

1. Expand `diagnosis_agent.py`'s evidence-gathering to cover more
   evidence types / columns (replace the hard-coded proof-of-concept with
   real data-dictionary lookups).
2. Run `python scripts\fetch_datasets.py` and build corrupted benchmark
   scenarios from the real Titanic/Adult Income/German Credit datasets,
   not just the synthetic 30-row dataset in `run_evaluation.py`.
3. Run the evaluation across MANY seeds/scenarios and aggregate the
   results -- one run is a smoke test, not a research result.
4. Run it against your REAL local LLM (not the mocked response) for
   final reported numbers.

### What's still missing

At this point, every major component from the original project spec
exists as real, tested code: tools, agents, LangGraph orchestration,
evidence-gating, sandbox/rollback, audit trail, FastAPI backend,
real-time WebSocket streaming, an interactive frontend, Docker/Azure
deployment, and now the evaluation framework. What remains is largely
**scaling and depth, not new components**:

- Expanding evidence-gathering coverage (point 1 above)
- Running the evaluation at real research scale (points 2-3 above)
- Building out the literature review, research gap writeup, and final
  report sections that go around this working system
- Actually validating the Docker build and an Azure deployment end-to-end
  on your machine, since neither was executable in the environment that
  built this project

This order matters -- it's what kept the project runnable and testable
at every single stage instead of one big untested leap at the end.
