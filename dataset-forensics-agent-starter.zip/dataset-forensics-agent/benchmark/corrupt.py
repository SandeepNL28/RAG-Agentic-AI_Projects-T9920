"""
Controlled corruption injection. Takes a clean DataFrame and deliberately
breaks it in a KNOWN, TRACKED way -- every function returns both the
corrupted data and a ground_truth record describing exactly what was
changed and what the original value was. This ground truth is what makes
Safe Repair Rate / False Repair Rate measurable at all: without knowing
the true original value, there's no way to know if a repair was correct.
"""

import random
import pandas as pd


def inject_outliers(df: pd.DataFrame, column: str, frac: float = 0.1, factor: float = 10, seed: int = 42) -> tuple[pd.DataFrame, dict]:
    """Multiplies a fraction of a numeric column's values by `factor`, creating extreme outliers."""
    rng = random.Random(seed)
    df = df.copy()
    n_to_corrupt = max(1, int(len(df) * frac))
    idx = rng.sample(list(df.index), n_to_corrupt)

    ground_truth = {"corruption_type": "outlier", "column": column, "true_values": df.loc[idx, column].to_dict()}
    df.loc[idx, column] = df.loc[idx, column] * factor

    return df, ground_truth


def inject_missing_values(df: pd.DataFrame, column: str, frac: float = 0.1, seed: int = 42) -> tuple[pd.DataFrame, dict]:
    """Blanks out a fraction of a column's values."""
    rng = random.Random(seed)
    df = df.copy()
    n_to_corrupt = max(1, int(len(df) * frac))
    idx = rng.sample(list(df.index), n_to_corrupt)

    ground_truth = {"corruption_type": "missing_value", "column": column, "true_values": df.loc[idx, column].to_dict()}
    df.loc[idx, column] = None

    return df, ground_truth


def inject_category_noise(df: pd.DataFrame, column: str, frac: float = 0.3, seed: int = 42) -> tuple[pd.DataFrame, dict]:
    """
    Rewrites a fraction of a categorical column's values into a randomly
    cased variant (e.g. "New York" -> "new york" / "NEW YORK"), simulating
    real-world inconsistent data entry.
    """
    rng = random.Random(seed)
    df = df.copy()
    n_to_corrupt = max(1, int(len(df) * frac))
    idx = rng.sample(list(df.index), n_to_corrupt)

    true_values = df.loc[idx, column].to_dict()
    variant_fns = [str.upper, str.lower, lambda s: s.capitalize()]

    def corrupt_value(value):
        return rng.choice(variant_fns)(str(value))

    ground_truth = {"corruption_type": "category_inconsistency", "column": column, "true_values": true_values}
    df.loc[idx, column] = df.loc[idx, column].apply(corrupt_value)

    return df, ground_truth


def inject_duplicates(df: pd.DataFrame, frac: float = 0.1, seed: int = 42) -> tuple[pd.DataFrame, dict]:
    """Appends exact copies of a random sample of rows to the end of the dataset."""
    rng = random.Random(seed)
    n_to_duplicate = max(1, int(len(df) * frac))
    idx = rng.sample(list(df.index), n_to_duplicate)

    duplicated_rows = df.loc[idx]
    corrupted_df = pd.concat([df, duplicated_rows], ignore_index=True)

    ground_truth = {
        "corruption_type": "duplicate",
        "original_row_count": len(df),
        "expected_duplicate_count": n_to_duplicate,
    }
    return corrupted_df, ground_truth


def inject_date_format_noise(df: pd.DataFrame, column: str, frac: float = 0.3, seed: int = 42) -> tuple[pd.DataFrame, dict]:
    """Rewrites a fraction of ISO-format (YYYY-MM-DD) dates into MM/DD/YYYY format."""
    rng = random.Random(seed)
    df = df.copy()
    n_to_corrupt = max(1, int(len(df) * frac))
    idx = rng.sample(list(df.index), n_to_corrupt)

    true_values = df.loc[idx, column].to_dict()

    def reformat(value):
        year, month, day = str(value).split("-")
        return f"{month}/{day}/{year}"

    ground_truth = {"corruption_type": "date_format", "column": column, "true_values": true_values}
    df.loc[idx, column] = df.loc[idx, column].apply(reformat)

    return df, ground_truth
