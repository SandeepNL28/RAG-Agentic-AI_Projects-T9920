# Deployment Guide

## Option 1: Local Docker Compose (fastest, no cloud account needed)

This runs the entire production stack -- API, real-time frontend, and
Ollama -- on your own machine, exactly as it would run in the cloud.

```bash
cp .env.example .env
docker compose -f docker/docker-compose.yml up -d --build
docker compose -f docker/docker-compose.yml exec ollama ollama pull qwen3:4b
```

Then open **http://localhost:8000** for the live dashboard, or
**http://localhost:8000/docs** for the API documentation.

Check logs / health:
```bash
docker compose -f docker/docker-compose.yml ps
docker compose -f docker/docker-compose.yml logs -f api
```

Stop everything:
```bash
docker compose -f docker/docker-compose.yml down
```

**Honesty note:** I could not actually run `docker build` in the sandbox
that generated this project (no Docker daemon available there), so this
has not been end-to-end verified the way the Python test suite has. The
Dockerfile and Compose file follow standard, correct conventions and the
file paths match this project's real structure, but please run the build
yourself and treat any error output as something to fix, not something
unexpected.

## Option 2: Azure VM (cloud deployment)

A VM is used rather than a serverless platform (Azure App Service,
Container Apps) deliberately: Ollama needs a persistent, always-on
process with predictable CPU/RAM, which serverless platforms are not
well-suited for.

```bash
az login
chmod +x deploy/azure_vm_deploy.sh
./deploy/azure_vm_deploy.sh
```

This provisions a `Standard_D4s_v3` VM (4 vCPUs, 16GB RAM -- matching the
project's target hardware profile), opens port 8000, and prints SSH /
Docker setup instructions for the rest of the deployment.

**Honesty note:** I cannot execute this script myself -- it requires your
own Azure account, credentials, and billing, none of which are available
to me. The `az` CLI commands are correct, standard usage, but you are the
one actually running this deployment, and you should review the VM size
and costs before running it against a real subscription.

## Production Considerations Already Handled

| Concern | How It's Addressed |
|---|---|
| LLM call reliability | `app/llm/ollama_client.py` retries transient failures 3x with exponential backoff |
| Run history durability | `app/api/run_registry.py` is SQLite-backed, survives restarts (tested explicitly) |
| Structured logging | `app/core/logging_config.py` outputs JSON logs, ready to ship to Azure Monitor or any log aggregator |
| Non-root container | `docker/Dockerfile.api` runs as a dedicated `appuser`, not root |
| Health checks | Both containers have Docker healthchecks; the API also exposes `GET /health` |
| CI/CD | `.github/workflows/ci.yml` runs the full test suite + a Docker build check on every push |
| Real-time updates | WebSocket streaming (`/runs/{run_id}/live`), not polling -- see below |

## Production Considerations NOT Yet Handled (Be Honest About These)

These are real, known gaps -- stating them clearly is better than
pretending they don't exist:

- **Single-instance only.** The event broadcaster (`app/api/event_broadcaster.py`)
  and the SQLite databases both assume ONE running API process. A true
  multi-instance production deployment (behind a load balancer, multiple
  replicas) would need a shared pub/sub backend (Redis Streams / Azure
  Service Bus) and a shared database (PostgreSQL) instead. This is
  explicitly flagged in the code comments of both files.
- **No authentication.** Anyone who can reach the API can upload datasets
  and start runs. A real production deployment handling real
  organizational data would need an auth layer (API keys, OAuth, or
  Azure AD integration) in front of this.
- **CORS is wide open (`allow_origins=["*"]`)** in `app/api/main.py` for
  local development convenience -- restrict this to your actual frontend
  origin before deploying somewhere with real external traffic.
- **No rate limiting.** A single user could start many concurrent runs
  and exhaust CPU/RAM on a small VM, since each run does real LLM
  inference.
