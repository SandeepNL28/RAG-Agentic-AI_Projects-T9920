"""
Investigation Agent -- gathers raw facts. No LLM is used here at all;
this node purely calls the deterministic tools built earlier and converts
their output into DetectedIssue records.
"""

import uuid
import pandas as pd

from app.core.schemas import ForensicsState, DetectedIssue
from app.audit.audit_logger import log, AuditEntry
from app.tools.quality_analysis import (
    missing_value_analysis,
    outlier_detection,
    category_consistency_analysis,
    date_format_consistency,
)


def _new_id() -> str:
    return str(uuid.uuid4())


def run(state: ForensicsState) -> ForensicsState:
    df = pd.read_csv(state.dataset_path)

    # --- Missing values ---
    missing = missing_value_analysis(df)
    for column, info in missing.items():
        state.issues.append(DetectedIssue(
            issue_id=_new_id(),
            column=column,
            issue_type="missing_value",
            severity="medium" if info["missing_pct"] < 20 else "high",
            affected_rows=info["affected_rows"],
            raw_observation=f"{info['missing_count']} missing value(s) ({info['missing_pct']}%).",
        ))

    # --- Outliers (numeric columns only) ---
    for column in df.select_dtypes(include="number").columns:
        result = outlier_detection(df, column)
        if result["flagged_rows"]:
            state.issues.append(DetectedIssue(
                issue_id=_new_id(),
                column=column,
                issue_type="outlier",
                severity="high",
                affected_rows=result["flagged_rows"],
                raw_observation=result["summary"],
            ))

    # --- Category inconsistencies (text/string columns only) ---
    # Using is_string_dtype() rather than select_dtypes(include="object"/"str")
    # since that selector's behavior changed between pandas 2.x and 3.x --
    # this way the agent behaves the same regardless of which pandas version
    # ends up installed.
    for column in df.columns:
        if pd.api.types.is_string_dtype(df[column]):
            result = category_consistency_analysis(df, column)
            if result["inconsistent_groups"]:
                state.issues.append(DetectedIssue(
                    issue_id=_new_id(),
                    column=column,
                    issue_type="category_inconsistency",
                    severity="low",
                    affected_rows=result["affected_rows"],
                    raw_observation=result["summary"],
                ))

    # --- Date-format inconsistencies (columns with "date" in the name) ---
    for column in [c for c in df.columns if "date" in c.lower()]:
        result = date_format_consistency(df, column)
        if result["flagged_rows"]:
            state.issues.append(DetectedIssue(
                issue_id=_new_id(),
                column=column,
                issue_type="date_format",
                severity="medium",
                affected_rows=result["flagged_rows"],
                raw_observation=result["summary"],
            ))

    log(AuditEntry(
        run_id=state.run_id,
        step="investigate",
        tool_used="missing_value_analysis, outlier_detection, category_consistency_analysis, date_format_consistency",
        observation=f"Investigation complete: {len(state.issues)} issue(s) detected across the dataset.",
        reasoning_summary="Ran all deterministic inspection tools across every applicable column.",
    ))

    return state
