"""
Repair Agent -- proposes a fix and estimates confidence, but only ever
applies it to a SANDBOX copy, and only if confidence clears
settings.confidence_threshold. No LLM is used here -- the repair action
itself is deterministic; only the earlier Diagnosis step used the LLM.
"""

import pandas as pd

from app.core.config import settings
from app.core.schemas import ForensicsState, RepairProposal, DetectedIssue, Hypothesis
from app.evidence.scoring import estimate_confidence
from app.sandbox import sandbox_manager
from app.audit.audit_logger import log, AuditEntry
from app.tools import repair as repair_tools
from app.tools.quality_analysis import category_consistency_analysis

# Maps an issue_type to which repair tool handles it.
_ACTION_FOR_ISSUE_TYPE = {
    "missing_value": "impute_missing_values",
    "category_inconsistency": "normalize_categories",
    "date_format": "standardize_dates",
    "duplicate": "remove_exact_duplicates",
    "outlier": "manual_value_correction",  # no safe automatic action defined yet
    "type_error": "correct_data_types",
    "constraint_violation": "manual_value_correction",
}


def _get_issue(state: ForensicsState, issue_id: str) -> DetectedIssue:
    return next(i for i in state.issues if i.issue_id == issue_id)


def _get_hypothesis(state: ForensicsState, issue_id: str) -> Hypothesis | None:
    return next((h for h in state.hypotheses if h.issue_id == issue_id), None)


def _apply_repair(action: str, df_path: str, issue: DetectedIssue) -> None:
    """Applies the chosen repair tool to the sandboxed file in place."""
    df = pd.read_csv(df_path)

    if action == "impute_missing_values":
        df = repair_tools.impute_missing_values(df, issue.column, strategy="median")
    elif action == "normalize_categories":
        detection = category_consistency_analysis(df, issue.column)
        df = repair_tools.normalize_categories(df, issue.column, detection["inconsistent_groups"])
    elif action == "standardize_dates":
        df = repair_tools.standardize_dates(df, issue.column)
    elif action == "remove_exact_duplicates":
        df = repair_tools.remove_exact_duplicates(df)
    else:
        return  # no safe automatic action -- leave the sandbox file unchanged

    df.to_csv(df_path, index=False)


def run(state: ForensicsState) -> ForensicsState:
    issue = _get_issue(state, state.current_issue_id)
    hypothesis = _get_hypothesis(state, issue.issue_id)
    evidence_for_issue = [e for e in state.evidence if e.issue_id == issue.issue_id]

    confidence = estimate_confidence(evidence_for_issue)
    action = _ACTION_FOR_ISSUE_TYPE.get(issue.issue_type, "manual_value_correction")

    proposal = RepairProposal(
        issue_id=issue.issue_id,
        action=action,
        confidence=confidence,
        rationale=hypothesis.explanation if hypothesis else "No hypothesis available.",
    )
    state.proposals.append(proposal)

    if confidence >= settings.confidence_threshold and action != "manual_value_correction":
        if state.sandbox_path is None:
            state.sandbox_path = sandbox_manager.create_sandbox(state.dataset_path)
        _apply_repair(action, state.sandbox_path, issue)
        repair_note = f"Confidence {confidence:.2f} cleared threshold -- repair applied to sandbox."
    else:
        repair_note = f"Confidence {confidence:.2f} did not clear threshold -- no repair applied."

    log(AuditEntry(
        run_id=state.run_id,
        issue_id=issue.issue_id,
        step="repair",
        tool_used=action,
        observation=f"Proposed action: {action} (confidence={confidence:.2f}).",
        reasoning_summary=f"{proposal.rationale} {repair_note}",
    ))

    return state
