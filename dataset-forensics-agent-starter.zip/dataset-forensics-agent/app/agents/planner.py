"""
Planner / Orchestrator -- decides which specialist node should act next,
based on the full current state. Deliberately rule-based (not LLM-driven)
for now -- predictable, debuggable routing, per the implementation guide's
recommendation to only upgrade to LLM-based planning after this version is
well-tested.
"""

from app.core.schemas import ForensicsState


def _has_decision(state: ForensicsState, issue_id: str) -> bool:
    return any(d.issue_id == issue_id for d in state.decisions)


def run(state: ForensicsState) -> ForensicsState:
    if not state.issues:
        state.next_step = "investigate"
        return state

    open_issue = next(
        (i for i in state.issues if not _has_decision(state, i.issue_id)), None
    )

    if open_issue is None:
        state.next_step = "done"
        return state

    state.current_issue_id = open_issue.issue_id

    has_hypothesis = any(h.issue_id == open_issue.issue_id for h in state.hypotheses)
    has_proposal = any(p.issue_id == open_issue.issue_id for p in state.proposals)
    has_validation_attempt = any(
        d.issue_id == open_issue.issue_id for d in state.decisions
    )

    if not has_hypothesis:
        state.next_step = "diagnose"
    elif not has_proposal:
        state.next_step = "repair"
    elif not has_validation_attempt:
        state.next_step = "validate"
    else:
        state.next_step = "done"  # shouldn't normally reach here

    return state
