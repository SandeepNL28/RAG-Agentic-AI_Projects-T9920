"""
Diagnosis Agent -- the FIRST place an LLM is used in the whole pipeline.

Given a DetectedIssue, this asks the LLM to propose an explanation
(Hypothesis) and list what evidence would confirm it, in strict JSON.
It then gathers that evidence using the deterministic tools we already
built (never the LLM itself -- evidence-gathering stays deterministic).
"""

import pandas as pd

from app.core.schemas import ForensicsState, Hypothesis, Evidence, DetectedIssue
from app.llm.ollama_client import call_llm
from app.audit.audit_logger import log, AuditEntry
from app.tools.quality_analysis import constraint_check, distribution_analysis

DIAGNOSIS_PROMPT = """You are a data-quality diagnostician. Given this detected \
issue, propose the most likely explanation and list what evidence would help \
confirm it.

Respond ONLY with JSON in this exact shape, nothing else:
{{"explanation": "<your explanation>", "requires_evidence": ["<evidence type>", ...]}}

Valid evidence types: "data_dictionary_rule", "related_column_consistency", \
"statistical_distribution", "pattern_frequency"

Issue type: {issue_type}
Column: {column}
Observation: {observation}
"""


def _get_issue(state: ForensicsState, issue_id: str) -> DetectedIssue:
    return next(i for i in state.issues if i.issue_id == issue_id)


def _gather_evidence(state: ForensicsState, issue: DetectedIssue, evidence_types: list[str]) -> None:
    """
    Deterministically gathers evidence for each requested type. This is
    intentionally simple in this scaffold -- a real system would check
    an actual data dictionary; here, "data_dictionary_rule" checks a
    hard-coded constraint (age 0-120) as a stand-in, which is enough to
    prove the evidence-gating math works end-to-end.
    """
    df = pd.read_csv(state.dataset_path)

    for evidence_type in evidence_types:
        if evidence_type == "data_dictionary_rule" and issue.column == "age":
            result = constraint_check(df, {"age": {"min": 0, "max": 120}})
            supports = issue.column in result["violations"]
            state.evidence.append(Evidence(
                issue_id=issue.issue_id,
                source="data_dictionary_rule",
                finding="Age must be between 0 and 120 per standard demographic constraints.",
                supports_hypothesis=supports,
            ))

        elif evidence_type == "statistical_distribution" and issue.column:
            dist = distribution_analysis(df, issue.column) if issue.column in df.select_dtypes(include="number").columns else None
            if dist and "mean" in dist:
                state.evidence.append(Evidence(
                    issue_id=issue.issue_id,
                    source="statistical_distribution",
                    finding=dist["summary"],
                    supports_hypothesis=True,
                ))


def run(state: ForensicsState) -> ForensicsState:
    issue = _get_issue(state, state.current_issue_id)

    prompt = DIAGNOSIS_PROMPT.format(
        issue_type=issue.issue_type,
        column=issue.column,
        observation=issue.raw_observation,
    )
    response = call_llm(prompt, expect_json=True)

    hypothesis = Hypothesis(
        issue_id=issue.issue_id,
        explanation=response["explanation"],
        requires_evidence=response.get("requires_evidence", []),
    )
    state.hypotheses.append(hypothesis)

    _gather_evidence(state, issue, hypothesis.requires_evidence)

    log(AuditEntry(
        run_id=state.run_id,
        issue_id=issue.issue_id,
        step="diagnose",
        tool_used="LLM (Ollama)",
        observation=issue.raw_observation,
        reasoning_summary=hypothesis.explanation,
    ))

    return state
