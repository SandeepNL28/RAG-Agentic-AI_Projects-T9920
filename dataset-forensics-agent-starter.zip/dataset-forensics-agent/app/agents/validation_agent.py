"""
Validation Agent -- the last checkpoint. Decides accepted / rejected /
rolled_back / human_review for each issue, based on the repair's
confidence AND whether the sandboxed result actually passes validation.
No LLM used here -- this stays fully deterministic on purpose.
"""

import pandas as pd

from app.core.config import settings
from app.core.schemas import ForensicsState, ValidationResult, Decision, DetectedIssue, RepairProposal
from app.sandbox import sandbox_manager
from app.audit.audit_logger import log, AuditEntry
from app.tools.validation import validate_schema, check_data_loss


def _get_issue(state: ForensicsState, issue_id: str) -> DetectedIssue:
    return next(i for i in state.issues if i.issue_id == issue_id)


def _get_proposal(state: ForensicsState, issue_id: str) -> RepairProposal:
    return next(p for p in state.proposals if p.issue_id == issue_id)


def run(state: ForensicsState) -> ForensicsState:
    issue = _get_issue(state, state.current_issue_id)
    proposal = _get_proposal(state, issue.issue_id)

    # Case 1: confidence never cleared the gate -- Repair Agent abstained.
    if proposal.confidence < settings.confidence_threshold:
        decision = Decision(
            issue_id=issue.issue_id,
            outcome="human_review",
            reason=f"Confidence {proposal.confidence:.2f} below threshold "
                   f"{settings.confidence_threshold:.2f}; evidence insufficient.",
        )
        state.decisions.append(decision)
        log(AuditEntry(
            run_id=state.run_id, issue_id=issue.issue_id, step="validate",
            observation="Repair Agent did not attempt a repair (low confidence).",
            reasoning_summary=decision.reason, decision=decision.outcome,
        ))
        return state

    # Case 2: a repair action wasn't defined for this issue type at all.
    if proposal.action == "manual_value_correction" or state.sandbox_path is None:
        decision = Decision(
            issue_id=issue.issue_id,
            outcome="human_review",
            reason="No safe automatic repair action is defined for this issue type.",
        )
        state.decisions.append(decision)
        log(AuditEntry(
            run_id=state.run_id, issue_id=issue.issue_id, step="validate",
            observation="No automatic repair action exists for this issue type.",
            reasoning_summary=decision.reason, decision=decision.outcome,
        ))
        return state

    # Case 3: a repair was applied to the sandbox -- validate it.
    original_df = pd.read_csv(state.dataset_path)
    sandboxed_df = pd.read_csv(state.sandbox_path)

    # duplicate removal legitimately reduces row count; everything else shouldn't
    max_allowed_decrease = len(original_df) - len(sandboxed_df) if proposal.action == "remove_exact_duplicates" else 0

    schema_check = validate_schema(original_df, sandboxed_df)
    loss_check = check_data_loss(original_df, sandboxed_df, max_allowed_row_decrease=max_allowed_decrease)

    checks = {
        "schema_ok": schema_check["passed"],
        "no_unexpected_data_loss": loss_check["passed"],
    }
    passed = all(checks.values())

    state.validations.append(ValidationResult(
        issue_id=issue.issue_id,
        passed=passed,
        checks=checks,
        notes="All checks passed." if passed else "One or more validation checks failed.",
    ))

    if passed:
        decision = Decision(
            issue_id=issue.issue_id,
            outcome="accepted",
            reason="Repair validated successfully in sandbox.",
        )
    else:
        sandbox_manager.discard_sandbox(state.sandbox_path)
        state.sandbox_path = None
        decision = Decision(
            issue_id=issue.issue_id,
            outcome="rolled_back",
            reason=f"Validation failed: {schema_check['summary']} / {loss_check['summary']}",
        )

    state.decisions.append(decision)
    log(AuditEntry(
        run_id=state.run_id, issue_id=issue.issue_id, step="validate",
        tool_used="validate_schema, check_data_loss",
        observation=f"Validation checks: {checks}",
        reasoning_summary=decision.reason, decision=decision.outcome,
    ))

    return state
