"""
Builds the LangGraph state machine that connects the Planner and the four
specialist agents. This is the actual orchestration layer -- everything
built so far (tools, agents) gets wired together here.
"""

from langgraph.graph import StateGraph, END

from app.core.schemas import ForensicsState
from app.agents import planner, investigation_agent, diagnosis_agent, repair_agent, validation_agent


def build_graph():
    graph = StateGraph(ForensicsState)

    graph.add_node("plan", planner.run)
    graph.add_node("investigate", investigation_agent.run)
    graph.add_node("diagnose", diagnosis_agent.run)
    graph.add_node("repair", repair_agent.run)
    graph.add_node("validate", validation_agent.run)

    graph.set_entry_point("plan")

    graph.add_conditional_edges(
        "plan",
        lambda state: state.next_step,
        {
            "investigate": "investigate",
            "diagnose": "diagnose",
            "repair": "repair",
            "validate": "validate",
            "done": END,
        },
    )
    # Every specialist hands control back to the Planner, which re-evaluates
    # the whole state and decides what's needed next -- this is what lets
    # the system loop (e.g. re-investigate) instead of running as a fixed
    # linear script.
    graph.add_edge("investigate", "plan")
    graph.add_edge("diagnose", "plan")
    graph.add_edge("repair", "plan")
    graph.add_edge("validate", "plan")

    return graph.compile()
