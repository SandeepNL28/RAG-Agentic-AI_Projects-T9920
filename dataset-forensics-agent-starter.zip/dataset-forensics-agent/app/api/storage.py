"""
Handles where dataset files actually live on disk. Deliberately simple
(plain files, UUID-named folders) -- per the earlier design discussion,
datasets are files, not database rows; only structured metadata (the
audit trail) goes into a database.
"""

import os
import shutil
import uuid

UPLOAD_DIR = "data/uploads"
OUTPUT_DIR = "data/outputs"


def save_upload(file_bytes: bytes, original_filename: str) -> tuple[str, str]:
    """
    Saves an uploaded file to its own dataset_id-named folder, keeping the
    original filename so extensions (.csv/.xlsx) are preserved for pandas.
    Returns (dataset_id, saved_path).
    """
    dataset_id = str(uuid.uuid4())
    dataset_dir = os.path.join(UPLOAD_DIR, dataset_id)
    os.makedirs(dataset_dir, exist_ok=True)

    saved_path = os.path.join(dataset_dir, original_filename)
    with open(saved_path, "wb") as f:
        f.write(file_bytes)

    return dataset_id, saved_path


def dataset_path_for(dataset_id: str) -> str | None:
    """Finds the uploaded file for a dataset_id, regardless of its original filename."""
    dataset_dir = os.path.join(UPLOAD_DIR, dataset_id)
    if not os.path.isdir(dataset_dir):
        return None
    files = os.listdir(dataset_dir)
    return os.path.join(dataset_dir, files[0]) if files else None


def save_output(run_id: str, source_path: str) -> str:
    """Copies the final (repaired or original) dataset into the outputs folder for download."""
    output_dir = os.path.join(OUTPUT_DIR, run_id)
    os.makedirs(output_dir, exist_ok=True)
    ext = os.path.splitext(source_path)[1] or ".csv"
    output_path = os.path.join(output_dir, f"cleaned{ext}")
    shutil.copy(source_path, output_path)
    return output_path
