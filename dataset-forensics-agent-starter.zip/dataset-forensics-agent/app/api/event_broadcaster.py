"""
In-process event broadcaster for real-time run updates.

THREADING NOTE (a genuine bug caught during testing, fixed here): the
investigation run itself executes in a background WORKER THREAD (FastAPI's
BackgroundTasks runs sync functions via a thread pool), while WebSocket
clients are served on the main asyncio event loop. Calling
`asyncio.Queue.put_nowait()` directly from a different OS thread than the
one running the event loop does NOT reliably wake up a waiting
`await queue.get()` -- asyncio's internal wakeup mechanism assumes it's
being called from the loop's own thread. The fix is to capture each
queue's owning event loop at subscribe time and marshal every publish()
back onto that loop via `loop.call_soon_threadsafe()`.

SCOPE NOTE (production honesty): this uses an in-memory per-process
broadcaster, which works correctly for a single-process deployment (one
uvicorn worker). A true multi-instance production deployment (e.g. behind
a load balancer with several API replicas) would need a shared pub/sub
backend (Redis Streams / Azure Service Bus) instead, since a WebSocket
client connected to instance A wouldn't see events published by instance
B. This is flagged explicitly rather than silently assumed away.
"""

import asyncio
from datetime import datetime, timezone
from typing import Any


class RunEventBroadcaster:
    def __init__(self):
        # Each run_id maps to a list of (queue, owning_event_loop) pairs.
        self._subscribers: dict[str, list[tuple[asyncio.Queue, asyncio.AbstractEventLoop]]] = {}

    def subscribe(self, run_id: str) -> asyncio.Queue:
        """Must be called from within the event loop that will consume the queue."""
        queue: asyncio.Queue = asyncio.Queue()
        loop = asyncio.get_running_loop()
        self._subscribers.setdefault(run_id, []).append((queue, loop))
        return queue

    def unsubscribe(self, run_id: str, queue: asyncio.Queue) -> None:
        subs = self._subscribers.get(run_id, [])
        self._subscribers[run_id] = [(q, l) for (q, l) in subs if q is not queue]

    def publish(self, run_id: str, event_type: str, data: dict[str, Any]) -> None:
        """
        Publishes an event to every currently-subscribed WebSocket client
        for this run. Safe to call from ANY thread (this is what fixes the
        cross-thread hang) -- each subscriber's put_nowait is scheduled
        back onto its own owning event loop via call_soon_threadsafe.

        Safe to call even if nobody is listening yet (the event is simply
        dropped -- the audit trail in the database remains the permanent
        record regardless).
        """
        event = {
            "type": event_type,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **data,
        }
        for queue, loop in self._subscribers.get(run_id, []):
            loop.call_soon_threadsafe(queue.put_nowait, event)


# Single shared broadcaster for the whole application process.
broadcaster = RunEventBroadcaster()

