"""
Tracks the status and results of each investigation run, persisted to
SQLite so run history survives a server restart -- replacing the earlier
in-memory-only version, which lost everything on restart (a real gap for
anything called "production").

SCOPE NOTE (still honest about limits): this is a single-file SQLite
database, appropriate for a single-instance deployment. A true
multi-instance production deployment behind a load balancer would need a
shared database (e.g. PostgreSQL) instead, since multiple API replicas
can't safely share one SQLite file under concurrent write load. This is
the same class of limitation as the event broadcaster's -- flagged
explicitly rather than silently assumed away.
"""

import json
from typing import Literal, Optional

from sqlmodel import SQLModel, Field, create_engine, Session, select

from app.core.config import settings

RunStatus = Literal["pending", "running", "completed", "failed"]


class RunRecordDB(SQLModel, table=True):
    """The actual database row -- final_state is stored as a JSON string
    since SQLite has no native nested-object column type. `status` is a
    plain str here (not the Literal type) since SQLModel/SQLAlchemy can't
    map typing.Literal to a column type -- validation of allowed values
    happens on the RunRecord view instead."""
    run_id: str = Field(primary_key=True)
    dataset_id: str
    status: str = "pending"
    error: Optional[str] = None
    final_state_json: Optional[str] = None
    output_path: Optional[str] = None


class RunRecord(SQLModel):
    """The Python-friendly view returned to callers -- final_state is a
    real dict here, not a JSON string."""
    run_id: str
    dataset_id: str
    status: RunStatus = "pending"
    error: Optional[str] = None
    final_state: Optional[dict] = None
    output_path: Optional[str] = None


_engine = None
_current_db_path = None


def get_engine():
    global _engine, _current_db_path
    if _engine is None or _current_db_path != settings.run_registry_db_path:
        _engine = create_engine(f"sqlite:///{settings.run_registry_db_path}")
        SQLModel.metadata.create_all(_engine)
        _current_db_path = settings.run_registry_db_path
    return _engine


def _to_record(db_row: RunRecordDB) -> RunRecord:
    return RunRecord(
        run_id=db_row.run_id,
        dataset_id=db_row.dataset_id,
        status=db_row.status,
        error=db_row.error,
        final_state=json.loads(db_row.final_state_json) if db_row.final_state_json else None,
        output_path=db_row.output_path,
    )


def create_run(run_id: str, dataset_id: str) -> RunRecord:
    engine = get_engine()
    with Session(engine) as session:
        db_row = RunRecordDB(run_id=run_id, dataset_id=dataset_id, status="pending")
        session.add(db_row)
        session.commit()
        session.refresh(db_row)
        return _to_record(db_row)


def get_run(run_id: str) -> Optional[RunRecord]:
    engine = get_engine()
    with Session(engine) as session:
        db_row = session.get(RunRecordDB, run_id)
        return _to_record(db_row) if db_row else None


def update_run(run_id: str, **fields) -> None:
    engine = get_engine()
    with Session(engine) as session:
        db_row = session.get(RunRecordDB, run_id)
        if db_row is None:
            return
        for key, value in fields.items():
            if key == "final_state":
                db_row.final_state_json = json.dumps(value) if value is not None else None
            else:
                setattr(db_row, key, value)
        session.add(db_row)
        session.commit()


def list_runs(limit: int = 50) -> list[RunRecord]:
    """Returns the most recent runs -- useful for a future 'run history' UI panel."""
    engine = get_engine()
    with Session(engine) as session:
        statement = select(RunRecordDB).order_by(RunRecordDB.run_id.desc()).limit(limit)
        return [_to_record(row) for row in session.exec(statement)]
