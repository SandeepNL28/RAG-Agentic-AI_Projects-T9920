"""
Endpoints for starting an investigation run, retrieving its results, and
streaming its progress live over WebSocket.
"""

import os
import uuid

from fastapi import APIRouter, BackgroundTasks, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse

from app.api import storage, run_registry
from app.api.event_broadcaster import broadcaster
from app.core.schemas import ForensicsState
from app.graph.workflow import build_graph
from app.audit.audit_logger import get_trail_for_run

router = APIRouter(prefix="/runs", tags=["runs"])


def _execute_run(run_id: str, dataset_id: str, dataset_path: str) -> None:
    run_registry.update_run(run_id, status="running")
    broadcaster.publish(run_id, "run_started", {"dataset_id": dataset_id})

    try:
        graph = build_graph()
        initial_state = ForensicsState(run_id=run_id, dataset_path=dataset_path)

        final_state_dict = initial_state.model_dump()
        # .stream() yields control back to us after EVERY node executes --
        # this is what makes the WebSocket feed genuinely real-time rather
        # than only reporting a result once the whole run is finished.
        for step_output in graph.stream(initial_state, config={"recursion_limit": 100}):
            node_name, node_state = next(iter(step_output.items()))
            final_state_dict = node_state if isinstance(node_state, dict) else node_state.model_dump()

            broadcaster.publish(run_id, "step_completed", {
                "node": node_name,
                "issues_so_far": len(final_state_dict.get("issues", [])),
                "decisions_so_far": len(final_state_dict.get("decisions", [])),
            })

        final_state = ForensicsState(**final_state_dict)

        # The final deliverable: sandboxed (repaired) file if one exists,
        # otherwise the original is copied through untouched.
        source_for_output = final_state.sandbox_path or dataset_path
        output_path = storage.save_output(run_id, source_for_output)

        run_registry.update_run(
            run_id,
            status="completed",
            final_state=final_state.model_dump(),
            output_path=output_path,
        )
        broadcaster.publish(run_id, "run_completed", {
            "issue_count": len(final_state.issues),
            "decision_count": len(final_state.decisions),
        })
    except Exception as exc:  # noqa: BLE001 -- surfaced to the API caller, not swallowed
        run_registry.update_run(run_id, status="failed", error=str(exc))
        broadcaster.publish(run_id, "run_failed", {"error": str(exc)})


@router.post("/start")
def start_run(dataset_id: str, background_tasks: BackgroundTasks):
    dataset_path = storage.dataset_path_for(dataset_id)
    if dataset_path is None:
        raise HTTPException(status_code=404, detail=f"No dataset found for dataset_id={dataset_id}")

    run_id = str(uuid.uuid4())
    run_registry.create_run(run_id, dataset_id)
    background_tasks.add_task(_execute_run, run_id, dataset_id, dataset_path)

    return {"run_id": run_id, "status": "pending"}


@router.get("/{run_id}/status")
def get_status(run_id: str):
    record = run_registry.get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"No run found for run_id={run_id}")
    return {"run_id": run_id, "status": record.status, "error": record.error}


@router.get("/{run_id}/issues")
def get_issues(run_id: str):
    record = run_registry.get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"No run found for run_id={run_id}")
    if record.status != "completed":
        raise HTTPException(status_code=409, detail=f"Run is not completed yet (status={record.status}).")

    issues = record.final_state["issues"]
    decisions = {d["issue_id"]: d for d in record.final_state["decisions"]}

    return [
        {**issue, "decision": decisions.get(issue["issue_id"])}
        for issue in issues
    ]


@router.get("/{run_id}/audit")
def get_audit(run_id: str):
    record = run_registry.get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"No run found for run_id={run_id}")

    entries = get_trail_for_run(run_id)
    return [
        {
            "step": e.step,
            "issue_id": e.issue_id,
            "tool_used": e.tool_used,
            "observation": e.observation,
            "reasoning_summary": e.reasoning_summary,
            "decision": e.decision,
            "timestamp": e.timestamp.isoformat(),
        }
        for e in entries
    ]


@router.get("/{run_id}/download")
def download_result(run_id: str):
    record = run_registry.get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"No run found for run_id={run_id}")
    if record.status != "completed" or not record.output_path:
        raise HTTPException(status_code=409, detail=f"Run is not completed yet (status={record.status}).")
    if not os.path.exists(record.output_path):
        raise HTTPException(status_code=404, detail="Output file no longer exists.")

    return FileResponse(record.output_path, filename=os.path.basename(record.output_path))


@router.websocket("/{run_id}/live")
async def stream_run_progress(websocket: WebSocket, run_id: str):
    """
    Streams live events for a run as they happen: run_started,
    step_completed (fired after every single LangGraph node execution),
    run_completed, run_failed. This is what makes the frontend feel
    real-time instead of relying on polling.

    If the run has ALREADY finished by the time a client connects (e.g. a
    slow page load), an immediate replay event is sent so the UI doesn't
    appear to hang waiting for events that already happened.
    """
    await websocket.accept()

    record = run_registry.get_run(run_id)
    if record is not None and record.status in ("completed", "failed"):
        await websocket.send_json({
            "type": "run_completed" if record.status == "completed" else "run_failed",
            "replay": True,
            "status": record.status,
            "error": record.error,
        })
        await websocket.close()
        return

    queue = broadcaster.subscribe(run_id)
    try:
        while True:
            event = await queue.get()
            await websocket.send_json(event)
            if event["type"] in ("run_completed", "run_failed"):
                break
    except WebSocketDisconnect:
        pass
    finally:
        broadcaster.unsubscribe(run_id, queue)
