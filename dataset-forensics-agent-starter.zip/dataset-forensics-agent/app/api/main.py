"""
FastAPI application entrypoint.

Run locally with:
    uvicorn app.api.main:app --reload --port 8000

Then visit http://localhost:8000/ for the live interactive dashboard, or
http://localhost:8000/docs for interactive API documentation.
"""

import os

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from app.api.routers import datasets, runs
from app.core.logging_config import configure_logging

configure_logging()

app = FastAPI(
    title="Autonomous Dataset Forensics Agent",
    description="Evidence-gated autonomous data quality investigation, safe repair, and validation.",
    version="0.1.0",
)

# CORS: permissive by default for local development. In a real production
# deployment, replace "*" with the actual frontend origin(s) -- left wide
# open here is a known, deliberate simplification for this project's scope.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(datasets.router)
app.include_router(runs.router)


@app.get("/health")
def health_check():
    return {"status": "ok"}


# Serves the interactive frontend (index.html, app.js, styles.css).
# Registered LAST and mounted at "/" so it acts as a catch-all -- the API
# routes above are matched first since Starlette checks explicit routes
# before falling through to a mount.
_frontend_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "frontend")
if os.path.isdir(_frontend_dir):
    app.mount("/", StaticFiles(directory=_frontend_dir, html=True), name="frontend")

