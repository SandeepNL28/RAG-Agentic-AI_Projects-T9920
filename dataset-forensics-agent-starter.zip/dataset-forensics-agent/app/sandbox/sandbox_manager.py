"""
Manages disposable sandbox copies of a dataset. Repairs are ALWAYS applied
to the file this module returns, never to the original dataset_path -- this
is the structural enforcement of the "never touch the original" safety rule.
"""

import os
import shutil
import uuid

from app.core.config import settings


def create_sandbox(original_path: str) -> str:
    """Copies the dataset to a new disposable file and returns its path."""
    os.makedirs(settings.sandbox_dir, exist_ok=True)
    ext = os.path.splitext(original_path)[1] or ".csv"
    sandbox_path = os.path.join(settings.sandbox_dir, f"{uuid.uuid4()}{ext}")
    shutil.copy(original_path, sandbox_path)
    return sandbox_path


def discard_sandbox(sandbox_path: str) -> None:
    """Deletes a sandbox copy -- used when a repair is rolled back."""
    if sandbox_path and os.path.exists(sandbox_path):
        os.remove(sandbox_path)
