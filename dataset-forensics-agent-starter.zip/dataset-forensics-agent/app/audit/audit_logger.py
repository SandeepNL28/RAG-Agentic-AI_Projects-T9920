"""
Persistent audit trail. Every agent step writes one AuditEntry here --
this is what the dashboard's "Agent Trajectory" panel will eventually
read from, and it's what makes every decision traceable after the fact.

The engine is created lazily via get_engine() rather than at import time,
so tests can point it at a temporary database instead of the real one.
"""

from datetime import datetime, timezone
from typing import Optional

from sqlmodel import SQLModel, Field, create_engine, Session, select

from app.core.config import settings


class AuditEntry(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    run_id: str
    issue_id: Optional[str] = None
    step: str  # "investigate", "diagnose", "repair", "validate"
    tool_used: Optional[str] = None
    observation: str
    reasoning_summary: str
    decision: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


_engine = None
_current_db_path = None


def get_engine():
    """
    Returns a SQLModel engine pointed at settings.audit_db_path, creating
    it (and the table) on first use. Recreated automatically if the
    configured path changes -- this is what lets tests safely redirect
    logging to a temporary file without touching the real audit trail.
    """
    global _engine, _current_db_path

    if _engine is None or _current_db_path != settings.audit_db_path:
        _engine = create_engine(f"sqlite:///{settings.audit_db_path}")
        SQLModel.metadata.create_all(_engine)
        _current_db_path = settings.audit_db_path

    return _engine


def log(entry: AuditEntry) -> None:
    """Writes one audit entry immediately -- called at the end of every agent node."""
    engine = get_engine()
    with Session(engine) as session:
        session.add(entry)
        session.commit()


def get_trail_for_run(run_id: str) -> list[AuditEntry]:
    """Returns every audit entry for a given run, in chronological order."""
    engine = get_engine()
    with Session(engine) as session:
        statement = select(AuditEntry).where(AuditEntry.run_id == run_id).order_by(AuditEntry.timestamp)
        return list(session.exec(statement))
