"""
Deterministic validation tools.

These run AFTER a repair has been applied to a sandboxed copy, and decide
whether that repair is trustworthy enough to accept. This is the last line
of defense before a Decision (accepted / rejected / rolled_back /
human_review) gets recorded -- nothing here uses an LLM or an API key.
"""

import pandas as pd

from app.tools.quality_analysis import distribution_analysis, constraint_check


def validate_schema(original_df: pd.DataFrame, repaired_df: pd.DataFrame) -> dict:
    """
    Confirms a repair didn't accidentally add or remove columns. Dtype
    changes are NOT flagged here, since some repairs (e.g.
    correct_data_types) legitimately change a column's type on purpose.
    """
    original_cols = set(original_df.columns)
    repaired_cols = set(repaired_df.columns)

    missing_columns = sorted(original_cols - repaired_cols)
    added_columns = sorted(repaired_cols - original_cols)
    passed = not missing_columns and not added_columns

    return {
        "passed": passed,
        "missing_columns": missing_columns,
        "added_columns": added_columns,
        "summary": "Schema unchanged." if passed else "Schema was altered unexpectedly.",
    }


def check_data_loss(original_df: pd.DataFrame, repaired_df: pd.DataFrame, max_allowed_row_decrease: int = 0) -> dict:
    """
    Confirms no unexpected rows disappeared. `max_allowed_row_decrease`
    should be set to the number of rows a repair was INTENDED to remove
    (e.g. after remove_exact_duplicates, pass in how many duplicates were
    expected to be dropped) -- anything beyond that is treated as
    unexpected data loss.
    """
    rows_removed = len(original_df) - len(repaired_df)
    columns_removed = len(original_df.columns) - len(repaired_df.columns)

    passed = (0 <= rows_removed <= max_allowed_row_decrease) and columns_removed == 0

    return {
        "passed": passed,
        "rows_removed": rows_removed,
        "columns_removed": columns_removed,
        "summary": (
            f"{rows_removed} row(s) removed (within allowed {max_allowed_row_decrease})."
            if passed else
            f"Unexpected data loss: {rows_removed} row(s) / {columns_removed} column(s) removed."
        ),
    }


def compare_before_after(original_df: pd.DataFrame, repaired_df: pd.DataFrame, column: str, max_mean_shift_pct: float = 20.0) -> dict:
    """
    Compares a numeric column's statistical shape before and after a
    repair. A repair that shifts the mean drastically may indicate the
    repair over-corrected or was applied to the wrong rows.
    """
    before = distribution_analysis(original_df, column)
    after = distribution_analysis(repaired_df, column)

    if before.get("mean") in (None, 0):
        pct_shift = 0.0
    else:
        pct_shift = abs(after["mean"] - before["mean"]) / abs(before["mean"]) * 100

    passed = pct_shift <= max_mean_shift_pct

    return {
        "passed": passed,
        "column": column,
        "mean_before": before.get("mean"),
        "mean_after": after.get("mean"),
        "pct_shift": round(pct_shift, 2),
        "summary": (
            f"Mean shifted {pct_shift:.2f}% (within {max_mean_shift_pct}% tolerance)."
            if passed else
            f"Mean shifted {pct_shift:.2f}%, exceeding the {max_mean_shift_pct}% tolerance -- repair may be too aggressive."
        ),
    }


def validate_constraints(df: pd.DataFrame, rules: dict) -> dict:
    """
    Re-runs constraint_check() after a repair and reports whether every
    rule now passes. This directly answers: "did the repair actually fix
    the problem it was meant to fix?"
    """
    result = constraint_check(df, rules)
    passed = len(result["violations"]) == 0

    return {
        "passed": passed,
        "violations": result["violations"],
        "summary": "All constraints satisfied." if passed else result["summary"],
    }
