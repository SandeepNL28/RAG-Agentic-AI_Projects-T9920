"""
Deterministic repair tools.

IMPORTANT SAFETY RULE: every function here takes a DataFrame and returns a
NEW DataFrame (via .copy()) -- none of them mutate the input in place. This
mirrors the real system's rule that repairs only ever touch a sandboxed
copy, never the original data directly. The Repair Agent (built later) will
call these, but only after a proposal has cleared the confidence threshold.

Still no LLM and no API key used anywhere in this file.
"""

import re
import pandas as pd


def normalize_categories(df: pd.DataFrame, column: str, inconsistent_groups: dict) -> pd.DataFrame:
    """
    Standardizes inconsistent category spellings to a single canonical form.

    `inconsistent_groups` is exactly the shape returned by
    category_consistency_analysis()["inconsistent_groups"]:
        {"new york": ["New York", "new york", "NEW YORK"], ...}

    For each group, the canonical form is chosen as the variant that occurs
    most often in the data (ties broken alphabetically, for determinism).
    """
    df = df.copy()
    series = df[column].astype(str)

    for _, variants in inconsistent_groups.items():
        counts = {v: int((series == v).sum()) for v in variants}
        max_count = max(counts.values())
        # tie-break alphabetically so the result is deterministic and testable
        canonical = sorted([v for v, c in counts.items() if c == max_count])[0]

        mask = df[column].isin(variants)
        df.loc[mask, column] = canonical

    return df


def impute_missing_values(df: pd.DataFrame, column: str, strategy: str = "median") -> pd.DataFrame:
    """
    Fills missing values in a numeric column using a simple, explainable
    strategy. This should only ever be called after the confidence gate has
    approved it -- imputation always destroys some information, so it's one
    of the higher-risk repair actions.
    """
    df = df.copy()
    series = df[column]

    if strategy == "median":
        fill_value = series.median()
    elif strategy == "mean":
        fill_value = series.mean()
    elif strategy == "mode":
        fill_value = series.mode().iloc[0]
    else:
        raise ValueError(f"Unknown strategy: {strategy}")

    df[column] = series.fillna(fill_value)
    return df


# Reuses the same format definitions as date_format_consistency() in
# quality_analysis.py, plus how to parse each one into (year, month, day).
_DATE_FORMAT_PARSERS = {
    "YYYY-MM-DD": (r"^(\d{4})-(\d{2})-(\d{2})$", lambda m: (m[1], m[2], m[3])),
    "MM/DD/YYYY": (r"^(\d{2})/(\d{2})/(\d{4})$", lambda m: (m[3], m[1], m[2])),
    "DD-MM-YYYY": (r"^(\d{2})-(\d{2})-(\d{4})$", lambda m: (m[3], m[2], m[1])),
}


def standardize_dates(df: pd.DataFrame, column: str, target_format: str = "%Y-%m-%d") -> pd.DataFrame:
    """
    Rewrites every date value in a column to one consistent format,
    correctly interpreting each recognized source format (rather than
    naively re-formatting text).
    """
    df = df.copy()

    def _convert(value):
        if pd.isna(value):
            return value
        value = str(value).strip()
        for pattern, extractor in _DATE_FORMAT_PARSERS.values():
            match = re.match(pattern, value)
            if match:
                year, month, day = extractor(match)
                return f"{year}-{month}-{day}"  # ISO form; reformat below if needed
        return value  # unrecognized format -- left as-is, not guessed at

    df[column] = df[column].apply(_convert)

    if target_format != "%Y-%m-%d":
        df[column] = pd.to_datetime(df[column], errors="coerce").dt.strftime(target_format)

    return df


def correct_data_types(df: pd.DataFrame, column: str, target_type: str) -> pd.DataFrame:
    """
    Converts a column to the correct dtype once the agent has confirmed the
    values are actually well-formed for that type.

    target_type: one of "numeric", "integer", "datetime", "string"
    """
    df = df.copy()

    if target_type == "numeric":
        df[column] = pd.to_numeric(df[column], errors="coerce")
    elif target_type == "integer":
        df[column] = pd.to_numeric(df[column], errors="coerce").astype("Int64")
    elif target_type == "datetime":
        df[column] = pd.to_datetime(df[column], errors="coerce")
    elif target_type == "string":
        df[column] = df[column].astype(str)
    else:
        raise ValueError(f"Unknown target_type: {target_type}")

    return df


def remove_exact_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes rows that are fully identical across every column, keeping the
    first occurrence. Near-duplicates (which might be legitimately
    different records) are intentionally NOT touched by this function.
    """
    return df.drop_duplicates(keep="first").reset_index(drop=True)
