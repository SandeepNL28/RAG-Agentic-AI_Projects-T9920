"""
Deterministic quality-analysis tools.

IMPORTANT: nothing in this file uses an LLM. These are plain, reproducible
Python functions -- the same input always produces the same output. This is
what the Investigation Agent will call once LangGraph is wired up. Building
and testing these first (before any agent/LLM code) means you always have
something runnable and verifiable at every stage.
"""

import pandas as pd
from scipy import stats

from app.core.config import settings


def missing_value_analysis(df: pd.DataFrame) -> dict:
    """
    Scans every column for missing (NaN/None) values.

    Returns a dict keyed by column name, each containing the count and
    percentage of missing values in that column.
    """
    result = {}
    total_rows = len(df)

    for col in df.columns:
        missing_count = int(df[col].isna().sum())
        if missing_count > 0:
            result[col] = {
                "missing_count": missing_count,
                "missing_pct": round(missing_count / total_rows * 100, 2),
                "affected_rows": df.index[df[col].isna()].tolist(),
            }

    return result


def outlier_detection(df: pd.DataFrame, column: str, z_thresh: float = None) -> dict:
    """
    Flags statistically extreme values in a numeric column using a
    z-score threshold (how many standard deviations away from the mean).

    Returns the flagged row indices and a short human-readable summary.
    """
    if z_thresh is None:
        z_thresh = settings.outlier_z_threshold

    series = df[column].dropna()

    if series.empty or series.std() == 0:
        return {"column": column, "flagged_rows": [], "summary": "No variation to analyze."}

    z_scores = stats.zscore(series)
    flagged_idx = series.index[abs(z_scores) > z_thresh].tolist()

    return {
        "column": column,
        "flagged_rows": flagged_idx,
        "flagged_values": series.loc[flagged_idx].to_dict(),
        "summary": f"{len(flagged_idx)} value(s) exceed {z_thresh} standard deviations from the mean.",
    }


def duplicate_analysis(df: pd.DataFrame) -> dict:
    """
    Finds fully duplicated rows (every column identical).
    """
    duplicated_mask = df.duplicated(keep="first")
    duplicated_idx = df.index[duplicated_mask].tolist()

    return {
        "duplicate_count": len(duplicated_idx),
        "duplicate_rows": duplicated_idx,
        "summary": f"{len(duplicated_idx)} fully duplicated row(s) found.",
    }


def category_consistency_analysis(df: pd.DataFrame, column: str) -> dict:
    """
    Finds category labels that likely mean the same thing but are written
    differently -- e.g. "New York", "new york", "NEW YORK".

    Groups values by a normalized form (lowercased, whitespace-stripped) and
    flags any normalized group that has more than one distinct raw spelling.
    """
    series = df[column].dropna().astype(str)

    normalized_groups: dict[str, set] = {}
    for value in series:
        key = value.strip().lower()
        normalized_groups.setdefault(key, set()).add(value)

    inconsistent = {
        key: sorted(variants)
        for key, variants in normalized_groups.items()
        if len(variants) > 1
    }

    affected_rows = df.index[
        series.str.strip().str.lower().isin(inconsistent.keys())
    ].tolist()

    return {
        "column": column,
        "inconsistent_groups": inconsistent,
        "affected_rows": affected_rows,
        "summary": (
            f"{len(inconsistent)} normalized value(s) have inconsistent spelling "
            f"across {len(affected_rows)} row(s)."
            if inconsistent else "No category inconsistencies found."
        ),
    }


# Recognized date formats, checked in order. Each is (label, strftime-style regex).
_DATE_FORMAT_PATTERNS = {
    "YYYY-MM-DD": r"^\d{4}-\d{2}-\d{2}$",
    "MM/DD/YYYY": r"^\d{2}/\d{2}/\d{4}$",
    "DD-MM-YYYY": r"^\d{2}-\d{2}-\d{4}$",
}


def date_format_consistency(df: pd.DataFrame, column: str) -> dict:
    """
    Checks whether every value in a date-like column follows the SAME
    format. Real-world data often mixes formats (e.g. "2023-01-15" and
    "01/03/2023" in the same column) which silently breaks naive parsing.

    Returns the format each value was classified into, and flags rows
    whose format doesn't match the majority (the "expected") format.
    """
    import re

    series = df[column].dropna().astype(str)
    format_of_row: dict[int, str] = {}

    for idx, value in series.items():
        matched_format = "UNKNOWN"
        for label, pattern in _DATE_FORMAT_PATTERNS.items():
            if re.match(pattern, value.strip()):
                matched_format = label
                break
        format_of_row[idx] = matched_format

    format_counts: dict[str, int] = {}
    for fmt in format_of_row.values():
        format_counts[fmt] = format_counts.get(fmt, 0) + 1

    if not format_counts:
        return {"column": column, "majority_format": None, "flagged_rows": [], "summary": "No values to check."}

    majority_format = max(format_counts, key=format_counts.get)
    flagged_rows = [idx for idx, fmt in format_of_row.items() if fmt != majority_format]

    return {
        "column": column,
        "format_counts": format_counts,
        "majority_format": majority_format,
        "flagged_rows": flagged_rows,
        "summary": (
            f"Majority format is {majority_format}; "
            f"{len(flagged_rows)} row(s) use a different or unrecognized format."
        ),
    }


def distribution_analysis(df: pd.DataFrame, column: str) -> dict:
    """
    Summarizes the statistical shape of a numeric column: central tendency,
    spread, and skew. This is what the Diagnosis Agent will later use as
    "statistical_distribution" evidence when weighing a hypothesis.
    """
    series = df[column].dropna()

    if series.empty:
        return {"column": column, "summary": "No non-null values to analyze."}

    return {
        "column": column,
        "count": int(series.count()),
        "mean": round(float(series.mean()), 2),
        "median": round(float(series.median()), 2),
        "std": round(float(series.std()), 2) if series.count() > 1 else 0.0,
        "min": float(series.min()),
        "max": float(series.max()),
        "q1": round(float(series.quantile(0.25)), 2),
        "q3": round(float(series.quantile(0.75)), 2),
        "skewness": round(float(series.skew()), 2) if series.count() > 2 else 0.0,
        "summary": (
            f"mean={series.mean():.2f}, median={series.median():.2f}, "
            f"range=[{series.min()}, {series.max()}]"
        ),
    }


def constraint_check(df: pd.DataFrame, rules: dict) -> dict:
    """
    Checks column values against explicit rules -- e.g. from a data
    dictionary or business-rule document. This is the strongest form of
    evidence the Diagnosis Agent can use (a documented rule, not just a
    statistical pattern).

    `rules` example:
        {
            "age": {"min": 0, "max": 120},
            "annual_income": {"min": 0},
            "city": {"allowed_values": ["New York", "Los Angeles", ...]},
        }
    """
    violations = {}

    for column, rule in rules.items():
        if column not in df.columns:
            continue

        series = df[column]
        mask = pd.Series(False, index=series.index)

        if "min" in rule:
            mask |= series < rule["min"]
        if "max" in rule:
            mask |= series > rule["max"]
        if "allowed_values" in rule:
            mask |= series.notna() & ~series.isin(rule["allowed_values"])

        mask &= series.notna()
        violated_idx = series.index[mask].tolist()

        if violated_idx:
            violations[column] = {
                "rule": rule,
                "violated_rows": violated_idx,
                "violated_values": series.loc[violated_idx].to_dict(),
            }

    return {
        "violations": violations,
        "summary": (
            f"{len(violations)} column(s) have constraint violations."
            if violations else "All checked columns satisfy their constraints."
        ),
    }
