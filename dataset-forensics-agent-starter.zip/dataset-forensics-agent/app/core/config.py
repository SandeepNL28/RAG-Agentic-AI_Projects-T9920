"""
Central configuration for the Autonomous Dataset Forensics Agent.
Keeping all tunable values here means nothing is hard-coded inside
the agent logic itself.
"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # LLM settings (used once we wire up LangGraph + Ollama)
    ollama_model: str = "qwen3:4b"
    ollama_base_url: str = "http://localhost:11434"

    # Evidence-gating threshold: minimum confidence (0.0-1.0) required
    # before the Repair Agent is allowed to auto-apply a fix.
    confidence_threshold: float = 0.80

    # Where sandboxed (disposable) dataset copies are written during repair.
    sandbox_dir: str = "./_sandbox"

    # Where the audit trail database lives.
    audit_db_path: str = "./audit_trail.sqlite"

    # Where run records (status, results) are persisted, so run history
    # survives a server restart -- unlike the old in-memory-only registry.
    run_registry_db_path: str = "./run_registry.sqlite"

    # Outlier detection sensitivity (z-score threshold).
    # NOTE: 2.5 rather than the more "textbook" 3.0 default. On small
    # datasets, a single extreme outlier inflates the standard deviation
    # enough to partially mask its own z-score (discovered directly while
    # testing outlier_detection() against the sample dataset -- see
    # tests/test_tools.py for the full explanation). 2.5 is a more
    # practical default for small/medium datasets; this is exactly the
    # kind of threshold that should be tuned experimentally per-dataset
    # once the benchmark evaluation exists.
    outlier_z_threshold: float = 2.5


settings = Settings()
