"""
Shared data models used across the whole pipeline.

These are the "shape" of information that flows between the Investigation,
Diagnosis, Repair, and Validation agents once LangGraph is wired up.
Defining these first means every later piece of code speaks the same
language.
"""

import uuid
from typing import Literal, Optional
from pydantic import BaseModel, Field


class DetectedIssue(BaseModel):
    """One specific data-quality problem found by an inspection tool."""
    issue_id: str
    column: Optional[str] = None
    issue_type: Literal[
        "missing_value",
        "duplicate",
        "outlier",
        "type_error",
        "category_inconsistency",
        "date_format",
        "constraint_violation",
    ]
    severity: Literal["low", "medium", "high"]
    affected_rows: list[int]
    raw_observation: str  # plain description of what the tool found


class Hypothesis(BaseModel):
    """The Diagnosis Agent's guess at why an issue occurred."""
    issue_id: str
    explanation: str
    requires_evidence: list[str]


class Evidence(BaseModel):
    """A single piece of evidence gathered for or against a hypothesis."""
    issue_id: str
    source: str  # e.g. "data_dictionary_rule", "related_column_consistency"
    finding: str
    supports_hypothesis: bool


class RepairProposal(BaseModel):
    """A specific proposed fix, with an estimated confidence score."""
    issue_id: str
    action: str
    proposed_value: Optional[str] = None
    confidence: float
    rationale: str


class ValidationResult(BaseModel):
    """Result of checking a repair after it was applied in the sandbox."""
    issue_id: str
    passed: bool
    checks: dict[str, bool]
    notes: str


class Decision(BaseModel):
    """The final outcome recorded for a given issue."""
    issue_id: str
    outcome: Literal["accepted", "rejected", "rolled_back", "human_review"]
    reason: str


class ForensicsState(BaseModel):
    """
    The single object LangGraph passes between every node.
    Everything the agent has learned so far lives here.
    """
    run_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    dataset_path: str
    sandbox_path: Optional[str] = None
    issues: list[DetectedIssue] = []
    hypotheses: list[Hypothesis] = []
    evidence: list[Evidence] = []
    proposals: list[RepairProposal] = []
    validations: list[ValidationResult] = []
    decisions: list[Decision] = []
    current_issue_id: Optional[str] = None
    next_step: Optional[str] = None
