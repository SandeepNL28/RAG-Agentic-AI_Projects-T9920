"""
End-to-end pipeline DEMO — runs analysis -> repair -> validation on the
sample dataset, manually and sequentially, producing a real before/after
cleaned CSV you can show your guide.

IMPORTANT: this is a manual, hard-coded demonstration of the pipeline
concept using the tools we've built so far. It is NOT the real agent --
there is no LLM, no confidence scoring, no evidence-gating, and no
abstention/human-review logic yet. Those all get added once LangGraph and
the four agent nodes are built. This script exists purely to prove the
three tool layers can genuinely work together end-to-end before we add
AI reasoning on top.

Run with:
    python scripts/run_demo_pipeline.py
"""

import pandas as pd

from app.tools.quality_analysis import (
    missing_value_analysis,
    outlier_detection,
    category_consistency_analysis,
    date_format_consistency,
    constraint_check,
)
from app.tools.repair import (
    normalize_categories,
    impute_missing_values,
    standardize_dates,
)
from app.tools.validation import (
    validate_schema,
    check_data_loss,
    validate_constraints,
)

INPUT_PATH = "sample_data/sample_customers.csv"
OUTPUT_PATH = "sample_data/sample_customers_cleaned.csv"

AGE_RULES = {"age": {"min": 0, "max": 120}}


def main():
    print("=" * 60)
    print("STEP 1: LOAD ORIGINAL DATASET")
    print("=" * 60)
    original_df = pd.read_csv(INPUT_PATH)
    print(f"Loaded {len(original_df)} rows, {len(original_df.columns)} columns.\n")

    print("=" * 60)
    print("STEP 2: INVESTIGATION (analysis tools -- detect issues)")
    print("=" * 60)
    missing = missing_value_analysis(original_df)
    print(f"[missing_value_analysis]      {list(missing.keys())}")

    outliers = outlier_detection(original_df, "age", z_thresh=2.5)
    print(f"[outlier_detection: age]      {outliers['summary']}")

    categories = category_consistency_analysis(original_df, "city")
    print(f"[category_consistency: city]  {categories['summary']}")

    dates = date_format_consistency(original_df, "signup_date")
    print(f"[date_format_consistency]     {dates['summary']}")

    constraints_before = constraint_check(original_df, AGE_RULES)
    print(f"[constraint_check: age]       {constraints_before['summary']}\n")

    print("=" * 60)
    print("STEP 3: REPAIR (apply fixes to a working copy, never the original)")
    print("=" * 60)
    working_df = original_df.copy()  # stand-in for the real sandbox copy

    working_df = normalize_categories(working_df, "city", categories["inconsistent_groups"])
    print("[normalize_categories]  city spellings standardized")

    working_df = impute_missing_values(working_df, "age", strategy="median")
    print("[impute_missing_values] age gap filled with median")

    working_df = impute_missing_values(working_df, "annual_income", strategy="median")
    print("[impute_missing_values] annual_income gap filled with median")

    working_df = standardize_dates(working_df, "signup_date")
    print("[standardize_dates]     signup_date formats unified")

    # The age=240 outlier: in the REAL system, this would only be changed
    # if evidence-gating confidence cleared the threshold. Here, since we
    # have no evidence-gating yet, we deliberately do NOT auto-repair it --
    # this mirrors the "abstain when unsure" principle even in this
    # simplified demo.
    print("[SKIPPED] age=240 outlier left untouched -- no evidence-gating")
    print("          logic exists yet to justify this repair automatically.\n")

    print("=" * 60)
    print("STEP 4: VALIDATION (check the repairs before trusting them)")
    print("=" * 60)
    schema_result = validate_schema(original_df, working_df)
    print(f"[validate_schema]    passed={schema_result['passed']} -- {schema_result['summary']}")

    loss_result = check_data_loss(original_df, working_df, max_allowed_row_decrease=0)
    print(f"[check_data_loss]    passed={loss_result['passed']} -- {loss_result['summary']}")

    constraints_after = validate_constraints(working_df, AGE_RULES)
    print(f"[validate_constraints] passed={constraints_after['passed']} -- {constraints_after['summary']}")
    print("  (still fails -- expected, since we correctly left age=240 unrepaired)\n")

    print("=" * 60)
    print("STEP 5: SAVE FINAL OUTPUT")
    print("=" * 60)
    working_df.to_csv(OUTPUT_PATH, index=False)
    print(f"Cleaned dataset saved to: {OUTPUT_PATH}")
    print(f"Original dataset untouched at: {INPUT_PATH}")


if __name__ == "__main__":
    main()
