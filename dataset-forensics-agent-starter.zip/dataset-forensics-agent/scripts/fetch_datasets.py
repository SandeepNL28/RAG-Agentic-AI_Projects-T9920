"""
Fetches the real-world datasets recommended for this project and saves
them locally as CSVs. Run this once to populate benchmark/datasets/.

Usage:
    python scripts/fetch_datasets.py
"""

import os
from sklearn.datasets import fetch_openml

OUTPUT_DIR = "benchmark/datasets"


def fetch_and_save(name: str, version, filename: str):
    print(f"Fetching {name} (version={version}) ...")
    data = fetch_openml(name, version=version, as_frame=True, parser="auto")
    df = data.frame
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    path = os.path.join(OUTPUT_DIR, filename)
    df.to_csv(path, index=False)
    print(f"  -> saved {len(df)} rows, {len(df.columns)} columns to {path}")


if __name__ == "__main__":
    # Small, fast to iterate on -- good for Phase 1/2 development
    fetch_and_save("titanic", version=1, filename="titanic.csv")

    # Larger, realistic mix of numeric + categorical -- good once tools mature
    fetch_and_save("adult", version=2, filename="adult_income.csv")

    # Rich categorical data -- great for category_consistency_analysis()
    fetch_and_save("credit-g", version=1, filename="german_credit.csv")

    print("\nDone. Clean, ground-truth datasets are now in benchmark/datasets/.")
    print("Next: write benchmark/corrupt.py to inject controlled corruptions")
    print("into copies of these files, keeping these originals as ground truth.")
