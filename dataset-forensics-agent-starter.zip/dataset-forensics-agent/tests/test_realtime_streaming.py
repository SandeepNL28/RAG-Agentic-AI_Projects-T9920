"""
Tests for the real-time event broadcaster and the WebSocket streaming
endpoint.

IMPORTANT TESTING NOTE: FastAPI's TestClient runs BackgroundTasks
synchronously (blocking) before the HTTP response is returned to the
caller. This means a naive test that calls POST /runs/start and THEN
opens a WebSocket would find the run already finished, with all its
events already published to zero subscribers. To properly test real-time
streaming, we run `_execute_run` in a background THREAD ourselves (rather
than through the BackgroundTasks/HTTP flow) so the WebSocket connection
can genuinely race against, and observe, live events -- exactly as a real
browser client would against a real uvicorn server.
"""

import asyncio
import threading
import time

import pytest

from app.api.event_broadcaster import RunEventBroadcaster
from app.api import run_registry
from app.api.routers.runs import _execute_run
from app.agents import diagnosis_agent
from app.api.main import app
from fastapi.testclient import TestClient


@pytest.fixture(autouse=True)
def mock_llm(monkeypatch):
    def _fake_call_llm(prompt, expect_json=True):
        return {
            "explanation": "Automated hypothesis for real-time streaming test.",
            "requires_evidence": ["statistical_distribution"],
        }
    monkeypatch.setattr(diagnosis_agent, "call_llm", _fake_call_llm)


def test_broadcaster_delivers_events_in_order_to_a_subscriber():
    """
    Unit-level test of the broadcaster itself: publish several events and
    confirm a subscriber receives exactly those events, in order.
    """
    async def run_test():
        broadcaster = RunEventBroadcaster()
        queue = broadcaster.subscribe("run-1")

        broadcaster.publish("run-1", "run_started", {"dataset_id": "d1"})
        broadcaster.publish("run-1", "step_completed", {"node": "investigate"})
        broadcaster.publish("run-1", "step_completed", {"node": "diagnose"})
        broadcaster.publish("run-1", "run_completed", {"issue_count": 1})

        received = [await queue.get() for _ in range(4)]
        return received

    received = asyncio.run(run_test())
    assert [e["type"] for e in received] == [
        "run_started", "step_completed", "step_completed", "run_completed",
    ]


def test_broadcaster_does_not_deliver_events_to_a_different_run_id():
    async def run_test():
        broadcaster = RunEventBroadcaster()
        queue_a = broadcaster.subscribe("run-A")
        queue_b = broadcaster.subscribe("run-B")

        broadcaster.publish("run-A", "run_started", {})

        # call_soon_threadsafe schedules the put for the NEXT loop
        # iteration rather than running synchronously -- yield control
        # once so the scheduled callback actually gets to run.
        await asyncio.sleep(0)

        assert queue_a.qsize() == 1
        assert queue_b.qsize() == 0

    asyncio.run(run_test())


def test_websocket_receives_live_events_while_run_executes_in_background(tmp_path):
    """
    The real integration test: starts _execute_run in a background thread
    (simulating what BackgroundTasks would do in a real deployment), opens
    a WebSocket connection concurrently, and verifies real, live events
    arrive over the actual WebSocket protocol as the run progresses --
    not just at the very end.
    """
    import shutil
    run_id = "integration-test-run"
    dataset_id = "fake-dataset-id"
    dataset_path = "sample_data/sample_customers.csv"

    run_registry.create_run(run_id, dataset_id)

    client = TestClient(app)

    received_events = []
    with client.websocket_connect(f"/runs/{run_id}/live") as websocket:
        # Kick off the real run in a separate thread AFTER the WebSocket is
        # already connected and subscribed -- this is what makes the race
        # realistic instead of accidentally missing early events.
        thread = threading.Thread(
            target=_execute_run, args=(run_id, dataset_id, dataset_path)
        )
        thread.start()

        while True:
            event = websocket.receive_json()
            received_events.append(event)
            if event["type"] in ("run_completed", "run_failed"):
                break

        thread.join(timeout=10)

    event_types = [e["type"] for e in received_events]
    assert "run_started" in event_types
    assert event_types.count("step_completed") > 0  # genuine per-step events, not just start/end
    assert event_types[-1] == "run_completed"

    shutil.rmtree("data", ignore_errors=True)


def test_websocket_immediately_replays_status_for_an_already_finished_run():
    run_id = "already-done-run"
    run_registry.create_run(run_id, "fake-dataset-id")
    run_registry.update_run(run_id, status="completed")

    client = TestClient(app)
    with client.websocket_connect(f"/runs/{run_id}/live") as websocket:
        event = websocket.receive_json()

    assert event["type"] == "run_completed"
    assert event["replay"] is True
