"""
Tests for the SQLite-backed run registry. Uses the global test isolation
fixture from conftest.py, so these never touch the real database.
"""

from app.api import run_registry


def test_create_and_retrieve_a_run():
    record = run_registry.create_run("run-1", "dataset-abc")
    assert record.status == "pending"

    fetched = run_registry.get_run("run-1")
    assert fetched.run_id == "run-1"
    assert fetched.dataset_id == "dataset-abc"
    assert fetched.status == "pending"


def test_update_run_status_persists():
    run_registry.create_run("run-2", "dataset-xyz")
    run_registry.update_run("run-2", status="running")

    fetched = run_registry.get_run("run-2")
    assert fetched.status == "running"


def test_update_run_stores_and_retrieves_final_state_as_a_real_dict():
    run_registry.create_run("run-3", "dataset-def")
    fake_final_state = {
        "issues": [{"issue_id": "i1", "issue_type": "outlier"}],
        "decisions": [{"issue_id": "i1", "outcome": "human_review"}],
    }
    run_registry.update_run("run-3", status="completed", final_state=fake_final_state)

    fetched = run_registry.get_run("run-3")
    assert fetched.status == "completed"
    assert isinstance(fetched.final_state, dict)  # not a raw JSON string
    assert fetched.final_state["issues"][0]["issue_type"] == "outlier"


def test_get_run_returns_none_for_unknown_run_id():
    assert run_registry.get_run("does-not-exist") is None


def test_run_survives_a_simulated_engine_restart():
    """
    Simulates what a real server restart looks like: force the module to
    forget its cached engine (as if the process had just started fresh)
    and confirm the previously-created run is still readable from disk --
    this is the entire point of switching away from the in-memory version.
    """
    run_registry.create_run("run-persist", "dataset-persist")
    run_registry.update_run("run-persist", status="completed")

    # Simulate a fresh process: drop the cached engine reference.
    run_registry._engine = None
    run_registry._current_db_path = None

    fetched = run_registry.get_run("run-persist")
    assert fetched is not None
    assert fetched.status == "completed"


def test_list_runs_returns_recent_runs():
    run_registry.create_run("run-a", "d1")
    run_registry.create_run("run-b", "d2")

    runs = run_registry.list_runs()
    run_ids = {r.run_id for r in runs}
    assert "run-a" in run_ids
    assert "run-b" in run_ids
