"""
Tests for evaluation metrics, with hand-calculated expected values. This
matters more than most other tests in the project: a subtle bug here
would silently produce plausible-looking but WRONG research numbers for
Safe Repair Rate / False Repair Rate, which are the project's actual
headline results.
"""

from evaluation.metrics import (
    precision_recall_f1,
    safe_repair_rate,
    false_repair_rate,
    autonomy_rate,
    diagnosis_accuracy,
)


def test_precision_recall_f1_perfect_detection():
    result = precision_recall_f1({"age", "city"}, {"age", "city"})
    assert result["precision"] == 1.0
    assert result["recall"] == 1.0
    assert result["f1"] == 1.0


def test_precision_recall_f1_hand_calculated_example():
    # Detected: {age, city, income}. True corrupted: {age, city, date}.
    # TP = {age, city} = 2. FP = {income} = 1. FN = {date} = 1.
    # precision = 2 / (2+1) = 0.6667
    # recall    = 2 / (2+1) = 0.6667
    # f1        = 2*0.6667*0.6667 / (0.6667+0.6667) = 0.6667
    result = precision_recall_f1({"age", "city", "income"}, {"age", "city", "date"})
    assert result["precision"] == 0.6667
    assert result["recall"] == 0.6667
    assert result["f1"] == 0.6667
    assert result["true_positives"] == 2
    assert result["false_positives"] == 1
    assert result["false_negatives"] == 1


def test_precision_recall_f1_handles_zero_detections():
    result = precision_recall_f1(set(), {"age"})
    assert result["precision"] == 0.0
    assert result["recall"] == 0.0
    assert result["f1"] == 0.0


def test_safe_repair_rate_hand_calculated():
    # 3 accepted, 2 of them correct -> 2/3 = 0.6667
    repairs = [
        {"outcome": "accepted", "correct": True},
        {"outcome": "accepted", "correct": True},
        {"outcome": "accepted", "correct": False},
        {"outcome": "human_review", "correct": False},  # not counted -- wasn't accepted
    ]
    assert safe_repair_rate(repairs) == 0.6667


def test_safe_repair_rate_is_none_when_nothing_was_accepted():
    repairs = [{"outcome": "human_review", "correct": False}]
    assert safe_repair_rate(repairs) is None


def test_false_repair_rate_hand_calculated():
    # automatic (accepted + rolled_back) = 4 total, 1 incorrect -> 1/4 = 0.25
    repairs = [
        {"outcome": "accepted", "correct": True},
        {"outcome": "accepted", "correct": True},
        {"outcome": "rolled_back", "correct": False},
        {"outcome": "accepted", "correct": True},
        {"outcome": "human_review", "correct": False},  # not counted
    ]
    assert false_repair_rate(repairs) == 0.25


def test_false_repair_rate_is_zero_when_no_automatic_repairs_happened():
    repairs = [{"outcome": "human_review", "correct": False}]
    assert false_repair_rate(repairs) == 0.0


def test_autonomy_rate_hand_calculated():
    # 5 issues total, 3 resolved without human review -> 3/5 = 0.6
    repairs = [
        {"outcome": "accepted", "correct": True},
        {"outcome": "accepted", "correct": True},
        {"outcome": "rejected", "correct": True},
        {"outcome": "human_review", "correct": False},
        {"outcome": "human_review", "correct": False},
    ]
    assert autonomy_rate(repairs) == 0.6


def test_diagnosis_accuracy_hand_calculated():
    diagnoses = [
        {"predicted_type": "outlier", "true_type": "outlier"},       # correct
        {"predicted_type": "missing_value", "true_type": "outlier"},  # wrong
        {"predicted_type": "duplicate", "true_type": "duplicate"},    # correct
        {"predicted_type": "category_inconsistency", "true_type": "date_format"},  # wrong
    ]
    # 2 correct out of 4 -> 0.5
    assert diagnosis_accuracy(diagnoses) == 0.5


def test_diagnosis_accuracy_handles_empty_input():
    assert diagnosis_accuracy([]) == 0.0
