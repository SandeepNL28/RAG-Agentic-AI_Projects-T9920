"""
Full end-to-end API test: upload -> start -> poll -> issues -> audit ->
download. This uses FastAPI's real TestClient (a real ASGI app, real
routing, real background task execution) -- only the LLM call is mocked,
for the same reason as the other agent tests (no Ollama server available
in this test environment).
"""

import io
import shutil

import pytest
from fastapi.testclient import TestClient

from app.api.main import app
from app.agents import diagnosis_agent


@pytest.fixture(autouse=True)
def mock_llm(monkeypatch):
    def _fake_call_llm(prompt, expect_json=True):
        return {
            "explanation": "Automated hypothesis generated during API testing.",
            "requires_evidence": ["statistical_distribution", "data_dictionary_rule"],
        }
    monkeypatch.setattr(diagnosis_agent, "call_llm", _fake_call_llm)


@pytest.fixture(autouse=True)
def cleanup_data_dirs():
    yield
    shutil.rmtree("data/uploads", ignore_errors=True)
    shutil.rmtree("data/outputs", ignore_errors=True)


client = TestClient(app)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_full_api_lifecycle_upload_to_download():
    # 1. Upload
    with open("sample_data/sample_customers.csv", "rb") as f:
        upload_response = client.post(
            "/datasets/upload",
            files={"file": ("sample_customers.csv", f, "text/csv")},
        )
    assert upload_response.status_code == 200
    dataset_id = upload_response.json()["dataset_id"]
    assert dataset_id

    # 2. Start a run (TestClient executes background tasks before returning)
    start_response = client.post(f"/runs/start?dataset_id={dataset_id}")
    assert start_response.status_code == 200
    run_id = start_response.json()["run_id"]
    assert run_id

    # 3. Poll status -- should be completed by the time TestClient returns,
    # since background tasks run synchronously within the test client call.
    status_response = client.get(f"/runs/{run_id}/status")
    assert status_response.status_code == 200
    assert status_response.json()["status"] == "completed"

    # 4. Get detected issues + their decisions
    issues_response = client.get(f"/runs/{run_id}/issues")
    assert issues_response.status_code == 200
    issues = issues_response.json()
    assert len(issues) >= 4  # the planted issues in sample_customers.csv
    assert all("decision" in issue and issue["decision"] is not None for issue in issues)

    # 5. Get the audit trail
    audit_response = client.get(f"/runs/{run_id}/audit")
    assert audit_response.status_code == 200
    audit_entries = audit_response.json()
    assert len(audit_entries) > 0
    assert any(e["step"] == "investigate" for e in audit_entries)

    # 6. Download the cleaned dataset
    download_response = client.get(f"/runs/{run_id}/download")
    assert download_response.status_code == 200
    assert len(download_response.content) > 0


def test_upload_rejects_unsupported_file_type():
    response = client.post(
        "/datasets/upload",
        files={"file": ("notes.txt", io.BytesIO(b"hello"), "text/plain")},
    )
    assert response.status_code == 400


def test_start_run_with_unknown_dataset_id_returns_404():
    response = client.post("/runs/start?dataset_id=does-not-exist")
    assert response.status_code == 404


def test_status_for_unknown_run_id_returns_404():
    response = client.get("/runs/does-not-exist/status")
    assert response.status_code == 404
