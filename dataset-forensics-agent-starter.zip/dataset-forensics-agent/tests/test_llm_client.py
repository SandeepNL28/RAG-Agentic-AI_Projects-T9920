"""
Tests for the Ollama client's retry/resilience behavior. No real Ollama
server is used -- requests.post is mocked to simulate transient failures.
"""

import requests
import pytest
from unittest.mock import patch, MagicMock

from app.llm.ollama_client import call_llm, LLMCallError


def test_call_llm_succeeds_on_first_try(monkeypatch):
    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {"response": '{"explanation": "ok"}'}

    with patch("requests.post", return_value=mock_response) as mock_post:
        result = call_llm("test prompt", expect_json=True)

    assert result == {"explanation": "ok"}
    assert mock_post.call_count == 1


def test_call_llm_retries_on_transient_failure_then_succeeds(monkeypatch):
    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {"response": '{"explanation": "recovered"}'}

    call_count = {"n": 0}

    def flaky_post(*args, **kwargs):
        call_count["n"] += 1
        if call_count["n"] < 2:
            raise requests.exceptions.ConnectionError("temporary network blip")
        return mock_response

    with patch("requests.post", side_effect=flaky_post):
        result = call_llm("test prompt", expect_json=True)

    assert result == {"explanation": "recovered"}
    assert call_count["n"] == 2  # failed once, succeeded on retry


def test_call_llm_raises_llm_call_error_after_exhausting_retries():
    with patch("requests.post", side_effect=requests.exceptions.ConnectionError("server down")):
        with pytest.raises(LLMCallError):
            call_llm("test prompt", expect_json=True)


def test_call_llm_raises_on_invalid_json_response():
    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {"response": "not valid json at all"}

    with patch("requests.post", return_value=mock_response):
        with pytest.raises(LLMCallError):
            call_llm("test prompt", expect_json=True)
