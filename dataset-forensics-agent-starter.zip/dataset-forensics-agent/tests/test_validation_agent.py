"""
Tests for the Validation Agent. No LLM needed -- purely deterministic
decision logic tested against constructed states.
"""

import os
import pandas as pd
import pytest

from app.core.config import settings
from app.core.schemas import ForensicsState, DetectedIssue, RepairProposal
from app.sandbox import sandbox_manager
from app.agents import validation_agent


def test_validation_agent_sends_low_confidence_to_human_review():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-1", column="age", issue_type="outlier", severity="high",
        affected_rows=[3], raw_observation="Age=240 is extreme.",
    ))
    state.proposals.append(RepairProposal(
        issue_id="issue-1", action="manual_value_correction",
        confidence=0.30, rationale="Weak evidence only.",
    ))
    state.current_issue_id = "issue-1"

    result_state = validation_agent.run(state)

    decision = result_state.decisions[0]
    assert decision.outcome == "human_review"


def test_validation_agent_accepts_a_valid_sandboxed_repair():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-2", column="city", issue_type="category_inconsistency",
        severity="low", affected_rows=[0, 5, 8], raw_observation="Spelling variants.",
    ))
    state.proposals.append(RepairProposal(
        issue_id="issue-2", action="normalize_categories",
        confidence=0.85, rationale="Strong evidence.",
    ))

    # Simulate what the Repair Agent would have done: create a sandbox
    # with a legitimate, schema-preserving repair already applied.
    state.sandbox_path = sandbox_manager.create_sandbox(state.dataset_path)
    df = pd.read_csv(state.sandbox_path)
    df.loc[[0, 5, 8], "city"] = "New York"  # normalized
    df.to_csv(state.sandbox_path, index=False)

    state.current_issue_id = "issue-2"

    result_state = validation_agent.run(state)

    decision = result_state.decisions[0]
    assert decision.outcome == "accepted"
    assert result_state.validations[0].passed is True

    os.remove(state.sandbox_path)


def test_validation_agent_rolls_back_a_broken_repair():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-3", column="city", issue_type="category_inconsistency",
        severity="low", affected_rows=[0, 5, 8], raw_observation="Spelling variants.",
    ))
    state.proposals.append(RepairProposal(
        issue_id="issue-3", action="normalize_categories",
        confidence=0.85, rationale="Strong evidence.",
    ))

    # Simulate a BROKEN repair: a column got accidentally dropped.
    state.sandbox_path = sandbox_manager.create_sandbox(state.dataset_path)
    df = pd.read_csv(state.sandbox_path)
    df = df.drop(columns=["annual_income"])  # simulate a bug that lost a column
    df.to_csv(state.sandbox_path, index=False)

    state.current_issue_id = "issue-3"

    result_state = validation_agent.run(state)

    decision = result_state.decisions[0]
    assert decision.outcome == "rolled_back"
    assert result_state.validations[0].passed is False
    # sandbox should have been discarded
    assert result_state.sandbox_path is None
