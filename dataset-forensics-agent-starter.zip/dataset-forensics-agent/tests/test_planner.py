"""
Tests for the Planner. Pure routing logic, no LLM or tools involved.
"""

from app.core.schemas import (
    ForensicsState, DetectedIssue, Hypothesis, RepairProposal, Decision,
)
from app.agents import planner


def test_planner_routes_to_investigate_when_no_issues_yet():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    result = planner.run(state)
    assert result.next_step == "investigate"


def test_planner_routes_through_full_issue_lifecycle():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-1", column="age", issue_type="outlier", severity="high",
        affected_rows=[3], raw_observation="Age=240 is extreme.",
    ))

    # 1. Issue exists, no hypothesis yet -> diagnose
    state = planner.run(state)
    assert state.next_step == "diagnose"
    assert state.current_issue_id == "issue-1"

    # 2. Hypothesis exists, no proposal yet -> repair
    state.hypotheses.append(Hypothesis(
        issue_id="issue-1", explanation="Typo.", requires_evidence=[],
    ))
    state = planner.run(state)
    assert state.next_step == "repair"

    # 3. Proposal exists, no decision yet -> validate
    state.proposals.append(RepairProposal(
        issue_id="issue-1", action="manual_value_correction",
        confidence=0.30, rationale="Weak evidence.",
    ))
    state = planner.run(state)
    assert state.next_step == "validate"

    # 4. Decision recorded -> done (no more open issues)
    state.decisions.append(Decision(
        issue_id="issue-1", outcome="human_review", reason="Low confidence.",
    ))
    state = planner.run(state)
    assert state.next_step == "done"


def test_planner_moves_to_next_open_issue_when_first_is_resolved():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-1", column="age", issue_type="outlier", severity="high",
        affected_rows=[3], raw_observation="...",
    ))
    state.issues.append(DetectedIssue(
        issue_id="issue-2", column="city", issue_type="category_inconsistency",
        severity="low", affected_rows=[0, 5, 8], raw_observation="...",
    ))
    state.decisions.append(Decision(
        issue_id="issue-1", outcome="human_review", reason="Low confidence.",
    ))

    result = planner.run(state)
    assert result.current_issue_id == "issue-2"
    assert result.next_step == "diagnose"
