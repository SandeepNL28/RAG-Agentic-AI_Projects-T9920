"""
Unit tests for the deterministic validation tools.

Run with:  pytest -v
"""

import pandas as pd
import pytest

from app.tools.repair import remove_exact_duplicates, impute_missing_values
from app.tools.validation import (
    validate_schema,
    check_data_loss,
    compare_before_after,
    validate_constraints,
)


@pytest.fixture
def sample_df():
    return pd.read_csv("sample_data/sample_customers.csv")


def test_validate_schema_passes_when_columns_unchanged(sample_df):
    repaired = impute_missing_values(sample_df, "age", strategy="median")
    result = validate_schema(sample_df, repaired)

    assert result["passed"] is True
    assert result["missing_columns"] == []
    assert result["added_columns"] == []


def test_validate_schema_fails_when_a_column_disappears(sample_df):
    broken = sample_df.drop(columns=["city"])
    result = validate_schema(sample_df, broken)

    assert result["passed"] is False
    assert "city" in result["missing_columns"]


def test_check_data_loss_allows_expected_duplicate_removal():
    df = pd.DataFrame({"id": [1, 2, 3], "name": ["A", "B", "A"]})
    df_with_dupe = pd.concat([df, df.iloc[[0]]], ignore_index=True)  # 4 rows, 1 true dup

    repaired = remove_exact_duplicates(df_with_dupe)  # removes exactly 1 row
    result = check_data_loss(df_with_dupe, repaired, max_allowed_row_decrease=1)

    assert result["passed"] is True
    assert result["rows_removed"] == 1


def test_check_data_loss_flags_unexpected_row_loss():
    df = pd.DataFrame({"id": [1, 2, 3], "name": ["A", "B", "C"]})
    accidentally_truncated = df.iloc[:1]  # lost 2 rows, none of it intended

    result = check_data_loss(df, accidentally_truncated, max_allowed_row_decrease=0)

    assert result["passed"] is False
    assert result["rows_removed"] == 2


def test_compare_before_after_passes_for_reasonable_imputation(sample_df):
    repaired = impute_missing_values(sample_df, "annual_income", strategy="median")
    result = compare_before_after(sample_df, repaired, "annual_income")

    assert result["passed"] is True  # filling one missing value shouldn't shift the mean much


def test_compare_before_after_fails_for_a_drastic_shift(sample_df):
    corrupted = sample_df.copy()
    corrupted["annual_income"] = corrupted["annual_income"] * 100  # deliberately extreme

    result = compare_before_after(sample_df, corrupted, "annual_income")
    assert result["passed"] is False


def test_validate_constraints_fails_before_repair_and_passes_after(sample_df):
    rules = {"age": {"min": 0, "max": 120}}

    before = validate_constraints(sample_df, rules)
    assert before["passed"] is False  # the age=240 row violates this

    fixed = sample_df.copy()
    fixed.loc[3, "age"] = 24  # simulate the agent's eventual repair

    after = validate_constraints(fixed, rules)
    assert after["passed"] is True
