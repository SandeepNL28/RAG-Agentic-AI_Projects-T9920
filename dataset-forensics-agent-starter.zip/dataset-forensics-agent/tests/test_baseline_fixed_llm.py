"""
Tests for Baseline 2 (fixed LLM workflow). As with the real Diagnosis
Agent, call_llm is mocked -- no real Ollama server is available in this
test environment. What matters here is proving this baseline applies
fixes DIRECTLY with no gating, which is the entire point of using it as
a comparison point.
"""

import pandas as pd
import pytest
from unittest.mock import patch

from evaluation.baselines import fixed_llm_workflow


def test_fixed_llm_workflow_imputes_missing_values_when_llm_says_to():
    df = pd.DataFrame({"income": [50000.0, 60000.0, None, 70000.0]})

    with patch.object(fixed_llm_workflow, "call_llm", return_value={"action": "impute", "fixed_value": None}):
        result = fixed_llm_workflow.run_fixed_llm_workflow(df)

    assert result["income"].isna().sum() == 0


def test_fixed_llm_workflow_does_nothing_when_llm_says_ignore():
    df = pd.DataFrame({"income": [50000.0, 60000.0, None, 70000.0]})

    with patch.object(fixed_llm_workflow, "call_llm", return_value={"action": "ignore", "fixed_value": None}):
        result = fixed_llm_workflow.run_fixed_llm_workflow(df)

    # Still missing -- the LLM said "ignore" and the baseline (correctly,
    # for THIS test's purpose) has no gating logic to override that.
    assert result["income"].isna().sum() == 1


def test_fixed_llm_workflow_normalizes_categories_when_llm_says_to():
    df = pd.DataFrame({"city": ["New York", "new york", "NEW YORK", "Boston"]})

    with patch.object(fixed_llm_workflow, "call_llm", return_value={"action": "normalize", "fixed_value": None}):
        result = fixed_llm_workflow.run_fixed_llm_workflow(df)

    ny_values = result.loc[[0, 1, 2], "city"].unique()
    assert len(ny_values) == 1


def test_fixed_llm_workflow_applies_fix_immediately_with_no_confidence_check():
    """
    Unlike the proposed system, this baseline has NO concept of
    confidence -- it applies whatever the LLM says on the very first
    response, every time. This test documents that behavior explicitly
    as the key structural difference being evaluated.
    """
    df = pd.DataFrame({"income": [50000.0, 60000.0, None, 70000.0]})
    call_count = {"n": 0}

    def counting_call_llm(prompt, expect_json=True):
        call_count["n"] += 1
        return {"action": "impute", "fixed_value": None}

    with patch.object(fixed_llm_workflow, "call_llm", side_effect=counting_call_llm):
        fixed_llm_workflow.run_fixed_llm_workflow(df)

    assert call_count["n"] == 1  # exactly one LLM call, no evidence-gathering round trips
