"""
Tests for the audit trail logger. Uses a temporary SQLite file (via
pytest's tmp_path fixture) so these tests never touch the real
audit_trail.sqlite that a live run would create.
"""

from app.core.config import settings
from app.audit import audit_logger
from app.audit.audit_logger import AuditEntry


def test_log_and_retrieve_a_single_entry(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "audit_db_path", str(tmp_path / "test_audit.sqlite"))
    monkeypatch.setattr(audit_logger, "_engine", None)  # force re-creation against the temp path

    entry = AuditEntry(
        run_id="run-123",
        issue_id="issue-1",
        step="investigate",
        observation="Found 1 outlier.",
        reasoning_summary="z-score exceeded threshold.",
    )
    audit_logger.log(entry)

    trail = audit_logger.get_trail_for_run("run-123")
    assert len(trail) == 1
    assert trail[0].step == "investigate"
    assert trail[0].observation == "Found 1 outlier."


def test_trail_is_scoped_to_a_single_run_id(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "audit_db_path", str(tmp_path / "test_audit2.sqlite"))
    monkeypatch.setattr(audit_logger, "_engine", None)

    audit_logger.log(AuditEntry(run_id="run-A", step="investigate", observation="...", reasoning_summary="..."))
    audit_logger.log(AuditEntry(run_id="run-B", step="investigate", observation="...", reasoning_summary="..."))
    audit_logger.log(AuditEntry(run_id="run-A", step="diagnose", observation="...", reasoning_summary="..."))

    trail_a = audit_logger.get_trail_for_run("run-A")
    trail_b = audit_logger.get_trail_for_run("run-B")

    assert len(trail_a) == 2
    assert len(trail_b) == 1


def test_trail_is_returned_in_chronological_order(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "audit_db_path", str(tmp_path / "test_audit3.sqlite"))
    monkeypatch.setattr(audit_logger, "_engine", None)

    audit_logger.log(AuditEntry(run_id="run-X", step="investigate", observation="first", reasoning_summary="..."))
    audit_logger.log(AuditEntry(run_id="run-X", step="diagnose", observation="second", reasoning_summary="..."))
    audit_logger.log(AuditEntry(run_id="run-X", step="repair", observation="third", reasoning_summary="..."))

    trail = audit_logger.get_trail_for_run("run-X")
    assert [entry.observation for entry in trail] == ["first", "second", "third"]
