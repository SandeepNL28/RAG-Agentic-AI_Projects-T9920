"""
Full end-to-end integration test: runs the ENTIRE compiled LangGraph
workflow, from raw CSV to final decisions, exactly as the real system
would. The LLM call inside diagnosis_agent is mocked (no Ollama server
available in this test environment) -- everything else is the real,
compiled graph actually executing.

This is the strongest proof yet that the wiring is correct: if the graph
had a broken edge, an infinite loop, or a state-passing bug, this test
would hang or crash.
"""

import pandas as pd
import pytest

from app.core.schemas import ForensicsState
from app.agents import diagnosis_agent
from app.graph.workflow import build_graph


@pytest.fixture(autouse=True)
def mock_llm(monkeypatch):
    """
    Every call to the LLM during this test returns a plausible, generic
    hypothesis requesting statistical evidence -- deliberately generic
    since the graph will diagnose several different issue types.
    """
    def _fake_call_llm(prompt, expect_json=True):
        return {
            "explanation": "Automated hypothesis generated during testing.",
            "requires_evidence": ["statistical_distribution", "data_dictionary_rule"],
        }
    monkeypatch.setattr(diagnosis_agent, "call_llm", _fake_call_llm)


def test_full_graph_runs_start_to_finish_without_hanging():
    graph = build_graph()
    initial_state = ForensicsState(dataset_path="sample_data/sample_customers.csv")

    # recursion_limit guards against an infinite loop bug -- if the graph
    # doesn't terminate within a reasonable number of steps, this raises
    # instead of hanging forever.
    final_state_dict = graph.invoke(initial_state, config={"recursion_limit": 50})
    final_state = ForensicsState(**final_state_dict)

    # The graph must have found the same planted issues the Investigation
    # Agent alone finds.
    assert len(final_state.issues) >= 4

    # Every single issue must have reached a final decision -- nothing left
    # dangling in an unresolved state.
    decided_issue_ids = {d.issue_id for d in final_state.decisions}
    all_issue_ids = {i.issue_id for i in final_state.issues}
    assert decided_issue_ids == all_issue_ids

    # Every decision must be one of the four valid outcomes.
    valid_outcomes = {"accepted", "rejected", "rolled_back", "human_review"}
    assert all(d.outcome in valid_outcomes for d in final_state.decisions)


def test_full_graph_never_touches_the_original_file():
    original_before = pd.read_csv("sample_data/sample_customers.csv")

    graph = build_graph()
    initial_state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    graph.invoke(initial_state, config={"recursion_limit": 50})

    original_after = pd.read_csv("sample_data/sample_customers.csv")
    pd.testing.assert_frame_equal(original_before, original_after)


def test_full_graph_produces_a_complete_audit_trail():
    from app.audit.audit_logger import get_trail_for_run

    graph = build_graph()
    initial_state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    final_state_dict = graph.invoke(initial_state, config={"recursion_limit": 50})
    final_state = ForensicsState(**final_state_dict)

    trail = get_trail_for_run(final_state.run_id)

    # At minimum: one "investigate" entry, plus one "diagnose"/"repair"/"validate"
    # entry per issue that was processed.
    steps_logged = [entry.step for entry in trail]
    assert "investigate" in steps_logged
    assert steps_logged.count("diagnose") == len(final_state.issues)
    assert steps_logged.count("validate") == len(final_state.issues)

    # Every validate-step entry should carry a final decision.
    validate_entries = [e for e in trail if e.step == "validate"]
    assert all(e.decision in {"accepted", "rejected", "rolled_back", "human_review"} for e in validate_entries)
