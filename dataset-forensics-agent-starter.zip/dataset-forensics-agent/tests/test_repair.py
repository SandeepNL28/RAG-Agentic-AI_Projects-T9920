"""
Unit tests for the deterministic repair tools.

Run with:  pytest -v
"""

import pandas as pd
import pytest

from app.tools.quality_analysis import category_consistency_analysis
from app.tools.repair import (
    normalize_categories,
    impute_missing_values,
    standardize_dates,
    correct_data_types,
    remove_exact_duplicates,
)


@pytest.fixture
def sample_df():
    return pd.read_csv("sample_data/sample_customers.csv")


def test_normalize_categories_collapses_new_york_variants(sample_df):
    detection = category_consistency_analysis(sample_df, "city")
    repaired = normalize_categories(sample_df, "city", detection["inconsistent_groups"])

    # All three New York rows should now share exactly one spelling
    ny_values = repaired.loc[[0, 5, 8], "city"].unique()
    assert len(ny_values) == 1

    # The original DataFrame must be untouched (repair tools never mutate in place)
    assert sample_df.loc[5, "city"] == "new york"


def test_impute_missing_values_fills_age_with_median(sample_df):
    repaired = impute_missing_values(sample_df, "age", strategy="median")

    assert repaired["age"].isna().sum() == 0
    # median of [27,29,31,34,34,38,41,45,240] = 34
    assert repaired.loc[2, "age"] == 34

    # Original untouched
    assert pd.isna(sample_df.loc[2, "age"])


def test_impute_missing_values_fills_income_with_median(sample_df):
    repaired = impute_missing_values(sample_df, "annual_income", strategy="median")
    assert repaired["annual_income"].isna().sum() == 0
    assert repaired.loc[4, "annual_income"] == 64000


def test_standardize_dates_normalizes_mixed_formats(sample_df):
    repaired = standardize_dates(sample_df, "signup_date")

    # "01/03/2023" is MM/DD/YYYY -> January 3rd -> "2023-01-03"
    assert repaired.loc[2, "signup_date"] == "2023-01-03"
    # "05-04-2023" is DD-MM-YYYY -> April 5th -> "2023-04-05"
    assert repaired.loc[5, "signup_date"] == "2023-04-05"
    # Already-correct values pass through unchanged
    assert repaired.loc[0, "signup_date"] == "2023-01-15"


def test_correct_data_types_converts_numeric_strings():
    df = pd.DataFrame({"quantity": ["10", "25", "7", "not_a_number"]})
    repaired = correct_data_types(df, "quantity", "numeric")

    assert repaired["quantity"].dtype.kind == "f"  # float64 after coercion
    assert repaired.loc[3, "quantity"] != repaired.loc[3, "quantity"]  # NaN check


def test_remove_exact_duplicates_removes_only_true_duplicates():
    df = pd.DataFrame({
        "id": [1, 2, 3],
        "name": ["Alice", "Bob", "Alice"],
        "age": [30, 40, 30],
    })
    # Rows 0 and 2 are NOT exact duplicates (different id), so nothing removed
    repaired = remove_exact_duplicates(df)
    assert len(repaired) == 3

    df_with_real_dupe = pd.concat([df, df.iloc[[0]]], ignore_index=True)
    repaired2 = remove_exact_duplicates(df_with_real_dupe)
    assert len(repaired2) == 3  # the appended exact copy of row 0 is removed
