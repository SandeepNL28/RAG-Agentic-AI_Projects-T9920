"""
Shared pytest configuration. The one thing every test in this project
needs, regardless of which file it's in: the audit trail database must
never point at the real audit_trail.sqlite during tests, or running the
test suite would silently pollute (and grow) that real file every time.

This autouse fixture applies to EVERY test automatically -- no need to
import or request it explicitly.
"""

import pytest

from app.core.config import settings
from app.audit import audit_logger
from app.api import run_registry


@pytest.fixture(autouse=True)
def _isolate_audit_db(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "audit_db_path", str(tmp_path / "test_audit_trail.sqlite"))
    monkeypatch.setattr(audit_logger, "_engine", None)
    monkeypatch.setattr(audit_logger, "_current_db_path", None)

    monkeypatch.setattr(settings, "run_registry_db_path", str(tmp_path / "test_run_registry.sqlite"))
    monkeypatch.setattr(run_registry, "_engine", None)
    monkeypatch.setattr(run_registry, "_current_db_path", None)
