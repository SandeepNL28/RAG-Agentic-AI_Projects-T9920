"""
Tests for Baseline 1 (rule-based pipeline). This baseline is deliberately
"dumb" -- these tests confirm it behaves exactly as blindly as intended,
which is the whole point of using it as a fair comparison point.
"""

import pandas as pd

from evaluation.baselines.rule_based import run_rule_based_pipeline


def test_rule_based_replaces_outlier_with_mean_blindly():
    # Needs enough data points that a single extreme value doesn't inflate
    # the standard deviation enough to mask its own z-score (the same
    # small-sample z-score limitation documented elsewhere in this
    # project -- see tests/test_tools.py's outlier detection notes).
    # An "id" column keeps every row distinct so the repeated normal
    # values don't accidentally collide with the pipeline's own
    # duplicate-removal step (the same interaction fixed in the test below).
    normal_values = [25, 26, 27, 28, 29, 30, 31, 32, 33, 34] * 2  # 20 normal points
    ages = normal_values + [240]
    df = pd.DataFrame({"id": range(len(ages)), "age": ages})
    result = run_rule_based_pipeline(df)

    original_mean = df["age"].mean()
    # The rule blindly replaces it with the (corruption-inflated) mean --
    # NOT the plausible original value (e.g. 24). This is intentionally
    # worse than the evidence-gated approach, which is exactly the
    # contrast the evaluation is meant to demonstrate.
    assert result.loc[20, "age"] == original_mean
    assert result.loc[20, "age"] != 240


def test_rule_based_fills_missing_numeric_with_mean():
    # An "id" column keeps every row structurally distinct, so filling
    # the missing income with its mean doesn't accidentally create an
    # exact-duplicate row that the pipeline's own dedup step would then
    # remove -- that interaction is real and correct pipeline behavior,
    # but it would make THIS test (about fillna specifically) ambiguous.
    df = pd.DataFrame({
        "id": [1, 2, 3, 4],
        "income": [50000, 60000, None, 70000],
    })
    result = run_rule_based_pipeline(df)

    assert result["income"].isna().sum() == 0
    expected_mean = df["income"].dropna().mean()
    assert result.loc[2, "income"] == expected_mean


def test_rule_based_lowercases_every_text_column_no_matter_what():
    df = pd.DataFrame({"city": ["New York", "BOSTON", "chicago"]})
    result = run_rule_based_pipeline(df)

    assert list(result["city"]) == ["new york", "boston", "chicago"]


def test_rule_based_removes_exact_duplicates():
    df = pd.DataFrame({"id": [1, 2, 1], "name": ["A", "B", "A"]})
    result = run_rule_based_pipeline(df)

    assert len(result) == 2
