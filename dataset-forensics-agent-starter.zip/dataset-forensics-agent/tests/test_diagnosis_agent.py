"""
Tests for the Diagnosis Agent.

We CANNOT call a real LLM in this environment (no Ollama server available
here) -- so call_llm is mocked with monkeypatch to return a fixed,
realistic JSON response. This proves the agent's own logic (prompt
building, parsing the response, triggering evidence-gathering) is correct,
independent of what a real model would say. This is standard practice for
testing LLM-dependent code.

Once you're on your own machine with `ollama serve` running, you can also
run this manually against the REAL model -- see the bottom of this file.
"""

import pandas as pd
import pytest

from app.core.schemas import ForensicsState, DetectedIssue
from app.agents import diagnosis_agent


@pytest.fixture
def state_with_age_outlier():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    state.issues.append(DetectedIssue(
        issue_id="issue-1",
        column="age",
        issue_type="outlier",
        severity="high",
        affected_rows=[3],
        raw_observation="1 value(s) exceed 2.5 standard deviations from the mean.",
    ))
    state.current_issue_id = "issue-1"
    return state


def test_diagnosis_agent_parses_mocked_llm_response_into_hypothesis(monkeypatch, state_with_age_outlier):
    mocked_response = {
        "explanation": "Likely a data-entry typo: an extra digit was probably added (24 -> 240).",
        "requires_evidence": ["data_dictionary_rule"],
    }
    monkeypatch.setattr(diagnosis_agent, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diagnosis_agent.run(state_with_age_outlier)

    assert len(result_state.hypotheses) == 1
    hyp = result_state.hypotheses[0]
    assert hyp.issue_id == "issue-1"
    assert "typo" in hyp.explanation.lower()
    assert hyp.requires_evidence == ["data_dictionary_rule"]


def test_diagnosis_agent_gathers_evidence_after_hypothesis(monkeypatch, state_with_age_outlier):
    mocked_response = {
        "explanation": "Likely a typo.",
        "requires_evidence": ["data_dictionary_rule"],
    }
    monkeypatch.setattr(diagnosis_agent, "call_llm", lambda prompt, expect_json=True: mocked_response)

    result_state = diagnosis_agent.run(state_with_age_outlier)

    assert len(result_state.evidence) == 1
    ev = result_state.evidence[0]
    assert ev.source == "data_dictionary_rule"
    assert ev.supports_hypothesis is True  # age=240 genuinely violates the 0-120 rule


# ---------------------------------------------------------------------------
# MANUAL LIVE TEST (not run by pytest -- run this yourself once Ollama is up)
# ---------------------------------------------------------------------------
# python -c "
# from app.core.schemas import ForensicsState, DetectedIssue
# from app.agents import diagnosis_agent
# state = ForensicsState(dataset_path='sample_data/sample_customers.csv')
# state.issues.append(DetectedIssue(
#     issue_id='issue-1', column='age', issue_type='outlier', severity='high',
#     affected_rows=[3], raw_observation='1 value exceeds threshold.',
# ))
# state.current_issue_id = 'issue-1'
# result = diagnosis_agent.run(state)
# print(result.hypotheses)
# print(result.evidence)
# "
