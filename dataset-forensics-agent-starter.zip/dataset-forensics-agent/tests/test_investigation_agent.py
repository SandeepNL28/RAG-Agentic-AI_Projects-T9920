"""
Tests for the Investigation Agent. No LLM involved -- this node is pure
tool orchestration, so it's fully testable without Ollama running.
"""

from app.core.schemas import ForensicsState
from app.agents import investigation_agent


def test_investigation_agent_finds_all_planted_issues():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    result_state = investigation_agent.run(state)

    issue_types_found = {issue.issue_type for issue in result_state.issues}

    # We know exactly what's planted in sample_customers.csv:
    assert "missing_value" in issue_types_found       # age, annual_income
    assert "outlier" in issue_types_found              # age = 240
    assert "category_inconsistency" in issue_types_found  # New York variants
    assert "date_format" in issue_types_found           # mixed signup_date formats


def test_investigation_agent_assigns_unique_issue_ids():
    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    result_state = investigation_agent.run(state)

    issue_ids = [issue.issue_id for issue in result_state.issues]
    assert len(issue_ids) == len(set(issue_ids))  # all unique


def test_investigation_agent_does_not_mutate_original_file():
    import pandas as pd
    before = pd.read_csv("sample_data/sample_customers.csv")

    state = ForensicsState(dataset_path="sample_data/sample_customers.csv")
    investigation_agent.run(state)

    after = pd.read_csv("sample_data/sample_customers.csv")
    pd.testing.assert_frame_equal(before, after)
