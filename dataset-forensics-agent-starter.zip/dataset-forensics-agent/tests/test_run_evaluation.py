"""
End-to-end test of the evaluation harness. This actually runs all three
systems against a real corrupted scenario and checks the resulting
numbers are computed correctly and are internally consistent -- this is
the closest thing in the project to "does the core research claim hold up
on a real (if small) run."
"""

import pytest

from app.agents import diagnosis_agent
from evaluation import run_evaluation


@pytest.fixture(autouse=True)
def mock_llm(monkeypatch):
    """
    Mocks BOTH the proposed system's diagnosis step AND Baseline 2's
    fixed workflow LLM calls -- no live Ollama server is available in
    this test environment. The mock gives a generic but plausible
    response so the surrounding evidence-gating / gating-free logic of
    each system can be genuinely exercised and compared.
    """
    def _fake_diagnosis_llm(prompt, expect_json=True):
        return {
            "explanation": "Automated evaluation-run hypothesis.",
            "requires_evidence": ["statistical_distribution", "data_dictionary_rule"],
        }
    monkeypatch.setattr(diagnosis_agent, "call_llm", _fake_diagnosis_llm)

    def _fake_baseline_llm(prompt, expect_json=True):
        # Baseline 2 always says "yes, fix it" -- no gating, matching its
        # documented behavior of applying whatever the LLM says immediately.
        if "impute" in prompt.lower() or "missing_value" in prompt.lower() or "outlier" in prompt.lower():
            return {"action": "impute", "fixed_value": None}
        return {"action": "normalize", "fixed_value": None}

    from evaluation.baselines import fixed_llm_workflow
    monkeypatch.setattr(fixed_llm_workflow, "call_llm", _fake_baseline_llm)


def test_build_benchmark_scenario_produces_trackable_ground_truth():
    corrupted_df, ground_truths = run_evaluation.build_benchmark_scenario()

    corruption_types = {gt["corruption_type"] for gt in ground_truths}
    assert corruption_types == {"outlier", "missing_value", "category_inconsistency", "duplicate"}

    # The corrupted dataset should actually be bigger than the clean one
    # (due to injected duplicates).
    clean_df = run_evaluation.build_clean_dataset()
    assert len(corrupted_df) > len(clean_df)


def test_score_baseline_output_hand_verifiable_case():
    import pandas as pd
    # A trivial scenario: one column, one corrupted row, baseline fixed it correctly.
    output_df = pd.DataFrame({"age": [25, 26, 27]})
    ground_truths = [{"corruption_type": "outlier", "column": "age", "true_values": {1: 26}}]

    result = run_evaluation.score_baseline_output(output_df, ground_truths)
    assert result["total_checked"] == 1
    assert result["total_correct"] == 1
    assert result["repair_accuracy"] == 1.0


def test_full_evaluation_runs_and_produces_internally_consistent_numbers():
    results = run_evaluation.run_full_evaluation(seed=7)

    # Structural checks: every system reported something.
    assert "baseline1_rule_based" in results
    assert "baseline2_fixed_llm" in results
    assert "proposed_system" in results

    b1 = results["baseline1_rule_based"]
    b2 = results["baseline2_fixed_llm"]
    proposed = results["proposed_system"]

    # Repair accuracy must be a valid fraction.
    assert 0.0 <= b1["repair_accuracy"] <= 1.0
    assert 0.0 <= b2["repair_accuracy"] <= 1.0

    # The proposed system's detection metrics must be valid fractions too.
    assert 0.0 <= proposed["detection"]["precision"] <= 1.0
    assert 0.0 <= proposed["detection"]["recall"] <= 1.0

    # Safe Repair Rate, if defined at all (not None), must be a valid fraction.
    if proposed["safe_repair_rate"] is not None:
        assert 0.0 <= proposed["safe_repair_rate"] <= 1.0
    assert 0.0 <= proposed["false_repair_rate"] <= 1.0
    assert 0.0 <= proposed["autonomy_rate"] <= 1.0

    # The proposed system should detect at least SOME of the four
    # genuinely corrupted columns -- if it detected zero, something in
    # the pipeline is broken, not just "imperfect."
    assert proposed["detection"]["true_positives"] > 0


def test_full_evaluation_proposed_system_never_touches_the_corrupted_input_file_in_place():
    """
    Sanity check that the proposed system's sandbox discipline holds even
    inside the evaluation harness, not just in the unit tests.
    """
    import pandas as pd
    corrupted_df, _ = run_evaluation.build_benchmark_scenario(seed=7)
    corrupted_df.to_csv("/tmp/eval_scenario_corrupted.csv", index=False)
    before = pd.read_csv("/tmp/eval_scenario_corrupted.csv")

    run_evaluation.run_full_evaluation(seed=7)

    after = pd.read_csv("/tmp/eval_scenario_corrupted.csv")
    pd.testing.assert_frame_equal(before, after)
