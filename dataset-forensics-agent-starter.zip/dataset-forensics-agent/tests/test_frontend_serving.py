"""
Tests confirming the static frontend is served correctly, and critically,
that mounting it as a catch-all at "/" does NOT shadow or break any of
the actual API routes registered earlier.
"""

from fastapi.testclient import TestClient

from app.api.main import app

client = TestClient(app)


def test_root_serves_the_dashboard_html():
    response = client.get("/")
    assert response.status_code == 200
    assert "text/html" in response.headers["content-type"]
    assert "Autonomous Dataset Forensics Agent" in response.text


def test_app_js_is_served_with_correct_content_type():
    response = client.get("/app.js")
    assert response.status_code == 200
    assert "javascript" in response.headers["content-type"]
    assert "startInvestigation" in response.text  # sanity check it's the real file


def test_styles_css_is_served():
    response = client.get("/styles.css")
    assert response.status_code == 200
    assert "css" in response.headers["content-type"]


def test_api_routes_still_work_and_are_not_shadowed_by_the_static_mount():
    # These must still resolve correctly even though StaticFiles is
    # mounted at "/" as a catch-all -- proves route registration order
    # protects them.
    assert client.get("/health").status_code == 200
    assert client.get("/health").json() == {"status": "ok"}

    assert client.post("/runs/start?dataset_id=does-not-exist").status_code == 404
    assert client.get("/runs/does-not-exist/status").status_code == 404


def test_swagger_docs_still_load():
    response = client.get("/docs")
    assert response.status_code == 200
    assert "swagger" in response.text.lower()


def test_unknown_path_returns_404_not_a_crash():
    response = client.get("/this-path-does-not-exist-anywhere")
    assert response.status_code == 404
