"""
Tests for corruption injection. These matter more than they might look --
if ground truth tracking is wrong here, every downstream metric
(Safe Repair Rate, False Repair Rate) becomes meaningless without anyone
noticing, since there'd be no way to tell the difference between "the
agent got it wrong" and "our ground truth was wrong to begin with."
"""

import pandas as pd
import pytest

from benchmark.corrupt import (
    inject_outliers,
    inject_missing_values,
    inject_category_noise,
    inject_duplicates,
    inject_date_format_noise,
)


@pytest.fixture
def clean_df():
    return pd.DataFrame({
        "id": range(1, 11),
        "age": [25, 30, 35, 40, 45, 50, 55, 60, 65, 70],
        "city": ["New York", "Boston", "Chicago", "Seattle", "Denver",
                 "Austin", "Miami", "Dallas", "Phoenix", "Atlanta"],
        "signup_date": ["2023-01-01", "2023-02-01", "2023-03-01", "2023-04-01", "2023-05-01",
                         "2023-06-01", "2023-07-01", "2023-08-01", "2023-09-01", "2023-10-01"],
    })


def test_inject_outliers_ground_truth_matches_original_values(clean_df):
    corrupted, ground_truth = inject_outliers(clean_df, "age", frac=0.3, factor=10)

    assert ground_truth["corruption_type"] == "outlier"
    for row_idx, true_value in ground_truth["true_values"].items():
        # The original value recorded in ground truth must match what was
        # ACTUALLY there before corruption -- verified against the clean_df fixture.
        assert clean_df.loc[row_idx, "age"] == true_value
        # And the corrupted dataframe must now hold a different, larger value.
        assert corrupted.loc[row_idx, "age"] == true_value * 10


def test_inject_missing_values_ground_truth_is_recoverable(clean_df):
    corrupted, ground_truth = inject_missing_values(clean_df, "city", frac=0.4)

    for row_idx, true_value in ground_truth["true_values"].items():
        assert clean_df.loc[row_idx, "city"] == true_value
        assert pd.isna(corrupted.loc[row_idx, "city"])


def test_inject_category_noise_preserves_semantic_meaning(clean_df):
    corrupted, ground_truth = inject_category_noise(clean_df, "city", frac=0.5)

    for row_idx, true_value in ground_truth["true_values"].items():
        assert clean_df.loc[row_idx, "city"] == true_value
        corrupted_value = corrupted.loc[row_idx, "city"]
        # The corrupted value should be a case-variant of the SAME city,
        # not a random different value -- this is what makes the ground
        # truth meaningful for scoring a repair as "correct."
        assert corrupted_value.lower() == true_value.lower()


def test_inject_duplicates_tracks_expected_count(clean_df):
    corrupted, ground_truth = inject_duplicates(clean_df, frac=0.3)

    assert ground_truth["original_row_count"] == 10
    assert len(corrupted) == 10 + ground_truth["expected_duplicate_count"]
    assert corrupted.duplicated().sum() == ground_truth["expected_duplicate_count"]


def test_inject_date_format_noise_produces_a_different_but_parseable_format(clean_df):
    corrupted, ground_truth = inject_date_format_noise(clean_df, "signup_date", frac=0.5)

    for row_idx, true_value in ground_truth["true_values"].items():
        assert clean_df.loc[row_idx, "signup_date"] == true_value
        corrupted_value = corrupted.loc[row_idx, "signup_date"]
        # MM/DD/YYYY should be recoverable back into the original YYYY-MM-DD
        month, day, year = corrupted_value.split("/")
        assert f"{year}-{month}-{day}" == true_value


def test_corruption_functions_never_mutate_the_original_dataframe(clean_df):
    before = clean_df.copy()
    inject_outliers(clean_df, "age")
    inject_missing_values(clean_df, "city")
    inject_category_noise(clean_df, "city")
    inject_date_format_noise(clean_df, "signup_date")

    pd.testing.assert_frame_equal(clean_df, before)


def test_corruption_is_deterministic_given_the_same_seed(clean_df):
    corrupted_a, gt_a = inject_outliers(clean_df, "age", seed=99)
    corrupted_b, gt_b = inject_outliers(clean_df, "age", seed=99)

    pd.testing.assert_frame_equal(corrupted_a, corrupted_b)
    assert gt_a == gt_b
