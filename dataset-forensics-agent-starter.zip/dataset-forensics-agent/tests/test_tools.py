"""
Unit tests for the deterministic quality-analysis tools.

Run with:  pytest -v
"""

import pandas as pd
import pytest

from app.tools.quality_analysis import (
    missing_value_analysis,
    outlier_detection,
    duplicate_analysis,
    category_consistency_analysis,
    date_format_consistency,
    distribution_analysis,
    constraint_check,
)


@pytest.fixture
def sample_df():
    return pd.read_csv("sample_data/sample_customers.csv")


def test_missing_value_analysis_finds_known_gaps(sample_df):
    result = missing_value_analysis(sample_df)

    # We deliberately left "age" (row 3) and "annual_income" (row 5) blank
    assert "age" in result
    assert "annual_income" in result
    assert result["age"]["missing_count"] == 1
    assert result["annual_income"]["missing_count"] == 1


def test_outlier_detection_flags_the_age_240_row(sample_df):
    # NOTE: with only 9 non-null age values, the single extreme value (240)
    # inflates the standard deviation so much it "masks" its own z-score
    # (a well-known limitation of z-score outlier detection on small samples).
    # At the default threshold (3.0) it narrowly slips under; at 2.5 it is
    # correctly flagged. This is worth remembering for the real Investigation
    # Agent tool later -- small datasets may need a lower threshold or a more
    # robust method (e.g. IQR-based detection) instead of a fixed z-score cutoff.
    result = outlier_detection(sample_df, "age", z_thresh=2.5)

    # Row index 3 (0-based, the 4th data row) has age = 240
    assert 3 in result["flagged_rows"]
    assert result["flagged_values"][3] == 240


def test_outlier_detection_handles_no_outliers_gracefully(sample_df):
    # annual_income has no extreme outliers relative to itself
    result = outlier_detection(sample_df, "annual_income")
    assert isinstance(result["flagged_rows"], list)


def test_duplicate_analysis_runs_without_error(sample_df):
    result = duplicate_analysis(sample_df)
    assert "duplicate_count" in result
    assert result["duplicate_count"] >= 0


def test_category_consistency_finds_new_york_variants(sample_df):
    # "New York" (row 0), "new york" (row 5), "NEW YORK" (row 8) are all the
    # same city written three different ways.
    result = category_consistency_analysis(sample_df, "city")

    assert "new york" in result["inconsistent_groups"]
    variants = result["inconsistent_groups"]["new york"]
    assert set(variants) == {"New York", "new york", "NEW YORK"}
    assert 0 in result["affected_rows"]
    assert 5 in result["affected_rows"]
    assert 8 in result["affected_rows"]


def test_category_consistency_ignores_genuinely_unique_cities(sample_df):
    result = category_consistency_analysis(sample_df, "city")
    # "Boston" only appears once -- it should NOT be flagged as inconsistent
    assert "boston" not in result["inconsistent_groups"]


def test_date_format_consistency_flags_minority_formats(sample_df):
    # Most signup_date values are YYYY-MM-DD; rows 2 ("01/03/2023") and
    # 5 ("05-04-2023") deliberately use different formats.
    result = date_format_consistency(sample_df, "signup_date")

    assert result["majority_format"] == "YYYY-MM-DD"
    assert 2 in result["flagged_rows"]
    assert 5 in result["flagged_rows"]


def test_distribution_analysis_reports_expected_shape(sample_df):
    result = distribution_analysis(sample_df, "age")

    # 9 non-null ages, min=27, max=240 (the deliberate outlier)
    assert result["count"] == 9
    assert result["min"] == 27
    assert result["max"] == 240
    assert result["mean"] > result["median"]  # the 240 outlier pulls the mean up


def test_constraint_check_flags_age_over_max(sample_df):
    rules = {"age": {"min": 0, "max": 120}}
    result = constraint_check(sample_df, rules)

    assert "age" in result["violations"]
    assert 3 in result["violations"]["age"]["violated_rows"]  # age = 240
    assert result["violations"]["age"]["violated_values"][3] == 240


def test_constraint_check_passes_when_no_rules_are_broken(sample_df):
    rules = {"annual_income": {"min": 0, "max": 1_000_000}}
    result = constraint_check(sample_df, rules)

    assert "annual_income" not in result["violations"]
    assert result["summary"] == "All checked columns satisfy their constraints."
