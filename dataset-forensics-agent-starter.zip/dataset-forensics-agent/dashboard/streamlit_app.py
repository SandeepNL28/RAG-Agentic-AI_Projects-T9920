"""
Streamlit dashboard for the Autonomous Dataset Forensics Agent.

This is deliberately a THIN client: it never touches the dataset, the
agents, or the database directly -- every action goes through the FastAPI
backend over HTTP, exactly like any other API consumer would. This keeps
a clean boundary between UI and logic, per the architecture design.

Run with:
    streamlit run dashboard/streamlit_app.py

Requires the API server to be running separately:
    uvicorn app.api.main:app --port 8000
"""

import os
import time

import requests
import streamlit as st

API_BASE_URL = os.environ.get("FORENSICS_API_URL", "http://localhost:8000")

st.set_page_config(page_title="Dataset Forensics Agent", layout="wide")
st.title("🔎 Autonomous Dataset Forensics Agent")
st.caption(
    "Upload a dataset to have the agent investigate it: gathering evidence, "
    "proposing safe repairs, and validating every change before accepting it."
)


def upload_dataset(file) -> str:
    response = requests.post(
        f"{API_BASE_URL}/datasets/upload",
        files={"file": (file.name, file.getvalue())},
        timeout=30,
    )
    response.raise_for_status()
    return response.json()["dataset_id"]


def start_run(dataset_id: str) -> str:
    response = requests.post(f"{API_BASE_URL}/runs/start", params={"dataset_id": dataset_id}, timeout=30)
    response.raise_for_status()
    return response.json()["run_id"]


def get_status(run_id: str) -> dict:
    response = requests.get(f"{API_BASE_URL}/runs/{run_id}/status", timeout=30)
    response.raise_for_status()
    return response.json()


def get_issues(run_id: str) -> list:
    response = requests.get(f"{API_BASE_URL}/runs/{run_id}/issues", timeout=30)
    response.raise_for_status()
    return response.json()


def get_audit(run_id: str) -> list:
    response = requests.get(f"{API_BASE_URL}/runs/{run_id}/audit", timeout=30)
    response.raise_for_status()
    return response.json()


def wait_for_completion(run_id: str, poll_interval: float = 1.0, max_wait: float = 300.0) -> dict:
    elapsed = 0.0
    while elapsed < max_wait:
        status = get_status(run_id)
        if status["status"] in ("completed", "failed"):
            return status
        time.sleep(poll_interval)
        elapsed += poll_interval
    raise TimeoutError(f"Run {run_id} did not complete within {max_wait} seconds.")


# ---------------------------------------------------------------------------
# Main UI
# ---------------------------------------------------------------------------

uploaded_file = st.file_uploader("Upload a dataset (CSV or Excel)", type=["csv", "xlsx", "xls"])

if uploaded_file and st.button("Run Investigation", type="primary"):
    try:
        with st.spinner("Uploading dataset..."):
            dataset_id = upload_dataset(uploaded_file)

        with st.spinner("Investigating... (this calls the local LLM and may take a moment)"):
            run_id = start_run(dataset_id)
            final_status = wait_for_completion(run_id)

        if final_status["status"] == "failed":
            st.error(f"Run failed: {final_status.get('error')}")
        else:
            st.session_state["run_id"] = run_id
            st.success("Investigation complete.")

    except requests.exceptions.ConnectionError:
        st.error(
            f"Could not reach the API at {API_BASE_URL}. "
            "Is it running? Start it with: uvicorn app.api.main:app --port 8000"
        )
    except Exception as exc:  # noqa: BLE001
        st.error(f"Something went wrong: {exc}")


if "run_id" in st.session_state:
    run_id = st.session_state["run_id"]
    issues = get_issues(run_id)
    audit_entries = get_audit(run_id)

    # --- Summary panel ---
    st.subheader("Summary")
    outcome_counts = {"accepted": 0, "rejected": 0, "rolled_back": 0, "human_review": 0}
    for issue in issues:
        decision = issue.get("decision")
        if decision:
            outcome_counts[decision["outcome"]] = outcome_counts.get(decision["outcome"], 0) + 1

    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Issues Found", len(issues))
    col2.metric("Accepted Repairs", outcome_counts["accepted"])
    col3.metric("Rolled Back", outcome_counts["rolled_back"])
    col4.metric("Sent to Human Review", outcome_counts["human_review"])
    autonomy_rate = (
        (outcome_counts["accepted"] + outcome_counts["rejected"]) / len(issues) * 100
        if issues else 0
    )
    col5.metric("Autonomy Rate", f"{autonomy_rate:.0f}%")

    # --- Detected issues panel ---
    st.subheader("Detected Issues")
    st.dataframe(
        [
            {
                "Column": issue.get("column"),
                "Issue Type": issue.get("issue_type"),
                "Severity": issue.get("severity"),
                "Observation": issue.get("raw_observation"),
                "Decision": issue["decision"]["outcome"] if issue.get("decision") else "pending",
                "Reason": issue["decision"]["reason"] if issue.get("decision") else "",
            }
            for issue in issues
        ],
        use_container_width=True,
    )

    # --- Agent trajectory panel ---
    st.subheader("Agent Trajectory")
    for entry in audit_entries:
        with st.expander(f"[{entry['step']}] {entry['reasoning_summary'][:80]}"):
            st.write(f"**Tool used:** {entry.get('tool_used') or 'n/a'}")
            st.write(f"**Observation:** {entry['observation']}")
            st.write(f"**Reasoning:** {entry['reasoning_summary']}")
            if entry.get("decision"):
                st.write(f"**Decision:** {entry['decision']}")

    # --- Download ---
    st.subheader("Final Output")
    download_url = f"{API_BASE_URL}/runs/{run_id}/download"
    st.markdown(f"[⬇ Download cleaned dataset]({download_url})")
